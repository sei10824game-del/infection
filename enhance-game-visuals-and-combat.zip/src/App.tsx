import { useEffect, useMemo, useRef, useState } from 'react';
import { Engine, attackPhase } from './game/engine';
import { FACTIONS, FACTION_MAP, EFFECT_LABEL } from './game/data';
import { drawScene, drawMinimap, project, unproject, type Camera } from './game/render';
import type { Unit } from './game/types';

const KIND_LABEL: Record<string, string> = {
  slash: '斬撃', stab: '刺突', smash: '叩きつけ', bite: '噛みつき', tail: '尾撃', tentacle: '触手', charge: '突進', pounce: '跳躍', shoot: '射撃', spit: '吐射',
  gas: 'ガス', explode: '自爆', grab: '掴み', flame: '火炎', slam: '衝撃波', spin: '回転', throw: '投擲', punch: '打撃', kick: '蹴り', whip: '鞭', drain: '吸収', spawn: '生成', scream: '咆哮',
};

interface Snapshot {
  time: number; units: number; counts: Record<string, number>; winner: string | null; events: string[];
  sel: null | { id: number; name: string; fid: string; vkey: string; hp: number; maxHp: number; atk: number; def: number; spd: number; kills: number; inf: string | null; infK: number; fear: number; pollution: number; attack: string | null; phase: string | null; cds: { name: string; cd: number; max: number; kind: string }[]; state: string; heldBy: boolean; stun: number; adapt: number; biomass: number };
  stats: Record<string, { kills: number; spawned: number; infected: number }>;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const camRef = useRef<Camera>({ x: 4500, zoom: 1.5 });
  const followRef = useRef(false);
  const keysRef = useRef(new Set<string>());
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [follow, setFollow] = useState(false);
  const [spawnFid, setSpawnFid] = useState(FACTIONS[0].id);
  const [spawnCount, setSpawnCount] = useState(5);
  const [infoFid, setInfoFid] = useState(FACTIONS[1].id);
  const [infoV, setInfoV] = useState(FACTIONS[1].variants[0].key);
  const [leftOpen, setLeftOpen] = useState(typeof window !== 'undefined' ? window.innerWidth > 900 : true);
  const [rightOpen, setRightOpen] = useState(typeof window !== 'undefined' ? window.innerWidth > 900 : true);
  const [tab, setTab] = useState<'unit' | 'spawn' | 'info' | 'log'>('unit');

  if (!engineRef.current) { engineRef.current = new Engine(); engineRef.current.reset(); }

  useEffect(() => { engineRef.current!.paused = paused; }, [paused]);
  useEffect(() => { engineRef.current!.speed = speed; }, [speed]);
  useEffect(() => { followRef.current = follow; }, [follow]);

  useEffect(() => {
    const canvas = canvasRef.current!; const ctx = canvas.getContext('2d')!;
    const eng = engineRef.current!;
    let raf = 0; let last = performance.now(); let uiT = 0; let shakeX = 0, shakeY = 0;
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize(); window.addEventListener('resize', resize);

    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      const cam = camRef.current; const W = canvas.width, H = canvas.height; const w = eng.world;
      // keys
      const k = keysRef.current; let dx = 0;
      if (k.has('a') || k.has('arrowleft')) dx -= 1; if (k.has('d') || k.has('arrowright')) dx += 1;
      if (k.has('w') || k.has('arrowup')) cam.zoom = Math.min(3.2, cam.zoom * (1 + dt * 1.2)); if (k.has('s') || k.has('arrowdown')) cam.zoom = Math.max(0.6, cam.zoom / (1 + dt * 1.2));
      if (dx) { cam.x += dx * 700 * dt / cam.zoom; if (followRef.current) { followRef.current = false; setFollow(false); } }
      // follow action
      if (followRef.current && !eng.paused) {
        let sx = 0, n = 0; const sel = eng.selectedId != null ? w.units.find((u) => u.id === eng.selectedId) : null;
        if (sel) { sx = sel.x; n = 1; }
        else for (const u of w.units) if (u.hitT > 0 || (u.attack && attackPhase(u.attack) === 'strike')) { sx += u.x; n++; }
        if (n) cam.x += ((sx / n) - cam.x) * Math.min(1, dt * 1.6);
      }
      cam.x = Math.max(W / cam.zoom * 0.35, Math.min(w.width - W / cam.zoom * 0.35, cam.x));
      eng.step(dt);
      // shake
      if (w.shake.t > 0) { shakeX = (Math.random() - 0.5) * w.shake.amp; shakeY = (Math.random() - 0.5) * w.shake.amp * 0.6; } else { shakeX *= 0.8; shakeY *= 0.8; }
      ctx.setTransform(1, 0, 0, 1, shakeX, shakeY);
      drawScene(ctx, w, cam, W, H, eng.selectedId, w.time);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      const mini = miniRef.current; if (mini) { const mc = mini.getContext('2d')!; mc.clearRect(0, 0, mini.width, mini.height); drawMinimap(mc, w, cam, W, H, mini.width, mini.height); }
      uiT += dt;
      if (uiT > 0.2) {
        uiT = 0;
        const sel = eng.selectedId != null ? w.units.find((u) => u.id === eng.selectedId) : null;
        setSnap({
          time: w.time, units: w.units.length, counts: eng.counts(), winner: w.winner, events: w.events.slice(0, 14), stats: w.stats,
          sel: sel ? {
            id: sel.id, name: sel.name, fid: sel.fid, vkey: sel.vkey, hp: sel.hp, maxHp: sel.maxHp, atk: sel.atk, def: sel.def, spd: sel.spd, kills: sel.kills,
            inf: sel.inf ? `${EFFECT_LABEL[sel.inf.tag] ?? sel.inf.tag} (${FACTION_MAP.get(sel.inf.src)?.name})` : null, infK: sel.inf ? sel.inf.t / sel.inf.dur : 0,
            fear: sel.fear, pollution: sel.pollution, attack: sel.attack ? sel.attack.spec.name : null, phase: sel.attack ? attackPhase(sel.attack) : null,
            cds: sel.variant.attacks.map((a) => ({ name: a.name, cd: Math.max(0, sel.cds[a.id] ?? 0), max: a.cd, kind: a.kind })), state: sel.state, heldBy: sel.heldBy != null, stun: sel.stun, adapt: sel.adapt, biomass: sel.biomass,
          } : null,
        });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    // input
    let dragging = false, moved = false, lx = 0, ly = 0; let pinchD = 0;
    const pick = (cx: number, cy: number) => {
      const W = canvas.width, H = canvas.height; const cam = camRef.current; let best: Unit | null = null, bd = 900;
      for (const u of eng.world.units) { const q = project(cam, W, H, u.x, u.z, eng.world.depth); const bh = u.radius * 5.2 * u.look.size * q.s; const ddx = q.sx - cx, ddy = (q.sy - bh * 0.5) - cy; const d = ddx * ddx + ddy * ddy * 0.6; if (d < bd + bh * bh * 0.2 && d < 2500) { bd = d; best = u; } }
      eng.selectedId = best ? best.id : null; if (best) setTab('unit');
    };
    const down = (x: number, y: number) => { dragging = true; moved = false; lx = x; ly = y; };
    const move = (x: number, y: number) => { if (!dragging) return; const dx = x - lx, dy = y - ly; if (Math.abs(dx) + Math.abs(dy) > 3) moved = true; camRef.current.x -= dx / camRef.current.zoom; lx = x; ly = y; if (moved && followRef.current) { followRef.current = false; setFollow(false); } };
    const up = (x: number, y: number) => { if (dragging && !moved) pick(x, y); dragging = false; };
    canvas.addEventListener('mousedown', (e) => { if (e.button === 0) down(e.clientX, e.clientY); });
    window.addEventListener('mousemove', (e) => move(e.clientX, e.clientY));
    window.addEventListener('mouseup', (e) => { if (dragging) up(e.clientX, e.clientY); });
    canvas.addEventListener('wheel', (e) => { e.preventDefault(); const cam = camRef.current; const W = canvas.width, H = canvas.height; const before = unproject(cam, W, H, e.clientX, e.clientY, eng.world.depth); cam.zoom = Math.max(0.6, Math.min(3.2, cam.zoom * (e.deltaY > 0 ? 0.9 : 1.1))); const after = unproject(cam, W, H, e.clientX, e.clientY, eng.world.depth); cam.x += before.x - after.x; }, { passive: false });
    canvas.addEventListener('touchstart', (e) => { e.preventDefault(); if (e.touches.length === 2) { pinchD = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); dragging = false; } else down(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
    canvas.addEventListener('touchmove', (e) => { e.preventDefault(); if (e.touches.length === 2) { const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); if (pinchD) camRef.current.zoom = Math.max(0.6, Math.min(3.2, camRef.current.zoom * (d / pinchD))); pinchD = d; } else move(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
    canvas.addEventListener('touchend', (e) => { e.preventDefault(); if (e.changedTouches.length) up(e.changedTouches[0].clientX, e.changedTouches[0].clientY); pinchD = 0; }, { passive: false });
    const kd = (e: KeyboardEvent) => { const k = e.key.toLowerCase(); if (['w', 'a', 's', 'd', 'arrowleft', 'arrowright', 'arrowup', 'arrowdown'].includes(k)) { keysRef.current.add(k); e.preventDefault(); } if (k === ' ') { setPaused((p) => !p); e.preventDefault(); } };
    const ku = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); };
  }, []);

  const infoFaction = FACTION_MAP.get(infoFid)!;
  const infoVariant = useMemo(() => infoFaction.variants.find((v) => v.key === infoV) ?? infoFaction.variants[0], [infoFaction, infoV]);
  const eng = engineRef.current!;
  const jumpTo = (fid: string) => { const us = eng.world.units.filter((u) => u.fid === fid); if (us.length) { camRef.current.x = us.reduce((s, u) => s + u.x, 0) / us.length; } else camRef.current.x = FACTION_MAP.get(fid)!.spawn.x; setFollow(false); };

  const btn = 'px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 border border-slate-600 text-slate-100 text-sm font-bold shadow transition-colors';
  const panel = 'absolute bg-slate-950/85 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl text-slate-200 text-xs';

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none font-sans">
      <canvas ref={canvasRef} className="block w-full h-full touch-none" />

      {/* top bar */}
      <div className="absolute top-0 left-0 right-0 flex flex-wrap items-center gap-2 px-3 py-2 bg-gradient-to-b from-black/85 to-black/30 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2 flex-wrap">
          <div className="mr-2">
            <div className="text-amber-200 font-black text-base leading-tight tracking-wide drop-shadow">INFECTION WAR</div>
            <div className="text-[10px] text-slate-300 leading-tight">感染者・寄生体 戦争シミュレーション</div>
          </div>
          <button className={btn} onClick={() => setPaused((p) => !p)}>{paused ? '▶ 再開' : '❚❚ 一時停止'}</button>
          <button className={btn} onClick={() => { eng.reset(); setPaused(false); camRef.current.x = 4500; }}>↻ リセット</button>
          <button className={btn} onClick={() => eng.forceBattle()}>⚔ 総力戦</button>
          <label className="text-slate-200 text-sm flex items-center gap-1">速度
            <select className="bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-sm" value={speed} onChange={(e) => setSpeed(Number(e.target.value))}>
              {[0.25, 0.5, 1, 1.5, 2, 3, 4].map((s) => <option key={s} value={s}>{s}x</option>)}
            </select>
          </label>
          <button className={`${btn} ${follow ? 'ring-2 ring-amber-300' : ''}`} onClick={() => setFollow((f) => !f)}>🎥 戦闘追尾</button>
          <button className={btn} onClick={() => setLeftOpen((o) => !o)}>陣営</button>
          <button className={btn} onClick={() => setRightOpen((o) => !o)}>パネル</button>
        </div>
        <div className="ml-auto pointer-events-auto text-right">
          <div className="text-slate-100 text-sm font-bold">Units {snap?.units ?? 0} <span className="text-slate-400 font-normal">/ {snap ? snap.time.toFixed(0) : 0}s</span></div>
          <div className="text-[10px] text-slate-400">ドラッグ:移動 / ホイール・W,S:ズーム / A,D:横移動 / Space:停止</div>
        </div>
      </div>

      {snap?.winner && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 px-6 py-3 rounded-2xl bg-black/70 border border-amber-300/50 text-amber-200 font-black text-2xl drop-shadow-xl animate-pulse">
          🏆 {FACTION_MAP.get(snap.winner)?.name} の勝利
        </div>
      )}

      {/* minimap */}
      <div className="absolute right-3 bottom-3 rounded-lg overflow-hidden border border-white/20 shadow-xl">
        <canvas ref={miniRef} width={240} height={70} className="block cursor-pointer" onClick={(e) => { const r = (e.target as HTMLCanvasElement).getBoundingClientRect(); camRef.current.x = ((e.clientX - r.left) / r.width) * eng.world.width; setFollow(false); }} />
      </div>

      {/* left: factions */}
      {leftOpen && (
        <div className={`${panel} left-3 top-[76px] w-[250px] max-h-[calc(100vh-100px)] overflow-auto p-2`}>
          <div className="flex items-center justify-between px-1 pb-1"><b className="text-sm text-white">陣営 (クリックで移動)</b><button className="text-slate-400 hover:text-white" onClick={() => setLeftOpen(false)}>✕</button></div>
          {FACTIONS.map((f) => {
            const c = snap?.counts[f.id] ?? 0; const st = snap?.stats[f.id];
            return (
              <button key={f.id} onClick={() => { jumpTo(f.id); setSpawnFid(f.id); setInfoFid(f.id); setInfoV(f.variants[0].key); }} className={`w-full grid grid-cols-[14px_1fr_auto] items-center gap-2 px-1.5 py-1 rounded-lg hover:bg-white/10 text-left ${c === 0 ? 'opacity-40' : ''}`}>
                <span className="w-3.5 h-3.5 rounded-full border" style={{ background: f.color, borderColor: f.outline ?? '#fff' }} />
                <span className="truncate">{f.name}<span className="block text-[9px] text-slate-400">K {st?.kills ?? 0} / 感染 {st?.infected ?? 0}</span></span>
                <b className="text-sm text-white tabular-nums">{c}</b>
              </button>
            );
          })}
        </div>
      )}

      {/* right panel */}
      {rightOpen && (
        <div className={`${panel} right-3 top-[76px] w-[320px] max-h-[calc(100vh-180px)] overflow-auto p-3`}>
          <div className="flex items-center gap-1 pb-2">
            {(['unit', 'spawn', 'info', 'log'] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`px-2 py-1 rounded-md text-xs font-bold ${tab === t ? 'bg-amber-400/20 text-amber-200 border border-amber-300/40' : 'bg-white/5 text-slate-300 hover:bg-white/10'}`}>
                {t === 'unit' ? '選択ユニット' : t === 'spawn' ? 'スポーン' : t === 'info' ? '図鑑' : 'ログ'}
              </button>
            ))}
            <button className="ml-auto text-slate-400 hover:text-white" onClick={() => setRightOpen(false)}>✕</button>
          </div>

          {tab === 'unit' && (
            !snap?.sel ? <div className="text-slate-400">キャンバス上のユニットをクリックすると詳細を表示します。</div> : (() => {
              const s = snap.sel; const f = FACTION_MAP.get(s.fid)!; const hp = Math.max(0, s.hp / s.maxHp);
              return (
                <div>
                  <div className="text-base font-black" style={{ color: f.outline && (f.color === '#101010' || f.color === '#0a0a0a' || f.color === '#1b1f22') ? f.outline : f.color }}>{s.name}</div>
                  <div className="text-slate-400">{f.name} / ID {s.id} / {s.state}{s.heldBy ? ' (拘束中)' : ''}{s.stun > 0 ? ' (よろめき)' : ''}</div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden my-1.5"><div className="h-full" style={{ width: `${hp * 100}%`, background: hp > 0.5 ? '#6bf26b' : hp > 0.25 ? '#ffd166' : '#ff5c5c' }} /></div>
                  <div className="grid grid-cols-4 gap-1 text-center">
                    {[['HP', `${Math.ceil(s.hp)}/${s.maxHp}`], ['ATK', s.atk.toFixed(1)], ['DEF', `${Math.round(s.def * 100)}%`], ['SPD', s.spd.toFixed(0)]].map(([k, v]) => <div key={k} className="bg-white/5 rounded-md py-1"><div className="text-[9px] text-slate-400">{k}</div><b className="text-white">{v}</b></div>)}
                  </div>
                  <div className="mt-2 text-slate-300">KILLS: <b className="text-white">{s.kills}</b>{s.adapt > 0 ? ` / 適応 ${Math.round(s.adapt * 100)}%` : ''}{s.biomass > 0 ? ` / 吸収 ${s.biomass}` : ''}</div>
                  {s.inf && <div className="mt-1 text-rose-300">感染: {s.inf} <span className="text-slate-400">({Math.round(s.infK * 100)}%)</span></div>}
                  {s.fear > 0 && <div className="text-amber-300">恐怖: {Math.round(s.fear)}%</div>}
                  {s.pollution > 0 && <div className="text-sky-300">A汚染: {Math.round(s.pollution)}%</div>}
                  {s.attack && <div className="mt-1 text-amber-200">攻撃中: <b>{s.attack}</b> <span className="text-slate-400">[{s.phase === 'windup' ? '予備動作' : s.phase === 'strike' ? '打撃' : '戻り'}]</span></div>}
                  <div className="mt-2 text-slate-400 font-bold">攻撃手段</div>
                  {s.cds.map((c) => (
                    <div key={c.name} className="flex items-center gap-2 py-0.5">
                      <span className="w-24 truncate text-slate-200">{c.name}</span>
                      <span className="text-[9px] text-slate-500 w-10">{KIND_LABEL[c.kind]}</span>
                      <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden"><div className="h-full bg-amber-300" style={{ width: `${(1 - c.cd / Math.max(0.01, c.max)) * 100}%` }} /></div>
                    </div>
                  ))}
                  <button className={`${btn} w-full mt-3`} onClick={() => setFollow(true)}>このユニットを追尾</button>
                </div>
              );
            })()
          )}

          {tab === 'spawn' && (
            <div className="space-y-2">
              <label className="block">陣営
                <select className="w-full mt-1 bg-slate-800 border border-slate-600 rounded-lg px-2 py-1.5" value={spawnFid} onChange={(e) => setSpawnFid(e.target.value)}>
                  {FACTIONS.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                </select>
              </label>
              <label className="block">出現数
                <input type="number" min={1} max={60} value={spawnCount} onChange={(e) => setSpawnCount(Math.max(1, Math.min(60, Number(e.target.value) || 1)))} className="w-full mt-1 bg-slate-800 border border-slate-600 rounded-lg px-2 py-1.5" />
              </label>
              <button className={`${btn} w-full`} onClick={() => { eng.spawnMany(spawnFid, spawnCount, null); jumpTo(spawnFid); }}>初期拠点に追加</button>
              <button className={`${btn} w-full`} onClick={() => { const cam = camRef.current; eng.spawnMany(spawnFid, spawnCount, { x: cam.x, z: eng.world.depth / 2 }); }}>画面中央に追加</button>
              <button className={`${btn} w-full`} onClick={() => { const s = eng.world.units.find((u) => u.id === eng.selectedId); if (s) eng.spawnMany(spawnFid, spawnCount, { x: s.x, z: s.z }); }}>選択ユニット付近に追加</button>
              <button className={`${btn} w-full !bg-rose-900/70 hover:!bg-rose-800`} onClick={() => { if (confirm(`${FACTION_MAP.get(spawnFid)?.name} を全て除去しますか？`)) eng.clearFaction(spawnFid); }}>選択陣営を除去</button>
              <div className="text-slate-400 pt-2 leading-relaxed">各陣営は時間経過で自ら増殖します（死体蘇生・巣・分裂）。感染や寄生を受けたユニットは一定時間後に相手陣営へ変異します。</div>
            </div>
          )}

          {tab === 'info' && (
            <div className="space-y-2">
              <select className="w-full bg-slate-800 border border-slate-600 rounded-lg px-2 py-1.5" value={infoFid} onChange={(e) => { setInfoFid(e.target.value); setInfoV(FACTION_MAP.get(e.target.value)!.variants[0].key); }}>
                {FACTIONS.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
              <div className="text-slate-300 leading-relaxed">{infoFaction.info}</div>
              <div className="flex flex-wrap gap-1">
                {infoFaction.variants.map((v) => <button key={v.key} onClick={() => setInfoV(v.key)} className={`px-2 py-0.5 rounded-md text-[11px] border ${infoVariant.key === v.key ? 'border-amber-300 text-amber-200 bg-amber-400/10' : 'border-white/10 text-slate-300 hover:bg-white/10'}`}>{v.name}</button>)}
              </div>
              <div className="bg-white/5 rounded-xl p-2">
                <div className="font-black text-white text-sm">{infoVariant.name}</div>
                <div className="grid grid-cols-4 gap-1 text-center my-1">
                  {[['HP', infoVariant.hp], ['ATK', infoVariant.atk], ['DEF', `${Math.round(infoVariant.def * 100)}%`], ['SPD', infoVariant.spd]].map(([k, v]) => <div key={String(k)} className="bg-black/30 rounded-md py-1"><div className="text-[9px] text-slate-400">{k}</div><b className="text-white">{v}</b></div>)}
                </div>
                <div className="text-slate-400 font-bold mt-1">攻撃手段 ({infoVariant.attacks.length})</div>
                {infoVariant.attacks.length === 0 && <div className="text-slate-500">なし（{infoVariant.desc}）</div>}
                {infoVariant.attacks.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 py-0.5 border-b border-white/5 last:border-0">
                    <span className="text-slate-100 font-bold w-28 truncate">{a.name}</span>
                    <span className="text-[10px] text-amber-200/80 w-10">{KIND_LABEL[a.kind]}</span>
                    <span className="text-[10px] text-slate-400">射程{a.range} / 威力x{a.dmg}{a.hits && a.hits > 1 ? ` x${a.hits}連` : ''}{a.aoe ? ' / 範囲' : ''}{a.effect ? ` / ${EFFECT_LABEL[a.effect] ?? a.effect}` : ''}</span>
                  </div>
                ))}
                {infoVariant.tags && infoVariant.tags.length > 0 && <div className="text-[10px] text-slate-500 mt-1">特性: {infoVariant.tags.join(', ')}</div>}
              </div>
              <button className={`${btn} w-full`} onClick={() => { const f = infoFaction; const cam = camRef.current; const v = infoVariant; for (let i = 0; i < 3; i++) eng.spawnAt(f, v, cam.x + (i - 1) * 40, eng.world.depth / 2); }}>このキャラを画面中央に3体召喚</button>
            </div>
          )}

          {tab === 'log' && (
            <div className="space-y-1">
              {(snap?.events ?? []).length === 0 && <div className="text-slate-500">まだイベントはありません。</div>}
              {(snap?.events ?? []).map((e, i) => <div key={i} className="text-slate-300 border-b border-white/5 pb-1">{e}</div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
