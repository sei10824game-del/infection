export type AttackKind =
  | 'slash' | 'stab' | 'smash' | 'bite' | 'tail' | 'tentacle' | 'charge' | 'pounce'
  | 'shoot' | 'spit' | 'gas' | 'explode' | 'grab' | 'flame' | 'slam' | 'spin'
  | 'throw' | 'punch' | 'kick' | 'whip' | 'drain' | 'spawn' | 'scream';

export type EffectTag =
  | 'tInfect' | 'gEmbryo' | 'cInfect' | 'plagaSeed' | 'uroSeed' | 'xenoEmbryo'
  | 'moldSpore' | 'cordySpore' | 'floodSpore' | 'necroInfect' | 'aGas' | 'burn'
  | 'fear' | 'pathogen' | 'assimilate' | 'eExposure' | 'abyssInfect' | 'veronica'
  | 'progenitor' | 'acid' | 'poison';

export interface AttackSpec {
  id: string;
  name: string;
  kind: AttackKind;
  range: number;
  minRange?: number;
  dmg: number;
  cd: number;
  windup: number;
  strike: number;
  recover: number;
  aoe?: number;
  knock?: number;
  stun?: number;
  hits?: number;
  effect?: EffectTag;
  hold?: boolean;
  heal?: boolean;
  spawnKey?: string;
  spawnCount?: number;
  weight?: number;
  color?: string;
  crit?: number;
}

export type BodyType = 'human' | 'hunched' | 'quad' | 'brute' | 'blob' | 'serpent' | 'floater' | 'crawler' | 'tall';
export type HeadType = 'zombie' | 'human' | 'xeno' | 'brain' | 'fungus' | 'split' | 'skull' | 'eyeless' | 'none' | 'maw' | 'dome' | 'hood';
export type Extra =
  | 'tail' | 'tongue' | 'tentacles' | 'bigArm' | 'eyeArm' | 'blades' | 'gun' | 'pitchfork'
  | 'axe' | 'saw' | 'spikes' | 'cores' | 'pods' | 'coat' | 'armor' | 'claws' | 'plates'
  | 'proboscis' | 'arms4' | 'glasses' | 'flames' | 'spores' | 'chain' | 'knife' | 'wings'
  | 'sac' | 'rags' | 'mycelium' | 'goo' | 'eyes' | 'bulge' | 'horns' | 'crown';

export interface Look {
  body: BodyType;
  size: number;
  skin: string;
  skin2?: string;
  cloth?: string;
  outline?: string;
  glow?: string;
  head: HeadType;
  extras?: Extra[];
}

export interface VariantDef {
  key: string;
  name: string;
  w: number;
  hp: number;
  atk: number;
  def: number;
  spd: number;
  radius: number;
  sight?: number;
  look: Look;
  attacks: AttackSpec[];
  tags?: string[];
  desc?: string;
}

export interface FactionDef {
  id: string;
  name: string;
  short: string;
  color: string;
  outline?: string;
  blood: string;
  initial: number;
  spawn: { x: number; z: number };
  variants: VariantDef[];
  growth: { every: number; count: number; cap: number; mode: 'corpse' | 'spawn' | 'nest' };
  info: string;
}

export interface Infection {
  tag: EffectTag;
  src: string;
  t: number;
  dur: number;
}

export interface ActiveAttack {
  spec: AttackSpec;
  t: number;
  targetId: number | null;
  hit: boolean;
  hitsDone: number;
  dir: number;
  tx: number;
  tz: number;
  sx: number;
  sz: number;
  spawnedFx?: boolean;
}

export interface Unit {
  id: number;
  fid: string;
  vkey: string;
  name: string;
  x: number;
  z: number;
  h: number;
  vx: number;
  vz: number;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  radius: number;
  sight: number;
  facing: 1 | -1;
  state: 'idle' | 'move' | 'attack' | 'channel';
  animT: number;
  moveT: number;
  attack: ActiveAttack | null;
  cds: Record<string, number>;
  targetId: number | null;
  corpseTarget: number | null;
  channelT: number;
  stun: number;
  hitT: number;
  hitDir: number;
  inf: Infection | null;
  pollution: number;
  fear: number;
  burn: number;
  acid: number;
  heldBy: number | null;
  kills: number;
  age: number;
  wanderT: number;
  wanderDir: number;
  aggro: number;
  lastHitBy: number | null;
  variant: VariantDef;
  look: Look;
  gForm?: number;
  biomass: number;
  adapt: number;
  regen: number;
  dead?: boolean;
}

export interface Corpse {
  id: number;
  fid: string;
  vkey: string;
  x: number;
  z: number;
  radius: number;
  life: number;
  facing: 1 | -1;
  look: Look;
  inf: Infection | null;
  claimedBy: string | null;
  claimT: number;
}

export interface Projectile {
  id: number;
  x: number;
  z: number;
  h: number;
  vx: number;
  vz: number;
  vh: number;
  owner: number;
  fid: string;
  spec: AttackSpec;
  dmg: number;
  life: number;
  kind: 'bullet' | 'spit' | 'throw' | 'spike' | 'fire';
  color: string;
  radius: number;
  gravity: boolean;
  trail: { x: number; z: number; h: number }[];
}

export interface Zone {
  id: number;
  x: number;
  z: number;
  radius: number;
  life: number;
  maxLife: number;
  fid: string;
  effect: EffectTag | 'damage';
  dps: number;
  color: string;
  kind: 'gas' | 'fire' | 'spore' | 'acid' | 'goo' | 'mycelium' | 'water';
}

export interface Particle {
  x: number;
  z: number;
  h: number;
  vx: number;
  vz: number;
  vh: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: 'blood' | 'dust' | 'spark' | 'smoke' | 'glow' | 'text' | 'ember' | 'chunk' | 'ring' | 'flash' | 'gore';
  text?: string;
  grav?: number;
  rot?: number;
  vr?: number;
}

export interface VisualFx {
  kind: 'arc' | 'thrust' | 'shock' | 'bitefx' | 'tether' | 'beam' | 'cone' | 'spinfx' | 'scream' | 'spawnfx';
  x: number;
  z: number;
  h: number;
  dir: number;
  t: number;
  dur: number;
  size: number;
  color: string;
  color2?: string;
  targetId?: number;
  ownerId?: number;
  angle0?: number;
  angle1?: number;
}

export interface Shake {
  t: number;
  amp: number;
}

export interface World {
  width: number;
  depth: number;
  units: Unit[];
  corpses: Corpse[];
  projectiles: Projectile[];
  zones: Zone[];
  particles: Particle[];
  fx: VisualFx[];
  time: number;
  nextId: number;
  winner: string | null;
  shake: Shake;
  nests: Record<string, { x: number; z: number; alive: boolean }>;
  growthTimers: Record<string, number>;
  stats: Record<string, { kills: number; spawned: number; infected: number }>;
  battle: boolean;
  events: string[];
}
