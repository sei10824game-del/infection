import { FACTIONS, FACTION_MAP, WORLD_D, WORLD_W, getVariant, EFFECT_LABEL } from './data';
import type {
  ActiveAttack, AttackSpec, Corpse, EffectTag, FactionDef, Infection, Particle, Projectile, Unit, VariantDef, VisualFx, World, Zone,
} from './types';

export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const chance = (p: number) => Math.random() < p;
const dist = (ax: number, az: number, bx: number, bz: number) => Math.hypot(ax - bx, (az - bz) * 1.6);

const INF_DUR: Record<string, number> = {
  tInfect: 55, veronica: 40, gEmbryo: 24, cInfect: 20, plagaSeed: 30, uroSeed: 14, xenoEmbryo: 28, moldSpore: 28,
  cordySpore: 38, floodSpore: 6, necroInfect: 40, pathogen: 28, assimilate: 18, eExposure: 32, abyssInfect: 28, progenitor: 30,
};

const ATTACK_PHASE_FX_COLOR: Record<string, string> = {
  slash: '#ffffff', stab: '#ffe6c0', smash: '#ffd080', bite: '#ff8080', tail: '#c0ffea', tentacle: '#e0a0ff', punch: '#fff0c0',
  kick: '#fff0c0', whip: '#ffb0b0', spin: '#ffffff', slam: '#ffc060',
};

export class Engine {
  world: World;
  selectedId: number | null = null;
  speed = 1;
  paused = false;
  private acc = 0;
  private retargetCursor = 0;

  constructor() {
    this.world = this.createWorld();
  }

  createWorld(): World {
    const w: World = {
      width: WORLD_W, depth: WORLD_D, units: [], corpses: [], projectiles: [], zones: [], particles: [], fx: [],
      time: 0, nextId: 1, winner: null, shake: { t: 0, amp: 0 }, nests: {}, growthTimers: {}, stats: {}, battle: false, events: [],
    };
    for (const f of FACTIONS) {
      w.nests[f.id] = { x: f.spawn.x, z: f.spawn.z, alive: true };
      w.growthTimers[f.id] = rand(0, f.growth.every);
      w.stats[f.id] = { kills: 0, spawned: 0, infected: 0 };
    }
    return w;
  }

  reset() {
    this.world = this.createWorld();
    this.selectedId = null;
    for (const f of FACTIONS) {
      const n = Math.round(f.initial * 0.75);
      for (let i = 0; i < n; i++) this.spawnAt(f, this.pickVariant(f), f.spawn.x + rand(-140, 140), f.spawn.z + rand(-70, 70));
    }
  }

  pickVariant(f: FactionDef, excludeSpecial = false): VariantDef {
    const list = f.variants.filter((v) => v.w > 0 && (!excludeSpecial || v.w >= 1));
    const tot = list.reduce((s, v) => s + v.w, 0);
    let r = Math.random() * tot;
    for (const v of list) { r -= v.w; if (r <= 0) return v; }
    return list[0];
  }

  baseVariant(f: FactionDef): VariantDef {
    return f.variants.reduce((a, b) => (b.w > a.w ? b : a));
  }

  spawnAt(f: FactionDef, v: VariantDef, x: number, z: number, hpRatio = 1): Unit {
    const w = this.world;
    const u: Unit = {
      id: w.nextId++, fid: f.id, vkey: v.key, name: v.name, x: clamp(x, 20, w.width - 20), z: clamp(z, 10, w.depth - 10), h: 0, vx: 0, vz: 0,
      hp: v.hp * hpRatio, maxHp: v.hp, atk: v.atk, def: v.def, spd: v.spd, radius: v.radius, sight: v.sight ?? 150,
      facing: x > w.width / 2 ? -1 : 1, state: 'idle', animT: rand(0, 10), moveT: 0, attack: null, cds: {}, targetId: null, corpseTarget: null,
      channelT: 0, stun: 0, hitT: 0, hitDir: 1, inf: null, pollution: 0, fear: 0, burn: 0, acid: 0, heldBy: null, kills: 0, age: 0,
      wanderT: 0, wanderDir: 1, aggro: 0, lastHitBy: null, variant: v, look: { ...v.look, extras: v.look.extras ? [...v.look.extras] : [] },
      biomass: 0, adapt: 0, regen: v.tags?.includes('regen') ? 4 : 0,
    };
    w.units.push(u);
    w.stats[f.id].spawned++;
    return u;
  }

  spawnMany(fid: string, count: number, near: { x: number; z: number } | null) {
    const f = FACTION_MAP.get(fid); if (!f) return;
    const base = near ?? f.spawn;
    for (let i = 0; i < count; i++) this.spawnAt(f, this.pickVariant(f), base.x + rand(-90, 90), base.z + rand(-50, 50));
    this.world.winner = null;
    this.text(base.x, base.z, `+${count}`, '#fff');
  }

  clearFaction(fid: string) {
    this.world.units = this.world.units.filter((u) => u.fid !== fid);
    this.world.winner = null;
  }

  forceBattle() { this.world.battle = true; for (const u of this.world.units) u.wanderT = 0; }

  log(msg: string) {
    const ev = this.world.events; ev.unshift(`[${this.world.time.toFixed(0)}s] ${msg}`); if (ev.length > 40) ev.length = 40;
  }

  // ---------- particles / fx ----------
  particle(p: Partial<Particle> & { x: number; z: number }) {
    const pr: Particle = { h: 0, vx: 0, vz: 0, vh: 0, life: 1, maxLife: 1, size: 3, color: '#fff', kind: 'dust', grav: 0, ...p } as Particle;
    pr.maxLife = pr.life;
    this.world.particles.push(pr);
  }
  text(x: number, z: number, text: string, color: string) {
    this.particle({ x, z, h: 40, vh: 30, life: 1.1, kind: 'text', text, color, size: 12 });
  }
  blood(x: number, z: number, h: number, color: string, n: number, power = 1, dir = 0) {
    for (let i = 0; i < n; i++) {
      const a = rand(-Math.PI, Math.PI);
      this.particle({ x, z, h: h + rand(-4, 4), vx: Math.cos(a) * rand(20, 90) * power + dir * 60 * power, vz: Math.sin(a) * rand(6, 25), vh: rand(40, 160) * power,
        life: rand(0.5, 1.1), size: rand(2, 4.5) * power, color, kind: 'blood', grav: 420 });
    }
  }
  gore(x: number, z: number, color: string, n: number) {
    for (let i = 0; i < n; i++) this.particle({ x, z, h: 12, vx: rand(-120, 120), vz: rand(-25, 25), vh: rand(120, 260), life: rand(0.8, 1.5), size: rand(3, 7), color, kind: 'chunk', grav: 520, rot: rand(0, 6), vr: rand(-10, 10) });
  }
  dust(x: number, z: number, n: number, power = 1, color = 'rgba(190,175,150,0.5)') {
    for (let i = 0; i < n; i++) this.particle({ x, z, h: 2, vx: rand(-60, 60) * power, vz: rand(-12, 12), vh: rand(10, 60) * power, life: rand(0.5, 1.0), size: rand(5, 11) * power, color, kind: 'dust', grav: 60 });
  }
  sparks(x: number, z: number, h: number, color: string, n: number) {
    for (let i = 0; i < n; i++) this.particle({ x, z, h, vx: rand(-160, 160), vz: rand(-20, 20), vh: rand(-40, 200), life: rand(0.2, 0.5), size: rand(1.5, 3), color, kind: 'spark', grav: 300 });
  }
  fx(f: Partial<VisualFx> & { kind: VisualFx['kind']; x: number; z: number }) {
    this.world.fx.push({ h: 0, dir: 1, t: 0, dur: 0.3, size: 30, color: '#fff', ...f } as VisualFx);
  }
  shake(amp: number) { const s = this.world.shake; s.amp = Math.max(s.amp, amp); s.t = Math.max(s.t, 0.25); }

  // ---------- main loop ----------
  step(frameDt: number) {
    if (this.paused) return;
    this.acc += frameDt * this.speed;
    const DT = 1 / 30; let n = 0;
    while (this.acc >= DT && n < 8) { this.update(DT); this.acc -= DT; n++; }
    if (n >= 8) this.acc = 0;
  }

  update(dt: number) {
    const w = this.world; w.time += dt;
    if (w.shake.t > 0) { w.shake.t -= dt; if (w.shake.t <= 0) w.shake.amp = 0; }
    this.updateUnits(dt);
    this.updateProjectiles(dt);
    this.updateZones(dt);
    this.updateCorpses(dt);
    this.updateGrowth(dt);
    this.updateParticles(dt);
    this.separate();
    this.checkWinner();
  }

  // ---------- targeting ----------
  private nearestEnemy(u: Unit, maxD: number): Unit | null {
    let best: Unit | null = null, bd = maxD;
    for (const o of this.world.units) {
      if (o === u || o.fid === u.fid || o.dead) continue;
      if (o.look.body === 'floater' && o.vkey === 'glasp' && u.fid !== 'tphobos' && chance(0.5)) continue;
      const d = dist(u.x, u.z, o.x, o.z) - o.radius;
      if (d < bd) { bd = d; best = o; }
    }
    return best;
  }
  private nearestCorpse(u: Unit, maxD: number): Corpse | null {
    let best: Corpse | null = null, bd = maxD;
    for (const c of this.world.corpses) {
      if (c.fid === u.fid || c.claimedBy) continue;
      const d = dist(u.x, u.z, c.x, c.z);
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }

  private updateUnits(dt: number) {
    const w = this.world;
    const byId = new Map<number, Unit>(); for (const u of w.units) byId.set(u.id, u);
    this.retargetCursor = (this.retargetCursor + 1) % 8;

    for (const u of w.units) {
      if (u.dead) continue;
      u.age += dt; u.animT += dt;
      for (const k in u.cds) if (u.cds[k] > 0) u.cds[k] -= dt;
      if (u.hitT > 0) u.hitT -= dt;
      if (u.stun > 0) u.stun -= dt;
      if (u.aggro > 0) u.aggro -= dt;
      if (u.regen > 0 && u.hp < u.maxHp) u.hp = Math.min(u.maxHp, u.hp + u.regen * dt);
      // status effects
      if (u.burn > 0) { u.burn -= dt; this.damage(u, 4 * dt, null, 'burn'); if (chance(dt * 12)) this.particle({ x: u.x + rand(-6, 6), z: u.z, h: rand(6, 30), vh: rand(30, 80), life: 0.5, size: rand(4, 8), color: '#ff8a20', kind: 'ember' }); }
      if (u.acid > 0) { u.acid -= dt; this.damage(u, 5 * dt, null, 'acid'); if (chance(dt * 6)) this.particle({ x: u.x + rand(-6, 6), z: u.z, h: rand(4, 24), vh: 20, life: 0.6, size: 3, color: '#c8ff3a', kind: 'glow' }); }
      if (u.pollution > 0 && u.fid !== 'avirus') { u.pollution = Math.max(0, u.pollution - dt * 1.5); }
      if (u.fear > 0 && u.fid !== 'tphobos') u.fear = Math.max(0, u.fear - dt * 2);
      this.updateInfection(u, dt);
      if (u.dead) continue;
      // cocoon stage
      if (u.variant.tags?.includes('cocoonStage')) {
        u.state = 'idle';
        if (u.age > 10) {
          const f = FACTION_MAP.get('cvirus')!; const keys = ['napad', 'strelats', 'lepotitsa', 'ubistvo'];
          const v = f.variants.find((x) => x.key === keys[Math.floor(Math.random() * keys.length)])!;
          this.transform(u, 'cvirus', v.key); this.log(`サナギが${v.name}へ羽化`); this.dust(u.x, u.z, 14, 1.4, 'rgba(240,200,120,0.6)');
        }
        continue;
      }
      // evolutions
      this.evolve(u);
      // velocity (knockback)
      if (Math.abs(u.vx) > 1 || Math.abs(u.vz) > 1) { u.x += u.vx * dt; u.z += u.vz * dt; u.vx *= 0.86; u.vz *= 0.86; }
      if (u.h > 0 && !u.attack) { u.h = Math.max(0, u.h - 300 * dt); }
      u.x = clamp(u.x, 15, w.width - 15); u.z = clamp(u.z, 8, w.depth - 8);

      if (u.heldBy != null) { const holder = byId.get(u.heldBy); if (!holder || holder.dead || !holder.attack?.spec.hold) u.heldBy = null; else { u.state = 'idle'; continue; } }
      if (u.stun > 0) { u.state = 'idle'; if (u.attack && !u.attack.spec.hold) u.attack = null; continue; }

      // attacking
      if (u.attack) { this.progressAttack(u, byId, dt); continue; }

      // corpse seekers
      if (u.variant.tags?.includes('corpseSeeker')) {
        if (u.corpseTarget != null) {
          const c = w.corpses.find((x) => x.id === u.corpseTarget);
          if (!c || (c.claimedBy && c.claimedBy !== u.fid)) { u.corpseTarget = null; u.state = 'idle'; }
          else {
            const d = dist(u.x, u.z, c.x, c.z);
            if (d < 14 + c.radius) {
              u.state = 'channel'; u.channelT += dt; c.claimedBy = u.fid; c.claimT = 4;
              if (chance(dt * 10)) this.particle({ x: c.x + rand(-8, 8), z: c.z, h: rand(2, 16), vh: 25, life: 0.7, size: 3, color: FACTION_MAP.get(u.fid)!.outline || FACTION_MAP.get(u.fid)!.color, kind: 'glow' });
              if (u.channelT > 2.2) {
                u.channelT = 0; u.corpseTarget = null;
                this.reanimateCorpse(c, u.fid, u.fid === 'necro' ? 'slasher' : 'combat');
                if (u.fid === 'flood') { this.removeUnit(u); continue; }
              }
              continue;
            } else { this.moveToward(u, c.x, c.z, dt); u.state = 'move'; continue; }
          }
        } else if ((u.id + this.retargetCursor) % 8 === 0) {
          const c = this.nearestCorpse(u, 320); if (c && chance(0.7)) { u.corpseTarget = c.id; }
        }
      }

      // retarget
      let target = u.targetId != null ? byId.get(u.targetId) : null;
      if (target?.dead) target = null;
      if (!target || (u.id + this.retargetCursor) % 8 === 0) {
        const ag = u.lastHitBy != null && u.aggro > 0 ? byId.get(u.lastHitBy) : null;
        if (ag && !ag.dead && dist(u.x, u.z, ag.x, ag.z) < u.sight * 1.6) target = ag;
        else {
          const near = this.nearestEnemy(u, target ? dist(u.x, u.z, target.x, target.z) - 5 : (w.battle ? 99999 : u.sight * 2.2));
          if (near) target = near;
        }
      }
      u.targetId = target ? target.id : null;
      if (!target) { this.wander(u, dt); continue; }

      // fear: afraid units flee
      if (u.fear > 55 && u.fid !== 'tphobos') { this.moveToward(u, u.x - (target.x - u.x), u.z, dt); u.state = 'move'; continue; }

      const d = dist(u.x, u.z, target.x, target.z) - target.radius;
      const dir = target.x >= u.x ? 1 : -1;
      // choose attack
      const ready = u.variant.attacks.filter((a) => (u.cds[a.id] ?? 0) <= 0);
      const inRange = ready.filter((a) => d <= a.range + u.radius && d >= (a.minRange ?? 0) && (a.kind !== 'spawn' || d < 220));
      if (inRange.length) {
        const pick = inRange[Math.floor(Math.random() * inRange.length)];
        this.startAttack(u, pick, target, dir);
        continue;
      }
      // any attack in range but on cd -> wait
      const usable = u.variant.attacks.filter((a) => a.kind !== 'spawn' && a.kind !== 'scream');
      const anyRange = usable.some((a) => d <= a.range + u.radius);
      let minReach = usable.length ? Math.min(...usable.map((a) => a.range)) : 30;
      if (!isFinite(minReach)) minReach = 30;
      const hasRanged = usable.some((a) => a.range >= 120);
      if (anyRange && (hasRanged || d < minReach + u.radius + 6)) { u.state = 'idle'; u.facing = dir; continue; }
      this.moveToward(u, target.x - dir * (minReach * 0.5), target.z, dt); u.state = 'move';
    }
    // cleanup dead
    if (w.units.some((u) => u.dead)) w.units = w.units.filter((u) => !u.dead);
  }

  private wander(u: Unit, dt: number) {
    u.wanderT -= dt;
    if (u.wanderT <= 0) {
      u.wanderT = rand(1.5, 4); u.vz = rand(-6, 6);
      const toCenter = u.x < this.world.width / 2 ? 1 : -1;
      u.wanderDir = chance(0.3) ? 0 : (chance(0.62) ? toCenter : -toCenter);
    }
    if (u.wanderDir === 0) { u.state = 'idle'; return; }
    const f = FACTION_MAP.get(u.fid)!;
    const tx = u.x + u.wanderDir * 50; const tz = u.z + (this.world.battle ? 0 : (f.spawn.z - u.z) * 0.1);
    this.moveToward(u, tx, tz, dt, 0.45); u.state = 'move';
  }

  private moveToward(u: Unit, tx: number, tz: number, dt: number, mult = 1) {
    const dx = tx - u.x, dz = tz - u.z; const len = Math.hypot(dx, dz) || 1;
    const spd = u.spd * mult * (u.fear > 30 ? 1.2 : 1);
    u.x += (dx / len) * spd * dt; u.z += (dz / len) * spd * dt * 0.7;
    if (Math.abs(dx) > 2) u.facing = dx > 0 ? 1 : -1;
    u.moveT += dt * spd / 30;
  }

  // ---------- attacks ----------
  private startAttack(u: Unit, spec: AttackSpec, target: Unit, dir: 1 | -1) {
    u.facing = dir; u.state = 'attack';
    u.cds[spec.id] = spec.cd + rand(0, 0.4);
    u.attack = { spec, t: 0, targetId: target.id, hit: false, hitsDone: 0, dir, tx: target.x, tz: target.z, sx: u.x, sz: u.z };
  }

  private progressAttack(u: Unit, byId: Map<number, Unit>, dt: number) {
    const a = u.attack!; const s = a.spec; a.t += dt;
    const target = a.targetId != null ? byId.get(a.targetId) : undefined;
    const tgt = target && !target.dead ? target : undefined;
    const tW = s.windup, tS = tW + s.strike, tE = tS + s.recover;
    if (tgt && a.t < tW && s.kind !== 'pounce' && s.kind !== 'charge') { a.tx = tgt.x; a.tz = tgt.z; u.facing = tgt.x >= u.x ? 1 : -1; a.dir = u.facing; }
    if (a.t >= tW && a.t < tS) {
      const p = (a.t - tW) / s.strike;
      this.strikePhase(u, a, tgt, p, dt);
    } else if (a.t >= tS && !a.hit && s.kind === 'pounce') {
      this.landPounce(u, a);
    }
    if (a.t >= tE) { this.endAttack(u); }
  }

  private endAttack(u: Unit) {
    const a = u.attack; if (!a) return;
    if (a.spec.hold && a.targetId != null) { const t = this.world.units.find((x) => x.id === a.targetId); if (t && t.heldBy === u.id) t.heldBy = null; }
    u.attack = null; u.state = 'idle'; u.h = 0;
  }

  private strikePhase(u: Unit, a: ActiveAttack, tgt: Unit | undefined, p: number, dt: number) {
    const s = a.spec; const w = this.world; const f = FACTION_MAP.get(u.fid)!;
    const dir = a.dir; const reach = (s.range + u.radius);
    const hx = u.x + dir * reach * 0.6, hz = u.z;
    const hits = s.hits ?? 1;
    const wantHits = Math.min(hits, Math.floor(p * hits + 1e-6) + 1);

    switch (s.kind) {
      case 'slash': case 'stab': case 'smash': case 'bite': case 'tail': case 'tentacle': case 'punch': case 'kick': case 'whip': case 'slam': case 'spin': {
        if (!a.spawnedFx) {
          a.spawnedFx = true;
          const col = s.color ?? ATTACK_PHASE_FX_COLOR[s.kind] ?? '#fff';
          if (s.kind === 'slash' || s.kind === 'tail' || s.kind === 'tentacle' || s.kind === 'whip') this.fx({ kind: 'arc', x: u.x, z: u.z, h: u.radius * 2.2, dir, dur: s.strike + 0.12, size: reach, color: col, color2: f.outline || f.color, angle0: -1.4, angle1: 1.1 });
          else if (s.kind === 'stab' || s.kind === 'punch' || s.kind === 'kick' || s.kind === 'bite') this.fx({ kind: 'thrust', x: u.x, z: u.z, h: u.radius * 2, dir, dur: s.strike + 0.1, size: reach, color: col });
          else if (s.kind === 'smash' || s.kind === 'slam') { this.fx({ kind: 'shock', x: hx, z: hz, dir, dur: 0.45, size: s.aoe ?? 40, color: col }); this.dust(hx, hz, 12, 1.4); this.shake(s.kind === 'slam' ? 9 : 5); }
          else if (s.kind === 'spin') this.fx({ kind: 'spinfx', x: u.x, z: u.z, h: u.radius * 2, dir, dur: s.strike, size: reach, color: col, ownerId: u.id });
        }
        while (a.hitsDone < wantHits) {
          a.hitsDone++;
          if (s.kind === 'spin' || s.kind === 'slam' || s.kind === 'smash' || (s.aoe && s.aoe > 0)) {
            const cx = s.kind === 'spin' ? u.x : hx, cz = s.kind === 'spin' ? u.z : hz;
            const r = (s.aoe ?? 30) + u.radius;
            let any = false;
            for (const o of w.units) { if (o.fid === u.fid || o.dead) continue; if (dist(o.x, o.z, cx, cz) < r + o.radius) { this.hit(u, o, s, 1); any = true; } }
            if (!any && tgt && dist(u.x, u.z, tgt.x, tgt.z) < reach + 14) this.hit(u, tgt, s, 1);
          } else if (tgt) {
            if (dist(u.x, u.z, tgt.x, tgt.z) - tgt.radius < reach + 16) this.hit(u, tgt, s, 1);
            else this.fx({ kind: 'thrust', x: u.x, z: u.z, h: u.radius, dir, dur: 0.2, size: 10, color: 'rgba(255,255,255,0.2)' });
          }
        }
        break;
      }
      case 'charge': {
        const spd = u.spd * 4.5 + 220;
        u.x += dir * spd * dt; u.x = clamp(u.x, 15, w.width - 15);
        u.moveT += dt * 8;
        if (chance(dt * 30)) this.dust(u.x - dir * u.radius, u.z, 1, 1.1);
        for (const o of w.units) {
          if (o.fid === u.fid || o.dead) continue;
          if (dist(u.x, u.z, o.x, o.z) < u.radius + o.radius + 10 && (o.hitT <= 0 || o.lastHitBy !== u.id)) { this.hit(u, o, s, 1); o.lastHitBy = u.id; this.shake(4); }
        }
        break;
      }
      case 'pounce': {
        const k = Math.min(1, p);
        u.x = a.sx + (a.tx - a.sx) * k; u.z = a.sz + (a.tz - a.sz) * k;
        u.h = Math.sin(k * Math.PI) * (40 + reach * 0.25);
        if (p >= 0.98 && !a.hit) this.landPounce(u, a);
        break;
      }
      case 'shoot': {
        while (a.hitsDone < wantHits) {
          a.hitsDone++;
          const tx = tgt ? tgt.x : a.tx, tz = tgt ? tgt.z : a.tz;
          const dx = tx - u.x, dz = tz - u.z; const L = Math.hypot(dx, dz) || 1; const v = 520;
          this.world.projectiles.push({ id: w.nextId++, x: u.x + dir * u.radius, z: u.z, h: u.radius * 2.4, vx: (dx / L) * v + rand(-20, 20), vz: (dz / L) * v * 0.6, vh: rand(-8, 8), owner: u.id, fid: u.fid, spec: s, dmg: 1, life: 1.2,
            kind: s.id.includes('barb') || s.id.includes('spike') ? 'spike' : 'bullet', color: u.fid === 'cvirus' || s.id === 'fc_shoot' ? '#ffe28a' : '#e0d0a0', radius: 5, gravity: false, trail: [] });
          this.fx({ kind: 'thrust', x: u.x + dir * u.radius, z: u.z, h: u.radius * 2.4, dir, dur: 0.08, size: 14, color: '#ffe0a0' });
          this.sparks(u.x + dir * u.radius * 1.5, u.z, u.radius * 2.4, '#ffd070', 3);
        }
        break;
      }
      case 'spit': case 'throw': {
        while (a.hitsDone < wantHits) {
          a.hitsDone++;
          const tx = (tgt ? tgt.x : a.tx) + rand(-15, 15), tz = (tgt ? tgt.z : a.tz) + rand(-8, 8);
          const dx = tx - u.x, dz = tz - u.z; const T = clamp(Math.hypot(dx, dz) / 260, 0.35, 1.0);
          const h0 = u.radius * 2.4; const g = 700;
          this.world.projectiles.push({ id: w.nextId++, x: u.x, z: u.z, h: h0, vx: dx / T, vz: dz / T, vh: (g * T) / 2 - h0 / T, owner: u.id, fid: u.fid, spec: s, dmg: 1, life: T + 0.05,
            kind: s.kind === 'throw' ? 'throw' : (s.effect === 'burn' ? 'fire' : 'spit'), color: s.effect === 'acid' ? '#c8ff3a' : s.effect === 'burn' ? '#ff9030' : s.effect === 'cordySpore' ? '#e0c070' : s.effect === 'plagaSeed' ? '#d6c542' : (f.outline || f.color), radius: s.kind === 'throw' ? 8 : 6, gravity: true, trail: [] });
        }
        break;
      }
      case 'gas': {
        if (!a.spawnedFx) {
          a.spawnedFx = true;
          const col = s.effect === 'acid' ? 'rgba(200,255,60,0.35)' : s.effect === 'fear' ? 'rgba(255,204,136,0.3)' : s.effect === 'poison' ? 'rgba(170,80,200,0.35)' : s.effect === 'eExposure' ? 'rgba(230,230,230,0.35)' : s.effect === 'floodSpore' ? 'rgba(180,200,90,0.35)' : 'rgba(159,184,198,0.35)';
          this.zone({ x: u.x + dir * 20, z: u.z, radius: s.aoe ?? 80, life: 9, fid: u.fid, effect: s.effect ?? 'damage', dps: u.atk * s.dmg, color: col, kind: s.effect === 'acid' ? 'acid' : 'gas' });
        }
        break;
      }
      case 'flame': {
        if (chance(dt * 60)) {
          for (let i = 0; i < 3; i++) this.particle({ x: u.x + dir * u.radius, z: u.z + rand(-4, 4), h: u.radius * 2.2 + rand(-4, 4), vx: dir * rand(180, 320), vz: rand(-30, 30), vh: rand(-10, 50), life: rand(0.3, 0.5), size: rand(6, 12), color: chance(0.5) ? '#ff8a20' : '#ffd060', kind: 'ember', grav: -80 });
        }
        if (a.hitsDone < Math.floor(p * 8)) {
          a.hitsDone++;
          for (const o of w.units) {
            if (o.fid === u.fid || o.dead) continue;
            const dx = (o.x - u.x) * dir, dz = Math.abs(o.z - u.z);
            if (dx > 0 && dx < reach && dz < 18 + dx * 0.35) this.hit(u, o, s, 0.5);
          }
        }
        break;
      }
      case 'explode': {
        if (!a.hit) {
          a.hit = true;
          this.explode(u.x, u.z, s.aoe ?? 80, u.atk * s.dmg, u, s);
          if (s.spawnKey) { const v = getVariant(u.fid, s.spawnKey); if (v) for (let i = 0; i < (s.spawnCount ?? 1); i++) this.spawnAt(f, v, u.x + rand(-30, 30), u.z + rand(-15, 15)); }
          this.kill(u, null, true);
        }
        break;
      }
      case 'grab': case 'drain': {
        if (!a.hit) {
          a.hit = true;
          if (tgt && dist(u.x, u.z, tgt.x, tgt.z) - tgt.radius < reach + 14 && tgt.maxHp < 900) {
            tgt.heldBy = u.id; tgt.stun = 0; tgt.facing = (-dir) as 1 | -1; tgt.x = u.x + dir * (u.radius + tgt.radius + 2); tgt.z = u.z + 2;
            this.fx({ kind: 'tether', x: u.x, z: u.z, h: u.radius * 2, dir, dur: s.strike, size: 10, color: f.outline || f.color, targetId: tgt.id, ownerId: u.id });
          } else { a.hitsDone = 99; }
        }
        if (a.hitsDone < 99 && tgt && tgt.heldBy === u.id) {
          const ticks = Math.floor(p * 4 + 1e-6) + 1;
          while (a.hitsDone < Math.min(4, ticks)) {
            a.hitsDone++;
            const last = a.hitsDone === 4;
            this.hit(u, tgt, s, last ? 1 : 0.35, !last);
            if (s.heal) { u.hp = Math.min(u.maxHp, u.hp + u.maxHp * 0.06); this.particle({ x: tgt.x, z: tgt.z, h: 20, vx: -dir * 60, vh: 30, life: 0.5, size: 4, color: '#ff4a4a', kind: 'glow' }); }
            if (last && s.knock) { tgt.vx = dir * s.knock * 4; tgt.h = 20; tgt.heldBy = null; }
          }
        } else if (a.hitsDone >= 99) { a.t = Math.max(a.t, s.windup + s.strike); }
        break;
      }
      case 'spawn': {
        if (!a.hit) {
          a.hit = true;
          const v = s.spawnKey ? getVariant(u.fid, s.spawnKey) : null;
          if (v) { for (let i = 0; i < (s.spawnCount ?? 1); i++) { const c = this.spawnAt(f, v, u.x + rand(-40, 40), u.z + rand(-20, 20)); c.h = 20; } this.fx({ kind: 'spawnfx', x: u.x, z: u.z, dur: 0.6, size: u.radius * 3, color: f.outline || f.color }); this.log(`${u.name}が${v.name}を生み出した`); }
        }
        break;
      }
      case 'scream': {
        if (!a.hit) {
          a.hit = true;
          this.fx({ kind: 'scream', x: u.x, z: u.z, h: u.radius * 2.4, dur: 0.7, size: s.aoe ?? 120, color: s.color ?? f.outline ?? f.color });
          this.shake(4);
          for (const o of w.units) { if (o.fid === u.fid || o.dead) continue; if (dist(o.x, o.z, u.x, u.z) < (s.aoe ?? 120) + o.radius) { this.hit(u, o, s, 1); if (s.effect === 'fear') o.fear += 40; } }
        }
        break;
      }
    }
  }

  private landPounce(u: Unit, a: ActiveAttack) {
    a.hit = true; u.h = 0; const s = a.spec; const w = this.world;
    this.dust(u.x, u.z, 10, 1.2); this.shake(3);
    this.fx({ kind: 'shock', x: u.x, z: u.z, dur: 0.3, size: (s.aoe ?? 30) + 10, color: 'rgba(255,255,255,0.7)' });
    for (const o of w.units) { if (o.fid === u.fid || o.dead) continue; if (dist(o.x, o.z, u.x, u.z) < (s.aoe ?? 30) + u.radius + o.radius) this.hit(u, o, s, 1); }
  }

  private explode(x: number, z: number, r: number, dmg: number, src: Unit | null, s: AttackSpec | null) {
    const w = this.world;
    this.fx({ kind: 'shock', x, z, dur: 0.5, size: r, color: '#ffb060' });
    this.particle({ x, z, h: 10, life: 0.25, size: r * 0.8, color: '#fff2c0', kind: 'flash' });
    for (let i = 0; i < 18; i++) this.particle({ x, z, h: 8, vx: rand(-200, 200), vz: rand(-30, 30), vh: rand(40, 260), life: rand(0.4, 0.9), size: rand(6, 14), color: chance(0.5) ? '#ff7a20' : '#ffc040', kind: 'ember', grav: 100 });
    for (let i = 0; i < 10; i++) this.particle({ x, z, h: 8, vx: rand(-90, 90), vz: rand(-10, 10), vh: rand(20, 90), life: rand(0.8, 1.5), size: rand(10, 20), color: 'rgba(60,50,45,0.5)', kind: 'smoke', grav: -20 });
    this.shake(12);
    for (const o of w.units) {
      if (o.dead || (src && o === src)) continue;
      const d = dist(o.x, o.z, x, z);
      if (d < r + o.radius) {
        const fall = 1 - (d / (r + o.radius)) * 0.6;
        this.damage(o, dmg * fall * (1 - o.def), src, 'explosion');
        o.vx = ((o.x - x) / (Math.abs(o.x - x) + 1)) * 260 * fall; o.h = 30 * fall; o.stun = Math.max(o.stun, 0.8 * fall);
        if (s?.effect) this.applyEffect(src, o, s.effect);
      }
    }
  }

  private hit(u: Unit, o: Unit, s: AttackSpec, mult: number, light = false) {
    const f = FACTION_MAP.get(u.fid)!;
    const dir = o.x >= u.x ? 1 : -1;
    let dmg = u.atk * s.dmg * mult * rand(0.85, 1.15);
    let crit = false;
    if (s.crit && chance(s.crit)) { dmg *= 2.2; crit = true; }
    if (o.variant.tags?.includes('adaptDmg')) { dmg *= 1 - Math.min(0.45, o.adapt); o.adapt += 0.02; }
    dmg *= 1 - o.def;
    this.damage(o, dmg, u, s.kind, crit);
    if (!light) {
      const fo = FACTION_MAP.get(o.fid)!;
      this.blood(o.x, o.z, o.radius * 1.8, fo.blood, crit ? 14 : 6, crit ? 1.4 : 1, dir);
      this.particle({ x: o.x + dir * 4, z: o.z, h: o.radius * 2, life: 0.12, size: 14 + (crit ? 10 : 0), color: '#fff', kind: 'flash' });
      if (s.knock) { o.vx = dir * s.knock * 3.2; if (s.knock > 50) o.h = 14; }
      if (s.stun) o.stun = Math.max(o.stun, s.stun * (o.maxHp > 400 ? 0.4 : 1));
      if (s.kind === 'smash' || s.kind === 'slam' || s.kind === 'charge' || s.kind === 'kick') this.shake(4);
      // acid blood retaliation
      if (o.variant.tags?.includes('acidBlood') && s.range <= 60 && !s.hold) { u.acid = Math.max(u.acid, 1.4); this.sparks(u.x, u.z, u.radius * 2, '#c8ff3a', 4); }
    }
    if (s.effect) this.applyEffect(u, o, s.effect);
    if (u.variant.tags?.includes('adapt') && u.hp < u.maxHp) u.hp = Math.min(u.maxHp, u.hp + dmg * 0.08);
    void f;
  }

  damage(o: Unit, dmg: number, src: Unit | null, kind: string, crit = false) {
    if (o.dead) return;
    o.hp -= dmg;
    if (src) { o.hitT = 0.28; o.hitDir = o.x >= src.x ? 1 : -1; o.lastHitBy = src.id; o.aggro = 6; if (kind !== 'burn' && kind !== 'acid') o.animT += 0.01; }
    if (src && dmg > 3) this.text(o.x + rand(-8, 8), o.z, `${Math.round(dmg)}${crit ? '!' : ''}`, crit ? '#ffd24a' : '#ffffff');
    if (o.hp <= 0) this.kill(o, src);
  }

  applyEffect(src: Unit | null, o: Unit, tag: EffectTag) {
    if (tag === 'burn') { o.burn = Math.max(o.burn, 4); return; }
    if (tag === 'acid' || tag === 'poison') { o.acid = Math.max(o.acid, 3.5); return; }
    if (tag === 'fear') { if (o.fid !== 'tphobos') { o.fear = Math.min(130, o.fear + 25); if (o.fear >= 100 && o.maxHp < 350) { this.transform(o, 'tphobos', 'afflicted'); this.log(`恐怖に呑まれた${o.name}がアフリクテッド化`); } } return; }
    if (tag === 'aGas') { if (o.fid !== 'avirus') { o.pollution = Math.min(120, o.pollution + 22); if (o.pollution >= 100 && o.maxHp < 350) { this.transform(o, 'avirus', 'azombie'); this.log(`A汚染が発症、A感染者化`); } } return; }
    if (!src || src.fid === o.fid || o.inf || o.maxHp >= 350) return;
    if (o.fid === 'progenitor' && o.vkey === 'adapted' && chance(0.7)) return;
    const dur = INF_DUR[tag] ?? 30;
    if (chance(0.75)) {
      o.inf = { tag, src: src.fid, t: 0, dur } as Infection;
      this.world.stats[src.fid].infected++;
      this.text(o.x, o.z - 4, EFFECT_LABEL[tag] ?? tag, FACTION_MAP.get(src.fid)!.outline || FACTION_MAP.get(src.fid)!.color);
    }
  }

  private updateInfection(u: Unit, dt: number) {
    const inf = u.inf; if (!inf) return;
    inf.t += dt;
    if (inf.tag === 'tInfect' || inf.tag === 'cordySpore' || inf.tag === 'necroInfect' || inf.tag === 'veronica') this.damage(u, 0.6 * dt, null, 'inf');
    if (inf.tag === 'uroSeed' || inf.tag === 'gEmbryo') this.damage(u, 1.5 * dt, null, 'inf');
    if (u.dead) return;
    if (chance(dt * 1.5)) { const f = FACTION_MAP.get(inf.src)!; this.particle({ x: u.x + rand(-6, 6), z: u.z, h: rand(10, 30), vh: 18, life: 0.7, size: 2.5, color: f.outline || f.color, kind: 'glow' }); }
    if (inf.t < inf.dur) return;
    const src = inf.src; const f = FACTION_MAP.get(src)!;
    const burst = (vkey: string, n = 1) => {
      this.log(`${u.name}の体内から${getVariant(src, vkey)?.name}が飛び出した`);
      for (let i = 0; i < n; i++) { const c = this.spawnAt(f, getVariant(src, vkey)!, u.x + rand(-10, 10), u.z + rand(-5, 5), 0.75); c.h = 25; c.vx = rand(-60, 60); }
      this.gore(u.x, u.z, FACTION_MAP.get(u.fid)!.blood, 8);
      this.kill(u, null, true);
    };
    const conv = (vkey: string) => { const v = getVariant(src, vkey); if (!v) return; this.log(`${u.name}が${v.name}に変異`); this.transform(u, src, vkey); };
    switch (inf.tag) {
      case 'tInfect': conv('zombie'); break;
      case 'veronica': conv('vinfected'); break;
      case 'gEmbryo': burst('gadult'); break;
      case 'cInfect': conv('cocoon'); break;
      case 'plagaSeed': conv(chance(0.75) ? 'ganado' : 'exposed'); break;
      case 'uroSeed': burst('umass'); break;
      case 'xenoEmbryo': burst(src === 'pathogen' ? 'deacon' : 'drone'); break;
      case 'moldSpore': conv('molded'); break;
      case 'cordySpore': conv('runner'); break;
      case 'floodSpore': conv('combat'); break;
      case 'necroInfect': conv('slasher'); break;
      case 'pathogen': burst(chance(0.5) ? 'hammerpede' : 'neomorph'); break;
      case 'assimilate': { const oldLook = { ...u.look }; conv('imitation'); u.look = { ...oldLook, glow: '#ff6a6a', extras: [...(oldLook.extras ?? []), 'tentacles'] }; break; }
      case 'eExposure': conv('emold'); break;
      case 'abyssInfect': conv('ooze'); break;
      case 'progenitor': conv(chance(0.2) ? 'adapted' : 'feral'); break;
      default: u.inf = null;
    }
  }

  transform(u: Unit, fid: string, vkey: string, hpRatio = 1) {
    const f = FACTION_MAP.get(fid)!; const v = getVariant(fid, vkey)!;
    const old = u.fid;
    u.fid = fid; u.vkey = vkey; u.name = v.name; u.variant = v; u.look = { ...v.look, extras: v.look.extras ? [...v.look.extras] : [] };
    u.maxHp = v.hp; u.hp = v.hp * hpRatio; u.atk = v.atk; u.def = v.def; u.spd = v.spd; u.radius = v.radius; u.sight = v.sight ?? 150;
    u.inf = null; u.pollution = 0; u.fear = 0; u.attack = null; u.cds = {}; u.targetId = null; u.heldBy = null; u.stun = 0.6; u.age = 0; u.state = 'idle';
    u.regen = v.tags?.includes('regen') ? 4 : 0; u.adapt = 0; u.biomass = 0;
    if (old !== fid) this.world.stats[fid].spawned++;
    this.fx({ kind: 'spawnfx', x: u.x, z: u.z, dur: 0.7, size: u.radius * 3, color: f.outline || f.color });
    this.blood(u.x, u.z, u.radius * 2, FACTION_MAP.get(old)!.blood, 8, 1);
    this.text(u.x, u.z - 10, `→${v.name}`, f.outline || f.color);
  }

  private evolve(u: Unit) {
    const tags = u.variant.tags ?? [];
    if (!tags.length) return;
    if (tags.includes('lickerMut') && u.kills >= 3 && chance(0.004)) { this.transform(u, 'tvirus', 'licker'); this.log('ゾンビがリッカーへ変異'); return; }
    if (tags.includes('adaptable') && u.kills >= 2 && chance(0.003)) { this.transform(u, 'progenitor', 'adapted'); this.log('不適合者が適応進化し適合者へ'); return; }
    if (tags.includes('cordyEvolve')) {
      if (u.vkey === 'runner' && u.age > 45 && chance(0.002)) { this.transform(u, 'cordyceps', chance(0.6) ? 'clicker' : 'stalker', 1); return; }
      if (u.vkey === 'clicker' && u.age > 70 && chance(0.0012)) { this.transform(u, 'cordyceps', chance(0.6) ? 'bloater' : 'shambler', 1); return; }
    }
    if (tags.includes('absorb')) {
      if (u.vkey === 'umass' && u.biomass >= 5) { this.transform(u, 'uroboros', 'aheri', 1); this.log('ウロボロスが死体を取り込み巨大化(アヘリ)'); return; }
      if (chance(0.06)) {
        const c = this.nearestCorpse(u, 60);
        if (c) { this.world.corpses = this.world.corpses.filter((x) => x !== c); u.biomass += 1; u.hp = Math.min(u.maxHp, u.hp + 25); this.text(u.x, u.z, '吸収', '#ff7a1a'); this.particle({ x: c.x, z: c.z, h: 6, life: 0.4, size: 20, color: 'rgba(255,122,26,0.5)', kind: 'flash' }); }
      }
    }
    if (tags.includes('adaptDmg') && u.vkey === 'imitation' && u.kills >= 4 && chance(0.004)) { this.transform(u, 'parasites', 'abomination'); this.log('SRP擬態体がバイオマスを蓄え合体体へ'); }
  }

  kill(u: Unit, killer: Unit | null, silent = false) {
    if (u.dead) return;
    const w = this.world; const f = FACTION_MAP.get(u.fid)!; const tags = u.variant.tags ?? [];
    if (killer && !killer.dead) { killer.kills++; w.stats[killer.fid].kills++; if (killer.variant.tags?.includes('adapt')) killer.atk += 0.4; }
    // death-triggered transformations (revive in place)
    const gf = tags.find((t) => t.startsWith('gform:'));
    if (gf) { const n = Number(gf.split(':')[1]); if (n < 5 && chance(0.5)) { this.transform(u, 'gvirus', `g${n + 1}`, 1); this.log(`G第${n}形態が第${n + 1}形態へ変異`); this.shake(6); return; } }
    if (tags.includes('cocoon') && chance(0.4)) { this.transform(u, 'cvirus', 'cocoon', 1); this.log('ジュアヴォがサナギ化'); return; }
    if (tags.includes('plagaExpose') && chance(0.35)) { this.transform(u, 'plaga', 'exposed', 0.7); this.log('ガナードの頭部から寄生体が露出'); return; }
    u.dead = true;
    if (u.attack?.spec.hold) this.endAttack(u);
    if (this.selectedId === u.id) this.selectedId = null;
    if (!silent) { this.blood(u.x, u.z, u.radius * 1.5, f.blood, 12, 1.3); this.gore(u.x, u.z, f.blood, 4); }
    if (tags.includes('gasDeath') || (u.fid !== 'avirus' && u.pollution > 40)) this.zone({ x: u.x, z: u.z, radius: 55, life: 7, fid: 'avirus', effect: 'aGas', dps: 2, color: 'rgba(159,184,198,0.35)', kind: 'gas' });
    if (tags.includes('explodeDeath')) this.explode(u.x, u.z, 70, u.atk * 2.2, u, null);
    if (tags.includes('acidBlood')) this.zone({ x: u.x, z: u.z, radius: 22, life: 4, fid: u.fid, effect: 'acid', dps: 6, color: 'rgba(200,255,60,0.35)', kind: 'acid' });
    if (u.fid === 'cordyceps' && chance(0.3)) this.zone({ x: u.x, z: u.z, radius: 40, life: 12, fid: 'cordyceps', effect: 'cordySpore', dps: 1, color: 'rgba(210,190,120,0.3)', kind: 'spore' });
    if (u.fid === 'pathogen') this.zone({ x: u.x, z: u.z, radius: 30, life: 10, fid: 'pathogen', effect: 'pathogen', dps: 1, color: 'rgba(10,10,10,0.55)', kind: 'goo' });
    // corpse
    let inf: Infection | null = u.inf;
    if (u.fid !== 'avirus' && u.pollution > 40) inf = { tag: 'aGas', src: 'avirus', t: 0, dur: 4 };
    if (!inf && killer && killer.fid === 'tvirus' && u.fid !== 'tvirus' && chance(0.5)) inf = { tag: 'tInfect', src: 'tvirus', t: 0, dur: 5 };
    if (!inf && killer && killer.fid === 'cordyceps' && u.fid !== 'cordyceps' && chance(0.35)) inf = { tag: 'cordySpore', src: 'cordyceps', t: 0, dur: 6 };
    if (!inf && killer && killer.fid === 'necro' && u.fid !== 'necro' && chance(0.3)) inf = { tag: 'necroInfect', src: 'necro', t: 0, dur: 5 };
    if (!inf && killer && killer.fid === 'veronica' && u.fid !== 'veronica' && chance(0.3)) inf = { tag: 'veronica', src: 'veronica', t: 0, dur: 5 };
    if (u.vkey !== 'cocoon' && !(u.fid === 'flood' && u.vkey === 'infection')) {
      w.corpses.push({ id: w.nextId++, fid: u.fid, vkey: u.vkey, x: u.x, z: u.z, radius: u.radius, life: 40, facing: u.facing, look: u.look, inf, claimedBy: null, claimT: 0 });
    }
    if (w.corpses.length > 160) w.corpses.splice(0, w.corpses.length - 160);
  }

  removeUnit(u: Unit) { u.dead = true; }

  private reanimateCorpse(c: Corpse, fid: string, vkey: string) {
    const f = FACTION_MAP.get(fid)!; const v = getVariant(fid, vkey) ?? this.baseVariant(f);
    this.world.corpses = this.world.corpses.filter((x) => x !== c);
    const u = this.spawnAt(f, v, c.x, c.z, 0.85); u.stun = 0.8;
    this.fx({ kind: 'spawnfx', x: c.x, z: c.z, dur: 0.8, size: v.radius * 3, color: f.outline || f.color });
    this.text(c.x, c.z, '蘇生', f.outline || f.color);
    this.log(`死体が${v.name}として蘇った`);
  }

  private zone(z: Omit<Zone, 'id' | 'maxLife'>) { this.world.zones.push({ id: this.world.nextId++, maxLife: z.life, ...z }); }

  // ---------- projectiles ----------
  private updateProjectiles(dt: number) {
    const w = this.world; const keep: Projectile[] = [];
    for (const p of w.projectiles) {
      p.life -= dt; p.x += p.vx * dt; p.z += p.vz * dt; p.h += p.vh * dt;
      if (p.gravity) p.vh -= 700 * dt;
      p.trail.push({ x: p.x, z: p.z, h: p.h }); if (p.trail.length > 8) p.trail.shift();
      const owner = w.units.find((u) => u.id === p.owner);
      let done = false;
      if (p.kind === 'bullet' || p.kind === 'spike') {
        for (const o of w.units) {
          if (o.fid === p.fid || o.dead) continue;
          if (Math.abs(o.x - p.x) < o.radius + 6 && Math.abs(o.z - p.z) < 14 && p.h < o.radius * 4.5) {
            if (owner) this.hit(owner, o, p.spec, p.dmg); else this.damage(o, 8, null, 'shot');
            done = true; break;
          }
        }
        if (p.life <= 0 || p.x < 0 || p.x > w.width) done = true;
      } else {
        if (p.h <= 0 || p.life <= 0) {
          done = true; const s = p.spec; const r = s.aoe ?? 30; const f = FACTION_MAP.get(p.fid)!;
          this.fx({ kind: 'shock', x: p.x, z: p.z, dur: 0.35, size: r, color: p.color });
          for (let i = 0; i < 8; i++) this.particle({ x: p.x, z: p.z, h: 4, vx: rand(-80, 80), vz: rand(-15, 15), vh: rand(30, 120), life: 0.5, size: rand(3, 6), color: p.color, kind: 'blood', grav: 400 });
          if (s.effect === 'acid') this.zone({ x: p.x, z: p.z, radius: r, life: 4, fid: p.fid, effect: 'acid', dps: 6, color: 'rgba(200,255,60,0.35)', kind: 'acid' });
          if (s.effect === 'burn') this.zone({ x: p.x, z: p.z, radius: r, life: 5, fid: p.fid, effect: 'burn', dps: 5, color: 'rgba(255,140,40,0.35)', kind: 'fire' });
          if (s.effect === 'cordySpore') this.zone({ x: p.x, z: p.z, radius: r, life: 8, fid: p.fid, effect: 'cordySpore', dps: 2, color: 'rgba(210,190,120,0.35)', kind: 'spore' });
          if (s.effect === 'plagaSeed') this.zone({ x: p.x, z: p.z, radius: r + 10, life: 5, fid: p.fid, effect: 'plagaSeed', dps: 1, color: 'rgba(214,197,66,0.3)', kind: 'spore' });
          for (const o of w.units) {
            if (o.fid === p.fid || o.dead) continue;
            if (dist(o.x, o.z, p.x, p.z) < r + o.radius) { if (owner) this.hit(owner, o, s, p.dmg); else this.damage(o, 10, null, 'proj'); }
          }
          void f;
        }
      }
      if (!done) keep.push(p);
    }
    w.projectiles = keep;
  }

  private updateZones(dt: number) {
    const w = this.world;
    for (const z of w.zones) {
      z.life -= dt;
      if (chance(dt * 6)) this.particle({ x: z.x + rand(-z.radius, z.radius) * 0.8, z: z.z + rand(-z.radius, z.radius) * 0.3, h: rand(0, 10), vh: rand(8, 22), vx: rand(-6, 6), life: rand(0.8, 1.6), size: rand(8, 16), color: z.color, kind: z.kind === 'fire' ? 'ember' : 'smoke' });
      if (z.kind === 'fire' && chance(dt * 20)) this.particle({ x: z.x + rand(-z.radius, z.radius) * 0.8, z: z.z + rand(-5, 5), h: 2, vh: rand(40, 90), life: rand(0.3, 0.6), size: rand(5, 10), color: chance(0.5) ? '#ff8a20' : '#ffd060', kind: 'ember', grav: -60 });
      for (const o of w.units) {
        if (o.fid === z.fid || o.dead) continue;
        if (dist(o.x, o.z, z.x, z.z) < z.radius + o.radius) {
          if (z.effect === 'aGas') { if (o.fid !== 'avirus') o.pollution = Math.min(120, o.pollution + 14 * dt); if (o.pollution >= 100 && o.maxHp < 350) { this.transform(o, 'avirus', 'azombie'); this.log('A汚染が発症'); } this.damage(o, z.dps * dt, null, 'gas'); }
          else if (z.effect === 'fear') { o.fear = Math.min(130, o.fear + 18 * dt); if (o.fear >= 100 && o.maxHp < 350) this.transform(o, 'tphobos', 'afflicted'); }
          else if (z.effect === 'burn') { o.burn = Math.max(o.burn, 1.5); }
          else if (z.effect === 'acid' || z.effect === 'poison' || z.effect === 'damage') this.damage(o, z.dps * dt, null, 'zone');
          else if (chance(dt * 0.35) && !o.inf) { const src = w.units.find((u) => u.fid === z.fid) ?? null; if (src) this.applyEffect(src, o, z.effect); }
        }
      }
    }
    w.zones = w.zones.filter((z) => z.life > 0);
  }

  private updateCorpses(dt: number) {
    const w = this.world;
    for (const c of w.corpses) {
      c.life -= dt;
      if (c.claimT > 0) { c.claimT -= dt; if (c.claimT <= 0) c.claimedBy = null; }
      if (c.inf) {
        c.inf.t += dt;
        if (c.inf.t >= c.inf.dur) {
          const src = c.inf.src; const vk = src === 'tvirus' ? 'zombie' : src === 'avirus' ? 'azombie' : src === 'cordyceps' ? 'runner' : src === 'necro' ? 'slasher' : src === 'veronica' ? 'vinfected' : src === 'flood' ? 'combat' : null;
          if (vk) { this.reanimateCorpse(c, src, vk); continue; }
          c.inf = null;
        }
      }
    }
    w.corpses = w.corpses.filter((c) => c.life > 0);
  }

  private updateGrowth(dt: number) {
    const w = this.world;
    const counts = new Map<string, number>(); for (const u of w.units) counts.set(u.fid, (counts.get(u.fid) ?? 0) + 1);
    for (const f of FACTIONS) {
      const n = counts.get(f.id) ?? 0; if (n === 0) continue;
      w.growthTimers[f.id] -= dt; if (w.growthTimers[f.id] > 0) continue;
      w.growthTimers[f.id] = f.growth.every * (n > f.growth.cap * 0.6 ? 1.6 : 1);
      if (n >= f.growth.cap || w.units.length > 520) continue;
      const own = w.units.filter((u) => u.fid === f.id);
      if (f.growth.mode === 'corpse') {
        for (let i = 0; i < f.growth.count; i++) {
          const anchor = own[Math.floor(Math.random() * own.length)]; if (!anchor) break;
          const c = this.nearestCorpse(anchor, 380); if (!c) break;
          this.reanimateCorpse(c, f.id, this.baseVariant(f).key);
        }
      } else if (f.growth.mode === 'nest') {
        const nest = w.nests[f.id];
        for (let i = 0; i < f.growth.count; i++) { const u = this.spawnAt(f, this.pickVariant(f, true), nest.x + rand(-60, 60), nest.z + rand(-30, 30)); u.stun = 0.5; }
        this.fx({ kind: 'spawnfx', x: nest.x, z: nest.z, dur: 0.8, size: 40, color: f.outline || f.color });
      } else {
        for (let i = 0; i < f.growth.count; i++) {
          const anchor = own[Math.floor(Math.random() * own.length)]; if (!anchor) break;
          const u = this.spawnAt(f, this.pickVariant(f, true), anchor.x + rand(-40, 40), anchor.z + rand(-20, 20)); u.stun = 0.6; u.h = 15;
          this.fx({ kind: 'spawnfx', x: u.x, z: u.z, dur: 0.6, size: u.radius * 3, color: f.outline || f.color });
        }
      }
    }
  }

  private updateParticles(dt: number) {
    const w = this.world;
    for (const p of w.particles) {
      p.life -= dt; p.x += p.vx * dt; p.z += p.vz * dt; p.h += p.vh * dt;
      if (p.grav) p.vh -= p.grav * dt;
      if (p.h < 0 && p.kind !== 'text') { p.h = 0; p.vh *= -0.3; p.vx *= 0.6; if (p.kind === 'blood' && p.life > 0.4) p.life = 0.4; }
      if (p.rot != null && p.vr) p.rot += p.vr * dt;
      if (p.kind === 'smoke') p.size += 12 * dt;
    }
    w.particles = w.particles.filter((p) => p.life > 0);
    if (w.particles.length > 900) w.particles.splice(0, w.particles.length - 900);
    for (const f of w.fx) f.t += dt;
    w.fx = w.fx.filter((f) => f.t < f.dur);
  }

  private separate() {
    const us = this.world.units; const cell = 60; const grid = new Map<number, Unit[]>();
    for (const u of us) { const k = Math.floor(u.x / cell) * 4096 + Math.floor(u.z / cell); (grid.get(k) ?? grid.set(k, []).get(k)!).push(u); }
    for (const u of us) {
      if (u.heldBy != null) continue;
      const cx = Math.floor(u.x / cell), cz = Math.floor(u.z / cell);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const arr = grid.get((cx + dx) * 4096 + (cz + dz)); if (!arr) continue;
        for (const o of arr) {
          if (o === u || o.id < u.id || o.heldBy != null) continue;
          const ddx = o.x - u.x, ddz = (o.z - u.z) * 1.8; const d = Math.hypot(ddx, ddz); const min = (u.radius + o.radius) * 1.1;
          if (d < min && d > 0.01) { const push = (min - d) * 0.5; const nx = ddx / d, nz = ddz / d; u.x -= nx * push; u.z -= nz * push * 0.5; o.x += nx * push; o.z += nz * push * 0.5; }
          else if (d <= 0.01) { u.x -= 1; o.x += 1; }
        }
      }
    }
  }

  private checkWinner() {
    const w = this.world; if (w.time < 8) return;
    const alive = new Set(w.units.map((u) => u.fid));
    if (alive.size === 1 && !w.winner) { w.winner = [...alive][0]; this.log(`${FACTION_MAP.get(w.winner)!.name} が生き残った`); }
    if (alive.size > 1) w.winner = null;
  }

  counts(): Record<string, number> {
    const c: Record<string, number> = {}; for (const f of FACTIONS) c[f.id] = 0; for (const u of this.world.units) c[u.fid]++; return c;
  }
}

export function attackPhase(a: ActiveAttack): 'windup' | 'strike' | 'recover' {
  if (a.t < a.spec.windup) return 'windup';
  if (a.t < a.spec.windup + a.spec.strike) return 'strike';
  return 'recover';
}
