import { FACTIONS, FACTION_MAP } from './data';
import { attackPhase } from './engine';
import type { AttackKind, Corpse, Look, Particle, Projectile, Unit, VisualFx, World, Zone } from './types';

export interface Camera { x: number; zoom: number; }

// ---------- color utils ----------
const colorCache = new Map<string, string>();
function hexToRgb(hex: string): [number, number, number] {
  if (hex.startsWith('rgb')) { const m = hex.match(/[\d.]+/g)!; return [+m[0], +m[1], +m[2]]; }
  const h = hex.replace('#', ''); const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function tint(hex: string, k: number): string {
  const key = hex + k; const c = colorCache.get(key); if (c) return c;
  const [r, g, b] = hexToRgb(hex);
  const f = (v: number) => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k);
  const out = `rgb(${f(r)},${f(g)},${f(b)})`; colorCache.set(key, out); return out;
}
function rgba(hex: string, a: number) { const [r, g, b] = hexToRgb(hex); return `rgba(${r},${g},${b},${a})`; }

// ---------- projection ----------
export function project(cam: Camera, W: number, H: number, x: number, z: number, depth: number) {
  const horizon = H * 0.34;
  const zn = z / depth;
  const sy = horizon + (0.05 + 0.95 * Math.pow(zn, 1.1)) * (H - horizon) * 0.92 + 10;
  const s = cam.zoom * (0.72 + 0.55 * zn);
  const sx = W / 2 + (x - cam.x) * cam.zoom;
  return { sx, sy, s };
}
export function unproject(cam: Camera, W: number, H: number, sx: number, sy: number, depth: number) {
  const horizon = H * 0.34;
  const zn01 = ((sy - 10 - horizon) / ((H - horizon) * 0.92) - 0.05) / 0.95;
  const z = Math.pow(Math.max(0.0001, zn01), 1 / 1.1) * depth;
  const x = cam.x + (sx - W / 2) / cam.zoom;
  return { x, z };
}

// ---------- pose ----------
interface Pose {
  lean: number; bob: number; crouch: number; lunge: number;
  armF: [number, number]; armB: [number, number]; legF: [number, number]; legB: [number, number];
  headTilt: number; headFwd: number; tail: number; jaw: number; twist: number; sq: number; spin: number; armsUp: number;
}
function basePose(): Pose {
  return { lean: 0, bob: 0, crouch: 0, lunge: 0, armF: [0.15, 0.2], armB: [-0.1, 0.2], legF: [0.1, -0.1], legB: [-0.1, -0.1], headTilt: 0, headFwd: 0, tail: 0, jaw: 0.1, twist: 0, sq: 1, spin: 0, armsUp: 0 };
}
type PP = Partial<Pose>;
const KF: Record<AttackKind, { ant: PP; ext: PP }> = {
  slash: { ant: { armF: [-2.4, 0.6], lean: -0.18, twist: -0.4, crouch: 1 }, ext: { armF: [1.1, 0.2], lean: 0.32, twist: 0.5, lunge: 10 } },
  stab: { ant: { armF: [-0.9, 1.2], lean: -0.12, lunge: -4, twist: -0.3 }, ext: { armF: [1.55, 0], lean: 0.34, lunge: 16, twist: 0.35 } },
  smash: { ant: { armF: [-2.9, 0.4], armB: [-2.9, 0.4], lean: -0.25, crouch: -2 }, ext: { armF: [1.05, 0.2], armB: [1.05, 0.2], lean: 0.55, crouch: 7 } },
  bite: { ant: { lean: -0.22, headTilt: -0.35, jaw: 1, lunge: -3 }, ext: { lean: 0.5, headFwd: 8, headTilt: 0.2, jaw: 0.15, lunge: 12 } },
  tail: { ant: { tail: -1.3, lean: -0.1, twist: -0.3 }, ext: { tail: 1.5, lean: 0.25, lunge: 6, twist: 0.4 } },
  tentacle: { ant: { tail: -1.1, armsUp: 1, lean: -0.15 }, ext: { tail: 1.4, armsUp: 0.3, lean: 0.3, lunge: 6 } },
  charge: { ant: { lean: -0.28, crouch: 4, armF: [-0.6, 0.6], armB: [-0.6, 0.6] }, ext: { lean: 0.6, crouch: 2, armF: [-0.4, 0.4], armB: [-0.4, 0.4] } },
  pounce: { ant: { crouch: 7, lean: -0.3, armF: [-0.7, 0.5], armB: [-0.7, 0.5] }, ext: { lean: 0.45, crouch: -3, armF: [1.5, 0.3], armB: [1.3, 0.3], legF: [-0.6, -0.8], legB: [-0.8, -0.8], jaw: 1 } },
  shoot: { ant: { armF: [1.45, 0.1], armB: [1.2, 0.5], lean: 0.05, twist: 0.3 }, ext: { armF: [1.5, 0.15], armB: [1.25, 0.5], lean: -0.08, lunge: -3, twist: 0.3 } },
  spit: { ant: { headTilt: -0.55, lean: -0.22, jaw: 0.5 }, ext: { headTilt: 0.5, headFwd: 6, lean: 0.3, jaw: 1 } },
  gas: { ant: { lean: -0.2, crouch: 3, armsUp: 0.5 }, ext: { lean: -0.1, armF: [-1.6, 0.3], armB: [-1.6, 0.3], jaw: 1, armsUp: 1 } },
  explode: { ant: { crouch: -4, sq: 1.18, armF: [-1.2, 0.2], armB: [-1.2, 0.2], jaw: 1 }, ext: { sq: 1.3 } },
  grab: { ant: { armF: [-0.5, 0.8], armB: [-0.5, 0.8], lean: -0.1 }, ext: { armF: [1.4, 0.3], armB: [1.25, 0.3], lunge: 10, lean: 0.3, jaw: 0.8 } },
  flame: { ant: { headTilt: -0.4, lean: -0.15, armF: [1.3, 0.2] }, ext: { headTilt: 0.15, headFwd: 4, lean: 0.2, jaw: 1, armF: [1.4, 0.2] } },
  slam: { ant: { armF: [-3, 0.3], armB: [-3, 0.3], crouch: -8, lean: -0.15 }, ext: { armF: [1.3, 0.1], armB: [1.3, 0.1], crouch: 11, lean: 0.45 } },
  spin: { ant: { armF: [1.2, 0.1], armB: [-1.2, 0.1], crouch: 2 }, ext: { armF: [1.5, 0.1], armB: [-1.5, 0.1], crouch: 1 } },
  throw: { ant: { armF: [-2.6, 0.5], lean: -0.22, twist: -0.4 }, ext: { armF: [1.35, 0.1], lean: 0.32, lunge: 8, twist: 0.4 } },
  punch: { ant: { armF: [-0.7, 1.6], twist: -0.35, lean: -0.05 }, ext: { armF: [1.5, 0.05], lunge: 8, twist: 0.45, lean: 0.15 } },
  kick: { ant: { legF: [-0.8, -0.6], lean: -0.2 }, ext: { legF: [1.7, -0.05], lean: -0.45, lunge: 6 } },
  whip: { ant: { armF: [-2.2, 0.4], tail: -1.2, lean: -0.15 }, ext: { armF: [1.2, 0.2], tail: 1.5, lean: 0.3, lunge: 6 } },
  drain: { ant: { armF: [-0.5, 0.8], armB: [-0.5, 0.8], headTilt: -0.3 }, ext: { armF: [1.35, 0.4], armB: [1.2, 0.4], lunge: 9, lean: 0.35, headFwd: 6, jaw: 0.9 } },
  spawn: { ant: { crouch: 4, lean: 0.1, armsUp: 0.4 }, ext: { crouch: 7, lean: 0.35, armsUp: 0.2, jaw: 1 } },
  scream: { ant: { lean: -0.25, crouch: 3, headTilt: -0.5, armF: [-0.6, 0.8], armB: [-0.6, 0.8] }, ext: { lean: -0.2, headTilt: -0.7, jaw: 1, armF: [-1.8, 0.2], armB: [-1.8, 0.2], sq: 1.06 } },
};
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
const easeOutBack = (t: number) => { const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
const easeInOut = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }
function mixPose(a: Pose, b: PP, t: number) {
  for (const k of Object.keys(b) as (keyof Pose)[]) {
    const bv = b[k]!; const av = a[k];
    if (Array.isArray(bv)) (a as unknown as Record<string, unknown>)[k] = [lerp((av as [number, number])[0], bv[0], t), lerp((av as [number, number])[1], bv[1], t)];
    else (a as unknown as Record<string, unknown>)[k] = lerp(av as number, bv as number, t);
  }
}

function computePose(u: Unit, time: number): Pose {
  const p = basePose(); const t = u.animT; const look = u.look;
  const hunched = look.body === 'hunched' || look.body === 'brute';
  if (hunched) { p.lean = look.body === 'brute' ? 0.22 : 0.4; p.armF = [0.5, 0.9]; p.armB = [0.35, 0.9]; p.headFwd = 3; }
  if (look.body === 'tall') { p.lean = 0.08; p.armF = [0.1, 0.3]; p.armB = [-0.2, 0.3]; }
  p.bob = Math.sin(t * 2.2) * 0.7;
  p.armF[0] += Math.sin(t * 2.2) * 0.05; p.armB[0] -= Math.sin(t * 2.2) * 0.05;
  if (u.state === 'move') {
    const run = u.spd > 60; const ph = u.moveT * (run ? 2.2 : 1.7) * Math.PI;
    const amp = run ? 1.0 : 0.6; const sw = Math.sin(ph);
    p.legF = [sw * amp, -Math.max(0, -Math.cos(ph)) * 1.1 * amp]; p.legB = [-sw * amp, -Math.max(0, Math.cos(ph)) * 1.1 * amp];
    if (!hunched) { p.armF = [-sw * amp * 0.8, 0.5]; p.armB = [sw * amp * 0.8, 0.5]; } else { p.armF = [0.5 - sw * 0.3, 0.9]; p.armB = [0.35 + sw * 0.3, 0.9]; }
    p.bob = Math.abs(Math.cos(ph)) * (run ? 2.2 : 1.2); p.lean += run ? 0.25 : 0.08;
    p.tail = Math.sin(ph * 0.5) * 0.4;
  } else {
    p.tail = Math.sin(t * 1.6) * 0.35;
  }
  if (u.state === 'channel') { p.crouch = 5; p.lean += 0.3; p.armF = [1.1, 0.6]; p.armB = [1.0, 0.6]; }
  if (u.attack) {
    const a = u.attack; const s = a.spec; const ph = attackPhase(a); const kf = KF[s.kind];
    if (ph === 'windup') mixPose(p, kf.ant, easeOutCubic(Math.min(1, a.t / s.windup)));
    else if (ph === 'strike') { mixPose(p, kf.ant, 1); const q = Math.min(1, (a.t - s.windup) / s.strike); mixPose(p, kf.ext, s.hold || s.kind === 'flame' || s.kind === 'charge' || s.kind === 'spin' ? Math.min(1, q * 4) : easeOutBack(q)); if (s.kind === 'spin') p.spin = q * Math.PI * 2 * (s.hits ?? 3); }
    else { mixPose(p, kf.ext, 1); const q = Math.min(1, (a.t - s.windup - s.strike) / s.recover); const n = basePose(); mixPose(p, { lean: hunched ? p.lean * 0.5 : 0, lunge: 0, crouch: 0, armF: n.armF, armB: n.armB, headFwd: 0, headTilt: 0, jaw: 0.1, twist: 0, tail: 0, sq: 1, armsUp: 0 }, easeInOut(q)); }
    if (s.kind === 'charge' && ph === 'strike') { const ph2 = a.t * 22; p.legF = [Math.sin(ph2), -Math.max(0, -Math.cos(ph2)) * 1.2]; p.legB = [-Math.sin(ph2), -Math.max(0, Math.cos(ph2)) * 1.2]; }
    if (s.kind === 'explode' && ph === 'windup') { p.sq = 1 + 0.18 * (a.t / s.windup) + Math.sin(time * 40) * 0.04 * (a.t / s.windup); }
  }
  if (u.hitT > 0) { const k = u.hitT / 0.28; p.lean -= 0.35 * k * u.hitDir * u.facing; p.headTilt -= 0.3 * k; p.armF[0] -= 0.4 * k; p.armB[0] -= 0.4 * k; }
  if (u.heldBy != null) { p.armF = [-2.4, 0.3]; p.armB = [-2.2, 0.3]; p.legF = [0.4, -0.6]; p.legB = [-0.3, -0.5]; p.jaw = 1; p.headTilt = -0.4; }
  if (u.stun > 0 && u.heldBy == null) { p.lean += Math.sin(time * 6) * 0.08; p.headTilt = 0.4; }
  return p;
}

// ---------- drawing primitives ----------
type Ctx = CanvasRenderingContext2D;
let OL = '#111';
function limb(ctx: Ctx, ax: number, ay: number, bx: number, by: number, w: number, col: string) {
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = OL; ctx.lineWidth = w + 1.6; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
  ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
  ctx.strokeStyle = tint(col, 0.35); ctx.lineWidth = Math.max(0.6, w * 0.32); ctx.beginPath(); ctx.moveTo(ax - w * 0.16, ay - w * 0.22); ctx.lineTo(bx - w * 0.16, by - w * 0.22); ctx.stroke();
}
function ball(ctx: Ctx, x: number, y: number, r: number, col: string, ry = r) {
  const g = ctx.createRadialGradient(x - r * 0.35, y - ry * 0.4, r * 0.1, x, y, r * 1.1);
  g.addColorStop(0, tint(col, 0.45)); g.addColorStop(0.55, col); g.addColorStop(1, tint(col, -0.45));
  ctx.fillStyle = g; ctx.strokeStyle = OL; ctx.lineWidth = 1.3;
  ctx.beginPath(); ctx.ellipse(x, y, r, ry, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
}
function shadedPoly(ctx: Ctx, pts: [number, number][], col: string, x0: number, x1: number) {
  const g = ctx.createLinearGradient(x0, 0, x1, 0);
  g.addColorStop(0, tint(col, 0.3)); g.addColorStop(0.5, col); g.addColorStop(1, tint(col, -0.4));
  ctx.fillStyle = g; ctx.strokeStyle = OL; ctx.lineWidth = 1.3; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]); ctx.closePath(); ctx.fill(); ctx.stroke();
}
function bez(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, w0: number, col: string) {
  ctx.lineCap = 'round';
  ctx.strokeStyle = OL; ctx.lineWidth = w0 + 1.6; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3); ctx.stroke();
  ctx.strokeStyle = col; ctx.lineWidth = w0; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.bezierCurveTo(x1, y1, x2, y2, x3, y3); ctx.stroke();
  ctx.strokeStyle = tint(col, 0.35); ctx.lineWidth = w0 * 0.3; ctx.beginPath(); ctx.moveTo(x0, y0 - w0 * 0.2); ctx.bezierCurveTo(x1, y1 - w0 * 0.2, x2, y2 - w0 * 0.2, x3, y3 - w0 * 0.2); ctx.stroke();
}
function glowDot(ctx: Ctx, x: number, y: number, r: number, col: string) {
  ctx.fillStyle = rgba(col, 0.28); ctx.beginPath(); ctx.arc(x, y, r * 2.2, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.3, r * 0.4, 0, Math.PI * 2); ctx.fill();
}
function dot(ctx: Ctx, x: number, y: number, r: number, col: string) {
  ctx.fillStyle = col; ctx.strokeStyle = OL; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = tint(col, 0.35); ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.3, r * 0.4, 0, Math.PI * 2); ctx.fill();
}
function blade(ctx: Ctx, x: number, y: number, ang: number, len: number, w: number, col = '#cfd4da') {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  shadedPoly(ctx, [[0, -w], [len * 0.75, -w * 0.9], [len, 0], [len * 0.75, w * 0.4], [0, w * 0.5]], col, 0, len);
  ctx.restore();
}
function claws(ctx: Ctx, x: number, y: number, ang: number, len: number, col: string) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  for (let i = -1; i <= 1; i++) { blade(ctx, 0, i * len * 0.18, i * 0.25, len, len * 0.14, col); }
  ctx.restore();
}

// ---------- head ----------
function drawHead(ctx: Ctx, look: Look, x: number, y: number, r: number, p: Pose, time: number) {
  const skin = look.skin, skin2 = look.skin2 ?? tint(skin, 0.3); const glow = look.glow ?? '#ffdcdc';
  ctx.save(); ctx.translate(x, y); ctx.rotate(p.headTilt * 0.6);
  switch (look.head) {
    case 'xeno': {
      ball(ctx, -r * 0.9, -r * 0.1, r * 1.9, skin, r * 0.72);
      ctx.fillStyle = 'rgba(255,255,255,0.10)'; ctx.beginPath(); ctx.ellipse(-r * 0.9, -r * 0.35, r * 1.5, r * 0.28, 0, 0, Math.PI * 2); ctx.fill();
      // teeth
      ctx.fillStyle = '#e8e8e0'; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(r * 0.2 + i * r * 0.2, r * 0.42); ctx.lineTo(r * 0.28 + i * r * 0.2, r * 0.42 + r * 0.28 * (1 + p.jaw)); ctx.lineTo(r * 0.36 + i * r * 0.2, r * 0.42); ctx.fill(); }
      if (p.jaw > 0.6) { limb(ctx, r * 0.6, r * 0.3, r * 0.6 + r * 1.4 * p.jaw, r * 0.4, r * 0.22, tint(skin, 0.2)); ctx.fillStyle = '#e8e8e0'; ctx.beginPath(); ctx.arc(r * 0.6 + r * 1.4 * p.jaw, r * 0.4, r * 0.16, 0, 7); ctx.fill(); }
      ctx.strokeStyle = rgba(glow, 0.5); ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(-r * 0.9, -r * 0.1, r * 1.9, r * 0.72, 0, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
      if (look.extras?.includes('crown')) { shadedPoly(ctx, [[-r * 2.6, -r * 0.4], [-r * 3.4, -r * 1.6], [-r * 1.8, -r * 1.2], [-r * 0.8, -r * 2.0], [0, -r * 0.9]], skin, -r * 3, 0); }
      break;
    }
    case 'dome': {
      ball(ctx, -r * 0.5, -r * 0.2, r * 1.5, skin, r * 0.9);
      ctx.strokeStyle = tint(skin, -0.4); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(r * 0.3, r * 0.4); ctx.lineTo(r * 0.9, r * 0.35); ctx.stroke();
      if (p.jaw > 0.4) { ctx.fillStyle = '#2a1a1a'; ctx.beginPath(); ctx.ellipse(r * 0.7, r * 0.45, r * 0.35, r * 0.3 * p.jaw, 0, 0, 7); ctx.fill(); }
      break;
    }
    case 'brain': {
      ball(ctx, 0, 0, r, skin);
      ctx.fillStyle = '#f0a0a8'; ctx.strokeStyle = OL; ctx.lineWidth = 1;
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(-r * 0.5 + i * r * 0.33, -r * 0.65, r * 0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = '#5a0a0a'; ctx.beginPath(); ctx.ellipse(r * 0.6, r * 0.3, r * 0.45, r * 0.3 * (0.4 + p.jaw), 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#fff'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(r * 0.3 + i * r * 0.25, r * 0.1); ctx.lineTo(r * 0.38 + i * r * 0.25, r * 0.4); ctx.lineTo(r * 0.46 + i * r * 0.25, r * 0.1); ctx.fill(); }
      break;
    }
    case 'fungus': {
      ball(ctx, 0, r * 0.1, r * 0.9, skin);
      ctx.fillStyle = skin2; ctx.strokeStyle = OL; ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) { const a = -2.6 + i * 0.75; ctx.beginPath(); ctx.ellipse(Math.cos(a) * r * 0.5, Math.sin(a) * r * 0.5 - r * 0.2, r * 0.75, r * 0.32, a + 0.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = tint(skin2, 0.4); ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.6, r * 0.5, r * 0.22, -0.3, 0, 7); ctx.fill();
      ctx.fillStyle = '#3a1a10'; ctx.beginPath(); ctx.ellipse(r * 0.55, r * 0.45, r * 0.3, r * 0.22 * (0.3 + p.jaw), 0, 0, 7); ctx.fill();
      break;
    }
    case 'split': {
      ball(ctx, 0, r * 0.2, r * 0.8, skin);
      const open = 0.3 + p.jaw * 0.9;
      for (let i = -1; i <= 1; i++) { ctx.save(); ctx.rotate(i * open + (i === 0 ? -1.4 : i * 0.3)); shadedPoly(ctx, [[0, 0], [r * 0.5, -r * 1.3], [r * 0.95, -r * 0.7], [r * 0.8, 0]], tint(skin, -0.1), 0, r); ctx.fillStyle = '#7a1020'; ctx.beginPath(); ctx.moveTo(r * 0.2, -r * 0.2); ctx.lineTo(r * 0.5, -r * 0.9); ctx.lineTo(r * 0.7, -r * 0.5); ctx.fill(); ctx.restore(); }
      glowDot(ctx, r * 0.3, r * 0.1, r * 0.15, glow);
      break;
    }
    case 'skull': {
      ball(ctx, 0, 0, r, tint(skin, 0.25));
      ctx.fillStyle = '#1a0a0a'; ctx.beginPath(); ctx.ellipse(r * 0.45, -r * 0.1, r * 0.28, r * 0.32, 0, 0, 7); ctx.fill(); ctx.beginPath(); ctx.ellipse(-r * 0.15, -r * 0.12, r * 0.22, r * 0.28, 0, 0, 7); ctx.fill();
      glowDot(ctx, r * 0.45, -r * 0.1, r * 0.1, glow);
      ctx.strokeStyle = '#1a0a0a'; ctx.lineWidth = 1; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(r * 0.1 + i * r * 0.22, r * 0.5); ctx.lineTo(r * 0.1 + i * r * 0.22, r * 0.85 + p.jaw * r * 0.4); ctx.stroke(); }
      break;
    }
    case 'eyeless': {
      ball(ctx, 0, 0, r, skin, r * 1.1);
      ctx.strokeStyle = tint(skin, -0.5); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(r * 0.2, r * 0.45); ctx.quadraticCurveTo(r * 0.6, r * 0.5 + p.jaw * r * 0.5, r * 0.95, r * 0.3); ctx.stroke();
      if (p.jaw > 0.5) { ctx.fillStyle = '#3a0a0a'; ctx.beginPath(); ctx.ellipse(r * 0.6, r * 0.5, r * 0.35, r * 0.28 * p.jaw, 0, 0, 7); ctx.fill(); }
      break;
    }
    case 'maw': {
      ball(ctx, 0, 0, r * 1.05, skin, r * 0.9);
      const open = 0.15 + p.jaw * 0.6;
      ctx.fillStyle = '#4a0a10'; ctx.beginPath(); ctx.moveTo(r * 0.1, r * 0.1); ctx.lineTo(r * 1.4, r * 0.1 - open * r * 1.2); ctx.lineTo(r * 1.4, r * 0.1 + open * r * 1.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#f0f0e8'; for (let i = 0; i < 4; i++) { const fx = r * 0.35 + i * r * 0.26; ctx.beginPath(); ctx.moveTo(fx, r * 0.1 - open * r * 0.9 * (fx / (r * 1.4))); ctx.lineTo(fx + r * 0.08, r * 0.1 - open * r * 0.9 * (fx / (r * 1.4)) + r * 0.3); ctx.lineTo(fx + r * 0.16, r * 0.1 - open * r * 0.9 * (fx / (r * 1.4))); ctx.fill(); }
      if (look.glow) glowDot(ctx, r * 0.35, -r * 0.35, r * 0.14, glow);
      break;
    }
    case 'hood': {
      shadedPoly(ctx, [[-r * 1.1, r * 1.2], [-r * 1.0, -r * 1.1], [r * 0.2, -r * 1.3], [r * 1.1, -r * 0.2], [r * 0.9, r * 1.2]], look.cloth ?? '#3a2a2a', -r, r);
      ctx.fillStyle = '#0a0606'; ctx.beginPath(); ctx.ellipse(r * 0.3, r * 0.1, r * 0.6, r * 0.7, 0, 0, 7); ctx.fill();
      glowDot(ctx, r * 0.45, 0, r * 0.12, glow);
      break;
    }
    case 'none': break;
    case 'human':
    case 'zombie':
    default: {
      const zomb = look.head === 'zombie';
      ball(ctx, 0, 0, r, zomb ? tint(skin, -0.05) : skin, r * 1.08);
      // hair / cap
      if (!look.extras?.includes('glasses') || true) { ctx.fillStyle = zomb ? tint(look.cloth ?? '#333', -0.3) : (look.cloth ? tint(look.cloth, -0.35) : '#2a2420'); ctx.beginPath(); ctx.ellipse(-r * 0.15, -r * 0.45, r * 0.95, r * 0.62, 0, Math.PI * 1.05, Math.PI * 1.95); ctx.fill(); }
      if (look.extras?.includes('crown')) { ctx.fillStyle = '#e0c060'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(-r * 0.7 + i * r * 0.6, -r * 0.7); ctx.lineTo(-r * 0.4 + i * r * 0.6, -r * 1.7); ctx.lineTo(-r * 0.1 + i * r * 0.6, -r * 0.7); ctx.fill(); } }
      // eye
      if (look.extras?.includes('glasses')) { ctx.fillStyle = '#111'; ctx.fillRect(r * 0.05, -r * 0.25, r * 1.0, r * 0.3); ctx.fillStyle = 'rgba(255,200,80,0.5)'; ctx.fillRect(r * 0.5, -r * 0.2, r * 0.4, r * 0.15); }
      else {
        if (zomb) { ctx.fillStyle = tint(skin, -0.5); ctx.beginPath(); ctx.ellipse(r * 0.45, -r * 0.1, r * 0.25, r * 0.3, 0, 0, 7); ctx.fill(); }
        glowDot(ctx, r * 0.5, -r * 0.1, r * 0.11, glow);
        if (look.extras?.includes('eyes')) { glowDot(ctx, r * 0.15, -r * 0.35, r * 0.08, glow); glowDot(ctx, r * 0.75, -r * 0.4, r * 0.08, glow); }
      }
      // mouth
      ctx.strokeStyle = '#2a0a0a'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(r * 0.35, r * 0.5); ctx.lineTo(r * 0.85, r * 0.42); ctx.stroke();
      if (p.jaw > 0.35) { ctx.fillStyle = '#3a0a0a'; ctx.beginPath(); ctx.ellipse(r * 0.6, r * 0.55, r * 0.25, r * 0.35 * p.jaw, 0, 0, 7); ctx.fill(); }
      if (zomb) { ctx.fillStyle = 'rgba(80,20,20,0.5)'; ctx.beginPath(); ctx.ellipse(-r * 0.3, r * 0.3, r * 0.35, r * 0.25, 0.5, 0, 7); ctx.fill(); }
      break;
    }
  }
  if (look.extras?.includes('tongue')) {
    const ext = p.lunge > 4 ? p.lunge * 3.5 : 0;
    bez(ctx, r * 0.9, r * 0.35, r * 1.6, r * 0.6 + Math.sin(time * 5) * 2, r * 2 + ext * 0.5, r * 0.2, r * 2.2 + ext, r * 0.4 + Math.sin(time * 7) * 2, r * 0.22, '#e05a7a');
  }
  if (look.extras?.includes('proboscis')) {
    const ext = p.lunge > 3 ? p.lunge * 2 : 0;
    bez(ctx, r * 0.8, r * 0.5, r * 1.3, r * 0.9, r * 1.6 + ext, r * 0.3, r * 1.9 + ext, r * 0.8, r * 0.14, tint(skin, -0.2));
  }
  ctx.restore();
}

// ---------- unit ----------
function drawTentacles(ctx: Ctx, _look: Look, x: number, y: number, len: number, p: Pose, time: number, n: number, col: string, forward: boolean) {
  for (let i = 0; i < n; i++) {
    const seed = i * 1.7; const sw = Math.sin(time * 3 + seed) * 0.4;
    const dir = forward ? 1 : -1;
    const ext = p.tail * (forward ? 1 : 0.4);
    const a0 = dir * (0.6 + i * 0.35) + ext * 0.6;
    const L = len * (0.7 + (i % 3) * 0.2) * (1 + Math.max(0, ext) * 0.5);
    const cx1 = x + Math.cos(a0) * L * 0.4, cy1 = y - Math.sin(a0 + 0.8 + sw) * L * 0.4;
    const cx2 = x + Math.cos(a0 - sw) * L * 0.8, cy2 = y - Math.sin(a0 + 0.3) * L * 0.8 - L * 0.2;
    const ex = x + Math.cos(a0 - sw * 1.5) * L, ey = y - Math.sin(a0 - 0.2 + sw) * L * 0.9;
    bez(ctx, x, y, cx1, cy1, cx2, cy2, ex, ey, len * 0.12 * (1.2 - i * 0.05), col);
    glowDot(ctx, ex, ey, len * 0.05, tint(col, 0.4));
  }
}

export function drawUnit(ctx: Ctx, u: Unit, sx: number, sy: number, s: number, time: number, selected: boolean, factionColor: string) {
  const look = u.look; const p = computePose(u, time);
  const f = FACTION_MAP.get(u.fid)!;
  OL = look.outline ?? '#141414';
  const bh = u.radius * 5.2 * look.size;
  // ground shadow (perspective ellipse)
  ctx.save(); ctx.translate(sx, sy);
  ctx.fillStyle = 'rgba(0,0,0,0.42)'; ctx.beginPath(); ctx.ellipse(0, 0, bh * 0.32 * s, bh * 0.1 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = rgba(factionColor === '#101010' || factionColor === '#0a0a0a' ? (f.outline ?? '#fff') : factionColor, selected ? 0.95 : 0.35); ctx.lineWidth = selected ? 2.2 : 1.1; ctx.beginPath(); ctx.ellipse(0, 0, bh * 0.36 * s, bh * 0.12 * s, 0, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.translate(sx, sy - u.h * s);
  ctx.scale(u.facing * s, s);
  if (u.hitT > 0) { ctx.translate((Math.random() - 0.5) * 2, 0); }
  const flash = u.hitT > 0.16;
  if (flash && 'filter' in ctx) { try { ctx.filter = 'brightness(1.9) saturate(0.5)'; } catch { /* unsupported */ } }
  ctx.translate(p.lunge * 0.3, 0);

  const skin = look.skin; const skin2 = look.skin2 ?? tint(skin, 0.25); const cloth = look.cloth;
  const alpha = u.vkey === 'glasp' ? 0.45 : 1; ctx.globalAlpha = alpha;

  if (look.body === 'quad') drawQuad(ctx, u, look, p, bh, time);
  else if (look.body === 'blob') drawBlob(ctx, u, look, p, bh, time);
  else if (look.body === 'serpent') drawSerpent(ctx, u, look, p, bh, time);
  else if (look.body === 'crawler') drawCrawler(ctx, u, look, p, bh, time);
  else if (look.body === 'floater') drawFloater(ctx, u, look, p, bh, time);
  else drawHumanoid(ctx, u, look, p, bh, time, skin, skin2, cloth);

  if (flash && 'filter' in ctx) { try { ctx.filter = 'none'; } catch { /* unsupported */ } }
  ctx.restore();

  // status/hp
  drawStatus(ctx, u, sx, sy - (u.h + bh * 1.15) * s, s, selected, factionColor);
}

function drawHumanoid(ctx: Ctx, u: Unit, look: Look, p: Pose, bh: number, time: number, skin: string, skin2: string, cloth?: string) {
  const brute = look.body === 'brute', tall = look.body === 'tall';
  const ex = look.extras ?? [];
  const H = bh * (tall ? 1.1 : 1) * p.sq;
  const hipY = -H * 0.47 + p.crouch - p.bob * 0.4, shY = -H * 0.74 + p.crouch * 1.4 - p.bob;
  const shW = H * (brute ? 0.2 : tall ? 0.11 : 0.14) * (ex.includes('bulge') ? 1.25 : 1);
  const lean = p.lean; const shX = Math.sin(lean) * (shY - hipY) * -1; // shoulder forward offset
  const armW = H * (brute ? 0.1 : tall ? 0.055 : 0.07), legW = H * (brute ? 0.1 : 0.08);
  const uaL = H * (tall ? 0.22 : 0.18), faL = H * (tall ? 0.21 : 0.17), thL = H * 0.24, shL = H * 0.23;
  const headR = H * (brute ? 0.085 : 0.11);
  const hipX = 0; const legSpread = H * 0.05;
  const rot = p.spin;
  const front = Math.cos(rot) >= 0;

  const limbPts = (ox: number, oy: number, a: [number, number], l1: number, l2: number, legMode: boolean) => {
    const a0 = a[0], a1 = a[0] + a[1] * (legMode ? 1 : 1);
    const ex1 = ox + Math.sin(a0) * l1, ey1 = oy + Math.cos(a0) * l1;
    return { ex: ex1, ey: ey1, hx: ex1 + Math.sin(a1) * l2, hy: ey1 + Math.cos(a1) * l2 };
  };
  const drawArm = (ox: number, oy: number, a: [number, number], big: boolean, col: string, isFront: boolean) => {
    const w = armW * (big ? 1.9 : 1) * (isFront ? 1 : 0.92);
    const pts = limbPts(ox, oy, a, uaL * (big ? 1.1 : 1), faL * (big ? 1.1 : 1), false);
    const c = isFront ? col : tint(col, -0.25);
    limb(ctx, ox, oy, pts.ex, pts.ey, w, c); limb(ctx, pts.ex, pts.ey, pts.hx, pts.hy, w * 0.9, c);
    const ang = Math.atan2(pts.hy - pts.ey, pts.hx - pts.ex);
    if (isFront && ex.includes('eyeArm')) { ball(ctx, ox + Math.sin(a[0]) * uaL * 0.55, oy + Math.cos(a[0]) * uaL * 0.55, w * 0.7, '#f0f0f0'); ctx.fillStyle = '#c02020'; ctx.beginPath(); ctx.arc(ox + Math.sin(a[0]) * uaL * 0.55, oy + Math.cos(a[0]) * uaL * 0.55, w * 0.35, 0, 7); ctx.fill(); ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(ox + Math.sin(a[0]) * uaL * 0.55, oy + Math.cos(a[0]) * uaL * 0.55, w * 0.15, 0, 7); ctx.fill(); }
    // hand / weapon
    if (ex.includes('blades') && (isFront || ex.includes('arms4'))) blade(ctx, pts.hx, pts.hy, ang, H * 0.32, w * 0.55, '#d8dde2');
    else if (ex.includes('claws') || big) claws(ctx, pts.hx, pts.hy, ang, H * (big ? 0.16 : 0.1), ex.includes('claws') ? '#e8e4d8' : tint(col, 0.2));
    else if (ex.includes('knife') && isFront) blade(ctx, pts.hx, pts.hy, ang - 0.3, H * 0.18, w * 0.4);
    else if (ex.includes('saw') && isFront) { ctx.save(); ctx.translate(pts.hx, pts.hy); ctx.rotate(ang); shadedPoly(ctx, [[0, -w * 0.9], [H * 0.42, -w * 0.9], [H * 0.42, w * 0.9], [0, w * 0.9]], '#6a6a70', 0, H * 0.4); ctx.fillStyle = '#c8c8c8'; for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.moveTo(i * H * 0.07, -w * 0.9); ctx.lineTo(i * H * 0.07 + H * 0.035, -w * 1.5); ctx.lineTo(i * H * 0.07 + H * 0.07, -w * 0.9); ctx.fill(); } ctx.restore(); }
    else if ((ex.includes('pitchfork') || ex.includes('axe')) && isFront) { ctx.save(); ctx.translate(pts.hx, pts.hy); ctx.rotate(ang - 0.4); limb(ctx, -H * 0.15, 0, H * 0.4, 0, w * 0.45, '#6a4a2a'); if (ex.includes('axe')) shadedPoly(ctx, [[H * 0.3, -w], [H * 0.42, -w * 2.6], [H * 0.5, w * 0.5], [H * 0.3, w]], '#9a9aa0', H * 0.3, H * 0.5); else { shadedPoly(ctx, [[H * 0.36, -w * 1.2], [H * 0.55, -w * 1.5], [H * 0.55, -w * 0.4], [H * 0.36, -w * 0.4]], '#9a9aa0', 0, H * 0.5); shadedPoly(ctx, [[H * 0.36, w * 0.4], [H * 0.55, w * 0.4], [H * 0.55, w * 1.5], [H * 0.36, w * 1.2]], '#9a9aa0', 0, H * 0.5); } ctx.restore(); }
    else if (ex.includes('gun') && isFront) { ctx.save(); ctx.translate(pts.hx, pts.hy); ctx.rotate(ang - 1.2); shadedPoly(ctx, [[-H * 0.12, -w * 0.5], [H * 0.34, -w * 0.5], [H * 0.34, w * 0.2], [H * 0.05, w * 0.3], [0, w * 1.0], [-H * 0.08, w * 0.9], [-H * 0.12, w * 0.3]], '#3a3f46', -H * 0.1, H * 0.3); ctx.restore(); }
    else { dot(ctx, pts.hx, pts.hy, w * 0.55, c); }
    if (ex.includes('flames') && isFront) { for (let i = 0; i < 3; i++) { const fy = pts.hy - i * w * 0.6 - Math.sin(time * 12 + i) * w * 0.4; glowDot(ctx, pts.hx + Math.sin(time * 9 + i * 2) * w * 0.4, fy, w * (0.5 - i * 0.1), i % 2 ? '#ffd060' : '#ff7a20'); } }
    return pts;
  };
  const drawLeg = (ox: number, oy: number, a: [number, number], col: string, isFront: boolean) => {
    const pts = limbPts(ox, oy, a, thL, shL, true);
    const c = isFront ? col : tint(col, -0.28);
    limb(ctx, ox, oy, pts.ex, pts.ey, legW, c); limb(ctx, pts.ex, pts.ey, pts.hx, pts.hy, legW * 0.85, c);
    // foot
    limb(ctx, pts.hx, pts.hy, pts.hx + legW * 0.9, pts.hy, legW * 0.8, tint(c, -0.15));
  };

  ctx.save();
  ctx.translate(0, p.bob * 0.2);
  // spin rotation faked by squashing horizontally
  if (rot) ctx.scale(Math.max(0.25, Math.abs(Math.cos(rot))) * (front ? 1 : -1), 1);

  // ---- BACK layer ----
  const backArmX = shX - shW * 0.55, frontArmX = shX + shW * 0.55;
  const armCol = skin;
  const legCol = cloth ? tint(cloth, -0.05) : skin;
  if (ex.includes('tail')) {
    const tl = H * 0.7; const sw = p.tail;
    bez(ctx, hipX - shW * 0.5, hipY + H * 0.03, hipX - tl * 0.5, hipY - H * 0.05 - sw * tl * 0.2, hipX - tl * 0.8 + sw * tl * 0.9, hipY - tl * 0.35 - sw * tl * 0.2, hipX - tl * 0.6 + sw * tl * 1.3, hipY - tl * 0.6 + Math.abs(sw) * tl * 0.5 - Math.sin(time * 3) * 3, H * 0.055, tint(skin, -0.1));
    const tipx = hipX - tl * 0.6 + sw * tl * 1.3, tipy = hipY - tl * 0.6 + Math.abs(sw) * tl * 0.5 - Math.sin(time * 3) * 3;
    blade(ctx, tipx, tipy, sw > 0.3 ? 0.2 : -1.8, H * 0.14, H * 0.03, tint(skin, 0.15));
  }
  if (ex.includes('tentacles')) drawTentacles(ctx, look, shX - shW * 0.3, shY + H * 0.05, H * 0.45, p, time, 3, tint(skin2, -0.2), p.tail > 0.5);
  if (ex.includes('wings')) { ctx.globalAlpha *= 0.55; shadedPoly(ctx, [[shX, shY], [shX - H * 0.5, shY - H * 0.45 - Math.sin(time * 14) * H * 0.1], [shX - H * 0.6, shY - H * 0.05]], tint(skin2, 0.2), -H * 0.6, 0); ctx.globalAlpha /= 0.55; }
  if (ex.includes('arms4')) drawArm(backArmX, shY + H * 0.12, [p.armB[0] * 0.8 - 0.4, p.armB[1]], false, tint(armCol, -0.1), false);
  drawArm(backArmX, shY, p.armB, false, armCol, false);
  drawLeg(hipX - legSpread, hipY, p.legB, legCol, false);

  // ---- torso ----
  const torso: [number, number][] = [
    [shX - shW, shY - H * 0.02], [shX + shW, shY - H * 0.02], [hipX + shW * 0.75, hipY + H * 0.04], [hipX - shW * 0.75, hipY + H * 0.04],
  ];
  if (ex.includes('coat')) { shadedPoly(ctx, [[shX - shW * 1.05, shY], [shX + shW * 1.05, shY], [hipX + shW * 1.0, hipY + H * 0.28 + p.lunge * 0.05], [hipX - shW * 1.3, hipY + H * 0.3 - p.lean * 8]], cloth ?? '#222', -shW, shW); }
  shadedPoly(ctx, torso, cloth ? cloth : skin, -shW, shW);
  if (cloth && !ex.includes('coat')) { // exposed skin patches for zombies
    if (ex.includes('rags')) { ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(shX + shW * 0.3, shY + H * 0.12, shW * 0.5, H * 0.06, 0.3, 0, 7); ctx.fill(); ctx.fillStyle = tint(cloth, -0.4); for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(hipX - shW * 0.7 + i * shW * 0.6, hipY + H * 0.03); ctx.lineTo(hipX - shW * 0.5 + i * shW * 0.6, hipY + H * 0.12 + Math.sin(time * 4 + i) * 2); ctx.lineTo(hipX - shW * 0.3 + i * shW * 0.6, hipY + H * 0.03); ctx.fill(); } }
  }
  if (ex.includes('bulge')) { ball(ctx, shX * 0.5 + shW * 0.3, (shY + hipY) / 2 + H * 0.02, shW * 0.9, tint(skin, -0.05), H * 0.13); }
  if (ex.includes('sac')) { ctx.globalAlpha *= 0.8; ball(ctx, shX * 0.4, (shY + hipY) / 2, shW * 1.1, skin2, H * 0.16); glowDot(ctx, shX * 0.4, (shY + hipY) / 2, shW * 0.4, tint(skin2, 0.5)); ctx.globalAlpha /= 0.8; }
  if (ex.includes('armor') || ex.includes('plates')) { shadedPoly(ctx, [[shX - shW * 1.15, shY - H * 0.04], [shX + shW * 1.15, shY - H * 0.04], [shX + shW * 0.9, shY + H * 0.08], [shX - shW * 0.9, shY + H * 0.08]], ex.includes('armor') ? tint(cloth ?? skin, -0.35) : tint(skin, -0.3), -shW, shW); }
  if (ex.includes('spikes')) { ctx.fillStyle = tint(skin2, 0.2); ctx.strokeStyle = OL; for (let i = 0; i < 4; i++) { const yy = shY + i * (hipY - shY) / 4; ctx.beginPath(); ctx.moveTo(shX - shW * 0.9, yy); ctx.lineTo(shX - shW * 1.5, yy - H * 0.05); ctx.lineTo(shX - shW * 0.8, yy + H * 0.04); ctx.fill(); ctx.stroke(); } }
  if (ex.includes('cores')) { for (let i = 0; i < 2; i++) glowDot(ctx, shX + (i - 0.5) * shW * 0.8, (shY + hipY) / 2 + i * H * 0.06, shW * 0.25 * (1 + Math.sin(time * 5 + i) * 0.15), '#ff7a1a'); }
  if (ex.includes('mycelium')) { ctx.strokeStyle = rgba(skin2, 0.55); ctx.lineWidth = 0.8; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(shX - shW * 0.8 + i * shW * 0.4, shY); ctx.quadraticCurveTo(shX + Math.sin(i * 3) * shW * 0.4, (shY + hipY) / 2, hipX - shW * 0.6 + i * shW * 0.3, hipY); ctx.stroke(); } }
  if (ex.includes('goo')) { ctx.fillStyle = rgba(skin2, 0.7); for (let i = 0; i < 3; i++) { const dy = ((time * 10 + i * 7) % 12); ctx.beginPath(); ctx.ellipse(shX - shW * 0.6 + i * shW * 0.6, hipY + dy, H * 0.015, H * 0.03, 0, 0, 7); ctx.fill(); } }
  if (ex.includes('chain')) { ctx.strokeStyle = '#8a8a90'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(shX - shW, shY + H * 0.05); ctx.quadraticCurveTo(shX - shW * 1.5, hipY + H * 0.1 + Math.sin(time * 4) * 3, shX - shW * 1.3, hipY + H * 0.3); ctx.stroke(); }
  if (ex.includes('eyes') && look.head !== 'human') { for (let i = 0; i < 4; i++) glowDot(ctx, shX - shW * 0.6 + i * shW * 0.4, shY + H * 0.1 + (i % 2) * H * 0.05, H * 0.012, look.glow ?? '#f00'); }

  // ---- head ----
  const neckX = shX + Math.sin(lean) * H * 0.05 + p.headFwd, neckY = shY - headR * 1.15 - Math.abs(p.headFwd) * 0.1;
  limb(ctx, shX, shY, neckX, neckY + headR * 0.4, armW * 0.8, skin);
  drawHead(ctx, look, neckX, neckY, headR, p, time);

  // ---- FRONT layer ----
  drawLeg(hipX + legSpread, hipY, p.legF, legCol, true);
  if (ex.includes('arms4')) drawArm(frontArmX, shY + H * 0.12, [p.armF[0] * 0.8 - 0.3, p.armF[1]], false, tint(armCol, -0.05), true);
  drawArm(frontArmX, shY, p.armF, ex.includes('bigArm'), armCol, true);
  if (ex.includes('tentacles') && p.tail > 0.5) drawTentacles(ctx, look, shX + shW * 0.3, shY + H * 0.05, H * 0.5, p, time, 2, tint(skin2, -0.1), true);
  if (ex.includes('spores') && Math.sin(time * 3 + u.id) > 0.7) { ctx.fillStyle = rgba(skin2, 0.5); for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(shX + (i - 1) * shW * 0.5, shY - H * 0.15 - ((time * 20) % 10), H * 0.02, 0, 7); ctx.fill(); } }
  ctx.restore();
}

function drawQuad(ctx: Ctx, _u: Unit, look: Look, p: Pose, bh: number, time: number) {
  const ex = look.extras ?? []; const skin = look.skin, skin2 = look.skin2 ?? tint(skin, 0.25);
  const L = bh * 0.85 * p.sq, Hh = bh * 0.42 + p.crouch * -0.5 - p.bob * 0.5;
  const legW = bh * 0.06, legL = Hh * 0.5;
  const bodyY = -Hh; const lean = p.lean;
  const leg = (ox: number, a: [number, number], isFront: boolean, col: string) => {
    const kx = ox + Math.sin(a[0]) * legL, ky = bodyY + Math.cos(a[0]) * legL;
    const fx = kx + Math.sin(a[0] + a[1] * 1.2) * legL, fy = ky + Math.cos(a[0] + a[1] * 1.2) * legL;
    const c = isFront ? col : tint(col, -0.28);
    limb(ctx, ox, bodyY, kx, ky, legW, c); limb(ctx, kx, ky, fx, fy, legW * 0.8, c);
    if (ex.includes('claws') || ex.includes('blades')) claws(ctx, fx, fy, 0.2, bh * 0.08, '#e8e4d8');
  };
  // tail
  if (ex.includes('tail')) { const sw = p.tail; bez(ctx, -L * 0.45, bodyY - Hh * 0.05, -L * 0.8, bodyY - Hh * 0.3 - sw * 8, -L * 1.0 + sw * L * 0.8, bodyY - Hh * 0.6 - sw * 10, -L * 0.9 + sw * L * 1.4, bodyY - Hh * 0.9 + Math.abs(sw) * 20, bh * 0.05, tint(skin, -0.1)); }
  if (ex.includes('tentacles')) drawTentacles(ctx, look, 0, bodyY - Hh * 0.2, bh * 0.4, p, time, 3, tint(skin2, -0.2), p.tail > 0.5);
  // back legs
  leg(-L * 0.35, [p.legB[0] * 0.8 - 0.2, -p.legB[1] * 0.6 + 0.6], false, skin);
  leg(L * 0.3, [p.armB[0] * 0.6 + 0.1, -0.3 - Math.abs(p.armB[1]) * 0.3], false, skin);
  // body
  ctx.save(); ctx.rotate(-lean * 0.35);
  ball(ctx, 0, bodyY - Hh * 0.05, L * 0.5, skin, Hh * 0.28);
  if (ex.includes('spikes') || ex.includes('plates')) { ctx.fillStyle = tint(skin2, 0.1); ctx.strokeStyle = OL; for (let i = 0; i < 5; i++) { const xx = -L * 0.35 + i * L * 0.17; ctx.beginPath(); ctx.moveTo(xx - L * 0.05, bodyY - Hh * 0.3); ctx.lineTo(xx, bodyY - Hh * 0.45); ctx.lineTo(xx + L * 0.05, bodyY - Hh * 0.3); ctx.fill(); ctx.stroke(); } }
  if (ex.includes('eyes')) for (let i = 0; i < 5; i++) glowDot(ctx, -L * 0.2 + i * L * 0.12, bodyY - Hh * 0.15 + (i % 2) * 4, bh * 0.02, look.glow ?? '#f00');
  if (ex.includes('mycelium')) { ctx.strokeStyle = rgba(skin2, 0.5); ctx.lineWidth = 0.8; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-L * 0.4 + i * L * 0.25, bodyY - Hh * 0.3); ctx.quadraticCurveTo(-L * 0.3 + i * L * 0.25, bodyY, -L * 0.45 + i * L * 0.25, bodyY + Hh * 0.2); ctx.stroke(); } }
  ctx.restore();
  // front legs
  leg(-L * 0.28, [p.legF[0] * 0.8 - 0.2, -p.legF[1] * 0.6 + 0.6], true, skin);
  leg(L * 0.38, [p.armF[0] * 0.6 + 0.1, -0.3 - Math.abs(p.armF[1]) * 0.3], true, skin);
  // neck + head
  const hx = L * 0.55 + p.headFwd, hy = bodyY - Hh * 0.25 + p.headTilt * 6;
  limb(ctx, L * 0.4, bodyY - Hh * 0.1, hx, hy, bh * 0.08, skin);
  drawHead(ctx, look, hx + bh * 0.05, hy - bh * 0.02, bh * 0.1, p, time);
}

function drawBlob(ctx: Ctx, u: Unit, look: Look, p: Pose, bh: number, time: number) {
  const ex = look.extras ?? []; const skin = look.skin, skin2 = look.skin2 ?? tint(skin, 0.25);
  const R = bh * 0.34 * p.sq; const pulse = 1 + Math.sin(time * 2.5 + u.id) * 0.03;
  const cy = -R * 0.9 + p.crouch * 0.3;
  if (ex.includes('tentacles')) drawTentacles(ctx, look, 0, cy - R * 0.2, bh * 0.5, p, time, 4, tint(skin2, -0.2), false);
  if (ex.includes('arms4')) { for (let i = 0; i < 3; i++) { const a = -0.6 + i * 0.5 + Math.sin(time * 2 + i) * 0.15; bez(ctx, R * 0.2, cy, R * 0.8, cy - R * 0.6 * Math.cos(a), R * 1.2 + p.lunge * 0.5, cy - R * 0.2, R * 1.4 + p.lunge, cy + R * 0.3 - i * R * 0.3, R * 0.14, tint(skin, 0.1)); claws(ctx, R * 1.4 + p.lunge, cy + R * 0.3 - i * R * 0.3, 0.3, R * 0.25, '#e8e4d8'); } }
  // lumpy mass
  for (let i = 0; i < 5; i++) { const a = i * 1.26 + 0.4; ball(ctx, Math.cos(a) * R * 0.55, cy + Math.sin(a) * R * 0.35, R * 0.55 * pulse, tint(skin, -0.05 * i), R * 0.45 * pulse); }
  ball(ctx, 0, cy, R * pulse, skin, R * 0.82 * pulse);
  if (ex.includes('plates')) { ctx.fillStyle = tint(skin2, -0.1); ctx.strokeStyle = OL; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.ellipse(-R * 0.4 + i * R * 0.3, cy - R * 0.5, R * 0.18, R * 0.1, 0, 0, 7); ctx.fill(); ctx.stroke(); } }
  if (ex.includes('cores')) { for (let i = 0; i < 4; i++) { const a = i * 1.6 + time * 0.5; glowDot(ctx, Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.4, R * 0.14 * (1 + Math.sin(time * 6 + i) * 0.2), '#ff7a1a'); } }
  if (ex.includes('eyes')) { for (let i = 0; i < 6; i++) { const a = i * 1.05; glowDot(ctx, Math.cos(a) * R * 0.6, cy + Math.sin(a) * R * 0.45, R * 0.06, look.glow ?? '#f00'); ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(Math.cos(a) * R * 0.6 + 1, cy + Math.sin(a) * R * 0.45, R * 0.025, 0, 7); ctx.fill(); } }
  if (ex.includes('pods')) { for (let i = 0; i < 4; i++) ball(ctx, -R * 0.5 + i * R * 0.35, cy - R * 0.6 - (i % 2) * R * 0.2, R * 0.16, skin2); }
  if (ex.includes('sac')) { ctx.globalAlpha *= 0.75; ball(ctx, 0, cy - R * 0.2, R * 0.7, skin2, R * 0.6); glowDot(ctx, 0, cy - R * 0.2, R * 0.25, tint(skin2, 0.5)); ctx.globalAlpha /= 0.75; }
  if (ex.includes('spikes')) { ctx.fillStyle = tint(skin2, 0.1); ctx.strokeStyle = OL; for (let i = 0; i < 6; i++) { const a = -2.6 + i * 0.45; ctx.beginPath(); ctx.moveTo(Math.cos(a - 0.08) * R * 0.9, cy + Math.sin(a - 0.08) * R * 0.75); ctx.lineTo(Math.cos(a) * R * 1.25, cy + Math.sin(a) * R * 1.05); ctx.lineTo(Math.cos(a + 0.08) * R * 0.9, cy + Math.sin(a + 0.08) * R * 0.75); ctx.fill(); ctx.stroke(); } }
  if (ex.includes('goo')) { ctx.fillStyle = rgba(skin2, 0.7); for (let i = 0; i < 4; i++) { const dy = ((time * 12 + i * 5) % 14); ctx.beginPath(); ctx.ellipse(-R * 0.6 + i * R * 0.4, cy + R * 0.6 + dy, R * 0.05, R * 0.1, 0, 0, 7); ctx.fill(); } }
  if (look.head !== 'none') drawHead(ctx, look, R * 0.55 + p.headFwd, cy - R * 0.1 + p.headTilt * 5, R * 0.36, p, time);
  if (ex.includes('tentacles') && p.tail > 0.3) drawTentacles(ctx, look, R * 0.3, cy - R * 0.3, bh * 0.6, p, time, 3, tint(skin2, -0.1), true);
}

function drawSerpent(ctx: Ctx, u: Unit, look: Look, p: Pose, bh: number, time: number) {
  const skin = look.skin; const L = bh * 1.1; const n = 9; const w = bh * 0.14;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) { const t = i / (n - 1); const x = -L * 0.75 + t * L * 0.75 + p.lunge * t; const y = -Math.sin(t * Math.PI) * bh * 0.15 - t * t * bh * 0.55 - Math.sin(time * 4 + i) * 2 * (1 - t); pts.push([x, y]); }
  for (let i = 0; i < n - 1; i++) limb(ctx, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], w * (0.5 + 0.6 * (i / n)), tint(skin, -0.2 + 0.25 * (i / n)));
  if (look.extras?.includes('goo')) { ctx.fillStyle = rgba(look.skin2 ?? '#fff', 0.6); for (let i = 1; i < n; i += 2) { ctx.beginPath(); ctx.arc(pts[i][0], pts[i][1] + w * 0.4, w * 0.15, 0, 7); ctx.fill(); } }
  const hp = pts[n - 1];
  ctx.save(); ctx.translate(hp[0], hp[1]); ctx.rotate(-0.5 + p.headTilt);
  const bl = (0.4 + p.jaw) * 0.8; // hammer head split
  shadedPoly(ctx, [[0, 0], [bh * 0.22, -bh * 0.12 - bl * bh * 0.1], [bh * 0.3, -bh * 0.02 - bl * bh * 0.05], [bh * 0.1, 0]], tint(skin, 0.1), 0, bh * 0.3);
  shadedPoly(ctx, [[0, 0], [bh * 0.22, bh * 0.12 + bl * bh * 0.1], [bh * 0.3, bh * 0.02 + bl * bh * 0.05], [bh * 0.1, 0]], tint(skin, -0.1), 0, bh * 0.3);
  ctx.fillStyle = '#4a0a10'; ctx.beginPath(); ctx.ellipse(bh * 0.12, 0, bh * 0.08, bh * 0.05 * (0.4 + p.jaw), 0, 0, 7); ctx.fill();
  ctx.restore();
  void u;
}

function drawCrawler(ctx: Ctx, u: Unit, look: Look, p: Pose, bh: number, time: number) {
  const skin = look.skin, skin2 = look.skin2 ?? tint(skin, 0.3); const R = bh * 0.32 * p.sq; const cy = -R * 0.7 + p.crouch * 0.3;
  const ph = u.state === 'move' ? u.moveT * 10 : time * 2;
  // legs
  for (let i = 0; i < 4; i++) {
    const sw = Math.sin(ph + i * 1.5) * 0.4; const bx = -R * 0.6 + i * R * 0.4;
    limb(ctx, bx, cy + R * 0.2, bx - R * 0.35 + sw * R, cy + R * 0.9, R * 0.12, tint(skin, -0.3));
    limb(ctx, bx, cy + R * 0.2, bx + R * 0.35 + sw * R, cy + R * 1.0, R * 0.12, skin);
  }
  if (look.extras?.includes('tail')) { const sw = Math.sin(time * 5) * 0.3 + p.tail; bez(ctx, -R * 0.8, cy, -R * 1.6, cy - R * 0.5, -R * 2.2 + sw * R, cy - R * 1.2, -R * 2.6 + sw * R * 2, cy - R * 0.4 + p.lunge * 0.2, R * 0.12, skin); }
  if (look.extras?.includes('tentacles')) drawTentacles(ctx, look, 0, cy, R * 0.9, p, time, 3, tint(skin2, -0.1), p.tail > 0.3);
  ball(ctx, 0, cy, R, skin, R * 0.62);
  ball(ctx, -R * 0.4, cy - R * 0.2, R * 0.4, tint(skin, 0.05), R * 0.3);
  if (look.extras?.includes('eyes')) for (let i = 0; i < 3; i++) glowDot(ctx, R * 0.3 + i * R * 0.15, cy - R * 0.15 + (i % 2) * R * 0.15, R * 0.06, look.glow ?? '#f00');
  if (look.head === 'maw') { ctx.fillStyle = '#4a0a10'; ctx.beginPath(); ctx.moveTo(R * 0.7, cy - R * 0.1); ctx.lineTo(R * 1.3 + p.lunge * 0.3, cy - R * 0.25 - p.jaw * R * 0.3); ctx.lineTo(R * 1.3 + p.lunge * 0.3, cy + R * 0.25 + p.jaw * R * 0.3); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#eee'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(R * 0.85 + i * R * 0.15, cy - R * 0.05 - p.jaw * R * 0.15, R * 0.05, 0, 7); ctx.fill(); } }
  if (look.glow && look.head !== 'maw') glowDot(ctx, R * 0.6, cy - R * 0.15, R * 0.1, look.glow);
}

function drawFloater(ctx: Ctx, u: Unit, look: Look, p: Pose, bh: number, time: number) {
  const skin = look.skin, skin2 = look.skin2 ?? tint(skin, 0.3); const R = bh * 0.26;
  const hover = -bh * 0.55 + Math.sin(time * 3 + u.id) * bh * 0.05 + p.crouch;
  ctx.globalAlpha *= 0.95;
  if (look.extras?.includes('wings')) { const fl = Math.sin(time * 18) * 0.5; for (const sgn of [-1, 1]) { ctx.save(); ctx.globalAlpha *= 0.5; shadedPoly(ctx, [[0, hover - R * 0.3], [sgn * R * 1.8, hover - R * 1.6 - fl * R], [sgn * R * 2.4, hover - R * 0.6 - fl * R * 0.5], [sgn * R * 1.2, hover]], tint(skin2, 0.3), -R * 2, R * 2); ctx.restore(); } }
  if (look.extras?.includes('tentacles')) { for (let i = 0; i < 5; i++) { const sw = Math.sin(time * 4 + i) * 0.3; const ext = p.tail > 0.3 ? p.lunge : 0; bez(ctx, (i - 2) * R * 0.35, hover + R * 0.6, (i - 2) * R * 0.5 + sw * R, hover + R * 1.5, (i - 2) * R * 0.4 + ext * 0.5, hover + R * 2.2, (i - 2) * R * 0.5 + sw * R * 2 + ext, hover + R * 2.9 - ext * 0.4, R * 0.14, tint(skin2, -0.1)); } }
  ball(ctx, 0, hover, R, skin, R * 0.8);
  ball(ctx, R * 0.2, hover - R * 0.4, R * 0.5, tint(skin, 0.1), R * 0.35);
  if (look.glow) glowDot(ctx, R * 0.5, hover - R * 0.1, R * 0.15, look.glow);
  if (look.extras?.includes('proboscis')) { const ext = p.lunge * 2; bez(ctx, R * 0.6, hover + R * 0.2, R * 1.2, hover + R * 0.5, R * 1.6 + ext * 0.5, hover + R * 0.2, R * 2.0 + ext, hover + R * 0.6 - ext * 0.2, R * 0.12, tint(skin, -0.15)); }
}

function drawStatus(ctx: Ctx, u: Unit, sx: number, sy: number, s: number, selected: boolean, color: string) {
  const w = Math.max(18, u.radius * 4 * s); const hp = Math.max(0, u.hp / u.maxHp);
  const show = selected || hp < 0.999 || u.inf || u.heldBy != null;
  if (!show) return;
  ctx.save(); ctx.translate(sx, sy);
  ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(-w / 2 - 1, -3, w + 2, 5);
  ctx.fillStyle = hp > 0.5 ? '#6bf26b' : hp > 0.25 ? '#ffd166' : '#ff5c5c'; ctx.fillRect(-w / 2, -2, w * hp, 3);
  if (u.inf) { const f = FACTION_MAP.get(u.inf.src)!; const k = u.inf.t / u.inf.dur; ctx.fillStyle = f.outline || f.color; ctx.fillRect(-w / 2, 3, w * k, 2); }
  if (u.fear > 0 && u.fid !== 'tphobos') { ctx.fillStyle = '#ffcc88'; ctx.fillRect(-w / 2, 6, w * Math.min(1, u.fear / 100), 1.5); }
  if (u.pollution > 0 && u.fid !== 'avirus') { ctx.fillStyle = '#9fb8c6'; ctx.fillRect(-w / 2, 8, w * Math.min(1, u.pollution / 100), 1.5); }
  if (selected) { ctx.fillStyle = color; ctx.font = `bold ${Math.max(10, 11 * Math.min(1.4, s))}px system-ui`; ctx.textAlign = 'center'; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.lineWidth = 3; ctx.strokeText(u.name, 0, -8); ctx.fillText(u.name, 0, -8); }
  if (u.attack && attackPhase(u.attack) !== 'recover' && s > 0.9) { ctx.font = `bold ${9 * Math.min(1.3, s)}px system-ui`; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.lineWidth = 2.5; const label = u.attack.spec.name; ctx.strokeText(label, 0, selected ? -22 : -8); ctx.fillText(label, 0, selected ? -22 : -8); }
  ctx.restore();
}

// ---------- corpse ----------
function drawCorpse(ctx: Ctx, c: Corpse, sx: number, sy: number, s: number, time: number) {
  const f = FACTION_MAP.get(c.fid)!; const look = c.look; OL = look.outline ?? '#141414';
  const a = Math.min(1, c.life / 10) * 0.9;
  ctx.save(); ctx.globalAlpha = a; ctx.translate(sx, sy);
  ctx.fillStyle = rgba(f.blood, 0.55); ctx.beginPath(); ctx.ellipse(0, 1, c.radius * 3 * s, c.radius * 1.0 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.scale(c.facing * s, s); ctx.rotate(-1.35);
  const bh = c.radius * 5.2 * look.size;
  // simplified lying body
  const skin = look.skin; const cloth = look.cloth;
  limb(ctx, 0, -bh * 0.05, 0, -bh * 0.45, bh * 0.13, cloth ?? skin);
  limb(ctx, bh * 0.02, -bh * 0.45, bh * 0.2, -bh * 0.62, bh * 0.07, skin);
  limb(ctx, -bh * 0.02, -bh * 0.45, -bh * 0.18, -bh * 0.3, bh * 0.07, skin);
  limb(ctx, 0, -bh * 0.05, bh * 0.1, bh * 0.28, bh * 0.08, cloth ?? skin);
  limb(ctx, 0, -bh * 0.05, -bh * 0.12, bh * 0.25, bh * 0.08, cloth ?? skin);
  if (look.head !== 'none') ball(ctx, bh * 0.05, -bh * 0.6, bh * 0.1, look.head === 'xeno' ? skin : tint(skin, -0.1));
  ctx.restore();
  if (c.inf) { const fi = FACTION_MAP.get(c.inf.src)!; ctx.save(); ctx.strokeStyle = rgba(fi.outline || fi.color, 0.5 + Math.sin(time * 6) * 0.3); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(sx, sy, c.radius * 3 * s, c.radius * 1.1 * s, 0, 0, 7); ctx.stroke(); ctx.restore(); }
  if (c.claimedBy) { const fi = FACTION_MAP.get(c.claimedBy)!; ctx.save(); ctx.strokeStyle = rgba(fi.outline || fi.color, 0.8); ctx.setLineDash([3, 3]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(sx, sy, c.radius * 3.4 * s, c.radius * 1.3 * s, 0, 0, 7); ctx.stroke(); ctx.restore(); }
}

// ---------- fx ----------
function drawFx(ctx: Ctx, fx: VisualFx, world: World, cam: Camera, W: number, H: number) {
  const { sx, sy, s } = project(cam, W, H, fx.x, fx.z, world.depth);
  const k = fx.t / fx.dur;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  switch (fx.kind) {
    case 'arc': {
      const R = fx.size * s; const a0 = fx.angle0 ?? -1.2, a1 = fx.angle1 ?? 1.1;
      const prog = Math.min(1, k * 1.4); const cur = a0 + (a1 - a0) * prog;
      const trail = Math.max(a0, cur - 1.3);
      ctx.translate(sx, sy - fx.h * s); ctx.scale(fx.dir, 1);
      const g = ctx.createRadialGradient(0, 0, R * 0.25, 0, 0, R);
      g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.7, rgba(fx.color, 0.55 * (1 - k))); g.addColorStop(1, rgba(fx.color2 ?? fx.color, 0.08 * (1 - k)));
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, R, trail - Math.PI / 2, cur - Math.PI / 2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = `rgba(255,255,255,${0.9 * (1 - k)})`; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(0, 0, R * 0.97, Math.max(trail, cur - 0.5) - Math.PI / 2, cur - Math.PI / 2); ctx.stroke();
      break;
    }
    case 'thrust': {
      const L = fx.size * s; const prog = Math.min(1, k * 2);
      ctx.translate(sx, sy - fx.h * s); ctx.scale(fx.dir, 1);
      const g = ctx.createLinearGradient(0, 0, L, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.6, rgba(fx.color, 0.7 * (1 - k))); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(L * 0.2 * prog, -3 * s); ctx.lineTo(L * prog + 6 * s, 0); ctx.lineTo(L * 0.2 * prog, 3 * s); ctx.closePath(); ctx.fill();
      ctx.fillStyle = `rgba(255,255,255,${(1 - k) * 0.9})`; ctx.beginPath(); ctx.arc(L * prog, 0, 3 * s * (1 - k), 0, 7); ctx.fill();
      break;
    }
    case 'shock': {
      const R = fx.size * s * (0.3 + 0.9 * Math.sqrt(k));
      ctx.translate(sx, sy); ctx.strokeStyle = rgba(fx.color, (1 - k) * 0.9); ctx.lineWidth = 3 * (1 - k) + 1; ctx.beginPath(); ctx.ellipse(0, 0, R, R * 0.35, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = rgba(fx.color, (1 - k) * 0.15); ctx.fill();
      break;
    }
    case 'tether': {
      const t = world.units.find((u) => u.id === fx.targetId), o = world.units.find((u) => u.id === fx.ownerId);
      if (t && o) { const a = project(cam, W, H, o.x, o.z, world.depth), b = project(cam, W, H, t.x, t.z, world.depth); ctx.strokeStyle = rgba(fx.color, 0.6 + Math.sin(fx.t * 30) * 0.3); ctx.lineWidth = 3 * s; ctx.beginPath(); ctx.moveTo(a.sx, a.sy - o.radius * 2.4 * a.s); ctx.lineTo(b.sx, b.sy - t.radius * 2.2 * b.s); ctx.stroke(); }
      break;
    }
    case 'spinfx': {
      const o = world.units.find((u) => u.id === fx.ownerId); const R = fx.size * s;
      const cx = o ? project(cam, W, H, o.x, o.z, world.depth) : { sx, sy };
      ctx.translate(cx.sx, cx.sy - fx.h * s);
      for (let i = 0; i < 3; i++) { const a = k * Math.PI * 6 + i * 2.1; ctx.strokeStyle = rgba(fx.color, 0.5 * (1 - k * 0.5)); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(0, 0, R, R * 0.4, 0, a, a + 1.2); ctx.stroke(); }
      break;
    }
    case 'scream': {
      ctx.translate(sx, sy - fx.h * s);
      for (let i = 0; i < 3; i++) { const kk = Math.max(0, k - i * 0.15) / (1 - i * 0.15); if (kk <= 0) continue; const R = fx.size * s * kk; ctx.strokeStyle = rgba(fx.color, (1 - kk) * 0.7); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(0, 0, R, R * 0.55, 0, 0, Math.PI * 2); ctx.stroke(); }
      break;
    }
    case 'spawnfx': {
      ctx.translate(sx, sy);
      const R = fx.size * s * (0.4 + k); ctx.strokeStyle = rgba(fx.color, (1 - k) * 0.8); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, R, R * 0.35, 0, 0, 7); ctx.stroke();
      const g = ctx.createLinearGradient(0, 0, 0, -fx.size * 3 * s); g.addColorStop(0, rgba(fx.color, (1 - k) * 0.45)); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(-R * 0.5, -fx.size * 3 * s, R, fx.size * 3 * s);
      break;
    }
    default: break;
  }
  ctx.restore();
}

function drawParticle(ctx: Ctx, p: Particle, cam: Camera, W: number, H: number, depth: number) {
  const { sx, sy, s } = project(cam, W, H, p.x, p.z, depth); const k = p.life / p.maxLife; const y = sy - p.h * s;
  ctx.save();
  switch (p.kind) {
    case 'text': ctx.globalAlpha = Math.min(1, k * 1.5); ctx.font = `bold ${p.size * Math.min(1.3, Math.max(0.9, s))}px system-ui`; ctx.textAlign = 'center'; ctx.strokeStyle = 'rgba(0,0,0,0.85)'; ctx.lineWidth = 3; ctx.strokeText(p.text ?? '', sx, y); ctx.fillStyle = p.color; ctx.fillText(p.text ?? '', sx, y); break;
    case 'blood': ctx.globalAlpha = Math.min(1, k * 2); ctx.fillStyle = p.color; ctx.beginPath(); ctx.ellipse(sx, y, p.size * s, p.size * s * (p.h > 1 ? 1 : 0.4), 0, 0, 7); ctx.fill(); break;
    case 'chunk': ctx.globalAlpha = Math.min(1, k * 2); ctx.translate(sx, y); ctx.rotate(p.rot ?? 0); ctx.fillStyle = p.color; ctx.fillRect(-p.size * s / 2, -p.size * s / 3, p.size * s, p.size * s * 0.66); ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(-p.size * s / 2, -p.size * s / 3, p.size * s * 0.5, p.size * s * 0.3); break;
    case 'dust': case 'smoke': ctx.globalAlpha = k * 0.7; ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(sx, y, p.size * s * (1.5 - k * 0.5), 0, 7); ctx.fill(); break;
    case 'spark': ctx.globalAlpha = k; ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = p.color; ctx.lineWidth = p.size * s; ctx.beginPath(); ctx.moveTo(sx, y); ctx.lineTo(sx - p.vx * 0.03 * s, y + p.vh * 0.03 * s); ctx.stroke(); break;
    case 'ember': case 'glow': ctx.globalAlpha = k; ctx.globalCompositeOperation = 'lighter'; ctx.shadowColor = p.color; ctx.shadowBlur = p.size * s; ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(sx, y, p.size * s * 0.5 * (0.5 + k * 0.5), 0, 7); ctx.fill(); break;
    case 'flash': ctx.globalAlpha = k * 0.9; ctx.globalCompositeOperation = 'lighter'; { const g = ctx.createRadialGradient(sx, y, 0, sx, y, p.size * s); g.addColorStop(0, p.color); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx, y, p.size * s, 0, 7); ctx.fill(); } break;
    default: break;
  }
  ctx.restore();
}

function drawProjectile(ctx: Ctx, p: Projectile, cam: Camera, W: number, H: number, depth: number) {
  const { sx, sy, s } = project(cam, W, H, p.x, p.z, depth); const y = sy - p.h * s;
  ctx.save();
  // shadow
  ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(sx, sy, p.radius * s * 0.8, p.radius * s * 0.3, 0, 0, 7); ctx.fill();
  if (p.trail.length > 1) { ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = rgba(p.color, 0.45); ctx.lineWidth = p.radius * s * 0.8; ctx.lineCap = 'round'; ctx.beginPath(); for (let i = 0; i < p.trail.length; i++) { const t = p.trail[i]; const q = project(cam, W, H, t.x, t.z, depth); if (i === 0) ctx.moveTo(q.sx, q.sy - t.h * q.s); else ctx.lineTo(q.sx, q.sy - t.h * q.s); } ctx.stroke(); ctx.globalCompositeOperation = 'source-over'; }
  if (p.kind === 'bullet') { ctx.fillStyle = '#fff4c0'; ctx.shadowColor = '#ffd070'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.ellipse(sx, y, 6 * s, 2 * s, Math.atan2(p.vz * 0.4, p.vx), 0, 7); ctx.fill(); }
  else if (p.kind === 'spike') { ctx.save(); ctx.translate(sx, y); ctx.rotate(Math.atan2(-p.vh * 0.3, p.vx)); shadedPoly(ctx, [[-6 * s, -1.5 * s], [6 * s, 0], [-6 * s, 1.5 * s]], '#e0c8a0', -6 * s, 6 * s); ctx.restore(); }
  else if (p.kind === 'fire') { ctx.globalCompositeOperation = 'lighter'; glowDot(ctx, sx, y, p.radius * s, '#ff8a20'); glowDot(ctx, sx, y, p.radius * s * 0.5, '#ffe080'); }
  else { ball(ctx, sx, y, p.radius * s, p.color); if (p.kind === 'spit') { ctx.globalAlpha = 0.6; ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(sx - p.vx * 0.02 * s, y + 2, p.radius * s * 0.5, 0, 7); ctx.fill(); } }
  ctx.restore();
}

function drawZone(ctx: Ctx, z: Zone, cam: Camera, W: number, H: number, depth: number, time: number) {
  const { sx, sy, s } = project(cam, W, H, z.x, z.z, depth); const k = Math.min(1, z.life / Math.min(2, z.maxLife));
  ctx.save(); ctx.globalAlpha = k;
  const R = z.radius * s;
  const g = ctx.createRadialGradient(sx, sy, R * 0.1, sx, sy, R);
  g.addColorStop(0, z.color); g.addColorStop(1, z.color.replace(/[\d.]+\)$/, '0)'));
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(sx, sy, R, R * 0.38, 0, 0, Math.PI * 2); ctx.fill();
  if (z.kind === 'gas' || z.kind === 'spore') { ctx.globalCompositeOperation = 'lighter'; for (let i = 0; i < 4; i++) { const a = time * 0.6 + i * 1.6; const px = sx + Math.cos(a) * R * 0.5, py = sy - 10 * s - Math.sin(a * 1.3) * R * 0.15 - i * 6 * s; ctx.fillStyle = z.color; ctx.beginPath(); ctx.ellipse(px, py, R * 0.4, R * 0.22, 0, 0, 7); ctx.fill(); } }
  if (z.kind === 'fire') { ctx.globalCompositeOperation = 'lighter'; for (let i = 0; i < 6; i++) { const px = sx + Math.sin(i * 2.3 + time * 3) * R * 0.7; const hh = (8 + Math.sin(time * 12 + i) * 4) * s; glowDot(ctx, px, sy - hh, 5 * s, i % 2 ? '#ff8a20' : '#ffd060'); } }
  if (z.kind === 'goo') { ctx.strokeStyle = 'rgba(160,160,160,0.4)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(sx, sy, R, R * 0.38, 0, 0, 7); ctx.stroke(); }
  ctx.restore();
}

// ---------- background ----------
let bgSeedCache: { x: number; h: number; w: number; t: number }[] | null = null;
function ruins() {
  if (bgSeedCache) return bgSeedCache; const arr: { x: number; h: number; w: number; t: number }[] = []; let x = 0; let seed = 7;
  const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  while (x < 6000) { const w = 30 + rnd() * 90; arr.push({ x, h: 40 + rnd() * 160, w, t: rnd() }); x += w + rnd() * 40; }
  bgSeedCache = arr; return arr;
}

export function drawScene(ctx: Ctx, world: World, cam: Camera, W: number, H: number, selectedId: number | null, time: number) {
  const horizon = H * 0.34;
  // sky
  const sky = ctx.createLinearGradient(0, 0, 0, horizon + 40);
  sky.addColorStop(0, '#1a1c2c'); sky.addColorStop(0.55, '#4a3a4e'); sky.addColorStop(0.85, '#9a6a52'); sky.addColorStop(1, '#c8a078');
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, horizon + 40);
  // sun
  const sunX = W * 0.62 - cam.x * 0.02; const sg = ctx.createRadialGradient(sunX, horizon - 30, 5, sunX, horizon - 30, 160); sg.addColorStop(0, 'rgba(255,220,170,0.9)'); sg.addColorStop(0.2, 'rgba(255,190,130,0.5)'); sg.addColorStop(1, 'rgba(255,180,120,0)'); ctx.fillStyle = sg; ctx.fillRect(0, 0, W, horizon + 40);
  // far mountains
  ctx.fillStyle = '#3a3040'; ctx.beginPath(); ctx.moveTo(0, horizon + 5);
  for (let x = 0; x <= W + 40; x += 40) { const wx = x + cam.x * 0.08; ctx.lineTo(x, horizon - 20 - Math.abs(Math.sin(wx * 0.002) * 60 + Math.sin(wx * 0.0057) * 30)); }
  ctx.lineTo(W, horizon + 5); ctx.fill();
  // ruins silhouettes (parallax)
  const rs = ruins();
  for (const layer of [{ par: 0.18, col: '#2a2530', hs: 0.8, yo: 0 }, { par: 0.32, col: '#1c1820', hs: 1, yo: 6 }]) {
    ctx.fillStyle = layer.col;
    for (const b of rs) {
      const sx = ((b.x - cam.x * layer.par) % 6000 + 6000) % 6000 - 600 + (W - 4800) / 2;
      if (sx < -200 || sx > W + 200) continue;
      const h = b.h * layer.hs; ctx.fillRect(sx, horizon + layer.yo - h, b.w, h + 10);
      if (b.t > 0.6) { ctx.beginPath(); ctx.moveTo(sx, horizon + layer.yo - h); ctx.lineTo(sx + b.w * 0.3, horizon + layer.yo - h - 25 * layer.hs); ctx.lineTo(sx + b.w * 0.5, horizon + layer.yo - h); ctx.fill(); }
      // windows
      if (layer.par > 0.3) { ctx.fillStyle = 'rgba(255,200,120,0.12)'; for (let wy = horizon - h + 12; wy < horizon - 6; wy += 16) for (let wx = sx + 6; wx < sx + b.w - 6; wx += 14) if (((wx * 7 + wy * 13) | 0) % 5 === 0) ctx.fillRect(wx, wy, 5, 7); ctx.fillStyle = layer.col; }
    }
  }
  // haze
  const hz = ctx.createLinearGradient(0, horizon - 30, 0, horizon + 60); hz.addColorStop(0, 'rgba(200,160,130,0)'); hz.addColorStop(0.5, 'rgba(200,160,130,0.35)'); hz.addColorStop(1, 'rgba(200,160,130,0)'); ctx.fillStyle = hz; ctx.fillRect(0, horizon - 30, W, 90);
  // ground
  const gg = ctx.createLinearGradient(0, horizon, 0, H); gg.addColorStop(0, '#6a5a48'); gg.addColorStop(0.15, '#5a4c3c'); gg.addColorStop(0.6, '#3e352b'); gg.addColorStop(1, '#241f19');
  ctx.fillStyle = gg; ctx.fillRect(0, horizon, W, H - horizon);
  // ground perspective stripes / cracks
  ctx.strokeStyle = 'rgba(0,0,0,0.13)'; ctx.lineWidth = 1;
  for (let i = 1; i < 10; i++) { const zz = (i / 10) * world.depth; const { sy } = project(cam, W, H, 0, zz, world.depth); ctx.beginPath(); ctx.moveTo(0, sy); ctx.lineTo(W, sy); ctx.stroke(); }
  for (let gx = Math.floor((cam.x - W / cam.zoom) / 300) * 300; gx < cam.x + W / cam.zoom; gx += 300) {
    const a = project(cam, W, H, gx, 0, world.depth), b = project(cam, W, H, gx, world.depth, world.depth);
    ctx.strokeStyle = 'rgba(0,0,0,0.08)'; ctx.beginPath(); ctx.moveTo(a.sx, a.sy); ctx.lineTo(b.sx + (b.sx - W / 2) * 0.08, b.sy); ctx.stroke();
  }
  // debris rocks (deterministic)
  ctx.fillStyle = 'rgba(0,0,0,0.22)';
  for (let i = 0; i < 70; i++) { const rx = ((i * 1237) % 9000), rz = ((i * 733) % 600) + 10; const q = project(cam, W, H, rx, rz, world.depth); if (q.sx < -20 || q.sx > W + 20) continue; ctx.beginPath(); ctx.ellipse(q.sx, q.sy, (6 + (i % 5) * 3) * q.s, (2 + (i % 3)) * q.s, 0, 0, 7); ctx.fill(); }
  // world edges
  const eL = project(cam, W, H, 0, 0, world.depth), eR = project(cam, W, H, world.width, 0, world.depth);
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; if (eL.sx > 0) ctx.fillRect(0, horizon, eL.sx, H - horizon); if (eR.sx < W) ctx.fillRect(eR.sx, horizon, W - eR.sx, H - horizon);

  // nests / banners
  for (const f of FACTIONS) {
    const n = world.nests[f.id]; const q = project(cam, W, H, n.x, n.z, world.depth); if (q.sx < -60 || q.sx > W + 60) continue;
    ctx.save(); ctx.translate(q.sx, q.sy); const s = q.s;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(0, 0, 22 * s, 7 * s, 0, 0, 7); ctx.fill();
    limb(ctx, 0, 0, 0, -70 * s, 3 * s, '#5a4a3a');
    shadedPoly(ctx, [[0, -70 * s], [34 * s, -60 * s + Math.sin(time * 3) * 3], [0, -46 * s]], f.color === '#101010' || f.color === '#0a0a0a' ? '#2a2a2a' : f.color, 0, 34 * s);
    ctx.fillStyle = f.outline ?? '#fff'; ctx.font = `bold ${10 * s}px system-ui`; ctx.textAlign = 'left'; ctx.fillText(f.short, 5 * s, -55 * s);
    ctx.restore();
  }

  // zones
  for (const z of world.zones) drawZone(ctx, z, cam, W, H, world.depth, time);
  // corpses
  for (const c of world.corpses) { const q = project(cam, W, H, c.x, c.z, world.depth); if (q.sx < -80 || q.sx > W + 80) continue; drawCorpse(ctx, c, q.sx, q.sy, q.s, time); }
  // units sorted by depth
  const drawList: { z: number; fn: () => void }[] = [];
  for (const u of world.units) {
    const q = project(cam, W, H, u.x, u.z, world.depth); if (q.sx < -150 || q.sx > W + 150) continue;
    const f = FACTION_MAP.get(u.fid)!;
    drawList.push({ z: u.z, fn: () => drawUnit(ctx, u, q.sx, q.sy, q.s, time, u.id === selectedId, f.color) });
  }
  for (const p of world.projectiles) drawList.push({ z: p.z - 0.01, fn: () => drawProjectile(ctx, p, cam, W, H, world.depth) });
  for (const p of world.particles) if (p.kind !== 'text') drawList.push({ z: p.z + 0.02, fn: () => drawParticle(ctx, p, cam, W, H, world.depth) });
  drawList.sort((a, b) => a.z - b.z);
  for (const d of drawList) d.fn();
  for (const fx of world.fx) drawFx(ctx, fx, world, cam, W, H);
  for (const p of world.particles) if (p.kind === 'text') drawParticle(ctx, p, cam, W, H, world.depth);

  // vignette + ash
  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.4, W / 2, H / 2, H * 0.95); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(230,220,200,0.35)';
  for (let i = 0; i < 40; i++) { const ax = ((i * 431 + time * (10 + (i % 5) * 4)) % (W + 40)) - 20; const ay = ((i * 197 + time * (12 + (i % 3) * 6)) % (H + 20)) - 10; ctx.fillRect(ax, ay, 1.5, 1.5); }
}

export function drawMinimap(ctx: Ctx, world: World, cam: Camera, W: number, H: number, mw: number, mh: number) {
  ctx.save();
  ctx.fillStyle = 'rgba(8,10,14,0.8)'; ctx.fillRect(0, 0, mw, mh); ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.strokeRect(0.5, 0.5, mw - 1, mh - 1);
  const mx = (x: number) => (x / world.width) * mw, mz = (z: number) => (z / world.depth) * mh;
  for (const z of world.zones) { ctx.fillStyle = z.color; ctx.beginPath(); ctx.arc(mx(z.x), mz(z.z), Math.max(2, (z.radius / world.width) * mw), 0, 7); ctx.fill(); }
  for (const u of world.units) { const f = FACTION_MAP.get(u.fid)!; ctx.fillStyle = f.outline && (f.color === '#101010' || f.color === '#0a0a0a' || f.color === '#1b1f22') ? f.outline : f.color; ctx.fillRect(mx(u.x) - 1, mz(u.z) - 1, 2.5, 2.5); }
  const vw = (W / cam.zoom / world.width) * mw;
  ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.strokeRect(mx(cam.x) - vw / 2, 0, vw, mh);
  void H;
  ctx.restore();
}
