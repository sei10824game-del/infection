import type { AttackKind, AttackSpec, FactionDef, Look, VariantDef } from './types';

const TEMPLATES: Record<AttackKind, Omit<AttackSpec, 'id' | 'name' | 'kind'>> = {
  slash: { range: 36, dmg: 1, cd: 1.7, windup: 0.34, strike: 0.16, recover: 0.36 },
  stab: { range: 44, dmg: 1.25, cd: 2.1, windup: 0.42, strike: 0.12, recover: 0.42 },
  smash: { range: 40, dmg: 1.7, cd: 3.2, windup: 0.6, strike: 0.14, recover: 0.55, aoe: 40, knock: 45, stun: 0.45 },
  bite: { range: 28, dmg: 1.1, cd: 1.6, windup: 0.3, strike: 0.12, recover: 0.32 },
  tail: { range: 64, dmg: 1.35, cd: 2.5, windup: 0.42, strike: 0.15, recover: 0.42, knock: 25 },
  tentacle: { range: 74, dmg: 1.05, cd: 2.7, windup: 0.48, strike: 0.22, recover: 0.46, aoe: 52 },
  charge: { range: 170, minRange: 60, dmg: 1.55, cd: 5.5, windup: 0.5, strike: 0.42, recover: 0.5, knock: 65, stun: 0.6 },
  pounce: { range: 160, minRange: 50, dmg: 1.45, cd: 4.8, windup: 0.46, strike: 0.46, recover: 0.46, knock: 25, aoe: 30 },
  shoot: { range: 210, dmg: 0.8, cd: 2.3, windup: 0.4, strike: 0.1, recover: 0.5 },
  spit: { range: 170, dmg: 1, cd: 3.6, windup: 0.5, strike: 0.15, recover: 0.5, aoe: 36 },
  gas: { range: 70, dmg: 0.3, cd: 8, windup: 0.6, strike: 0.5, recover: 0.6, aoe: 80 },
  explode: { range: 34, dmg: 3.2, cd: 0, windup: 0.75, strike: 0.1, recover: 0.1, aoe: 90, knock: 80 },
  grab: { range: 30, dmg: 0.65, cd: 5.5, windup: 0.42, strike: 1.7, recover: 0.4, hold: true },
  flame: { range: 110, dmg: 0.55, cd: 5.5, windup: 0.5, strike: 1.1, recover: 0.5 },
  slam: { range: 44, dmg: 1.7, cd: 4.8, windup: 0.62, strike: 0.15, recover: 0.62, aoe: 95, knock: 75, stun: 0.65 },
  spin: { range: 46, dmg: 0.85, cd: 4.2, windup: 0.42, strike: 0.66, recover: 0.42, aoe: 46, hits: 3 },
  throw: { range: 180, dmg: 1.25, cd: 4.2, windup: 0.52, strike: 0.15, recover: 0.5, aoe: 42 },
  punch: { range: 28, dmg: 0.75, cd: 1.3, windup: 0.22, strike: 0.1, recover: 0.26 },
  kick: { range: 34, dmg: 1.25, cd: 2.6, windup: 0.36, strike: 0.15, recover: 0.42, knock: 55 },
  whip: { range: 115, dmg: 0.95, cd: 2.5, windup: 0.42, strike: 0.2, recover: 0.42 },
  drain: { range: 28, dmg: 0.55, cd: 5.5, windup: 0.42, strike: 1.9, recover: 0.4, hold: true, heal: true },
  spawn: { range: 0, dmg: 0, cd: 14, windup: 0.85, strike: 0.35, recover: 0.6 },
  scream: { range: 0, dmg: 0.25, cd: 10, windup: 0.6, strike: 0.55, recover: 0.5, aoe: 120, stun: 1.3 },
};

export function A(id: string, name: string, kind: AttackKind, o: Partial<AttackSpec> = {}): AttackSpec {
  return { id, name, kind, ...TEMPLATES[kind], ...o };
}

const V = (
  key: string, name: string, w: number,
  s: { hp: number; atk: number; def: number; spd: number; radius: number; sight?: number },
  look: Look, attacks: AttackSpec[], tags: string[] = [], desc = ''
): VariantDef => ({ key, name, w, ...s, look, attacks, tags, desc });

const W = 9000;
const D = 620;

export const FACTIONS: FactionDef[] = [
  // ---------------- 始祖ウイルス ----------------
  {
    id: 'progenitor', name: '始祖ウイルス', short: 'P', color: '#d7b84a', blood: '#c8102e', initial: 14, spawn: { x: W * 0.5, z: D * 0.5 },
    growth: { every: 16, count: 1, cap: 40, mode: 'spawn' },
    info: '適合者は超人的な身体能力を得る。不適合者は理性を失うが感染を広げ、適応進化で稀に適合者へ。',
    variants: [
      V('adapted', '適合者', 3, { hp: 200, atk: 24, def: 0.22, spd: 62, radius: 8, sight: 170 },
        { body: 'human', size: 1, skin: '#e9c9a8', cloth: '#15161a', head: 'human', glow: '#ffb020', extras: ['coat', 'glasses'] },
        [
          A('p_fist', '拳連打', 'punch', { hits: 3, dmg: 0.6, cd: 1.6, strike: 0.36 }),
          A('p_dash', 'ダッシュ掌底', 'charge', { dmg: 1.6, range: 160, cd: 5 }),
          A('p_kick', '回し蹴り', 'kick', { aoe: 40, dmg: 1.4 }),
          A('p_throw', '掴み投げ', 'grab', { dmg: 1.4, strike: 0.8, knock: 90, stun: 0.9, cd: 6.5 }),
        ], ['adapt'], '拳連打／掌底突進／回し蹴り／投げ技'),
      V('feral', '不適合者', 5, { hp: 110, atk: 13, def: 0.08, spd: 44, radius: 7 },
        { body: 'hunched', size: 0.95, skin: '#d8c088', cloth: '#5a4a33', head: 'zombie', glow: '#ffd060', extras: ['rags'] },
        [
          A('pf_claw', '引っ掻き', 'slash', { dmg: 0.9 }),
          A('pf_bite', '噛みつき', 'bite', { effect: 'progenitor' }),
        ], ['adaptable'], '引っ掻き／噛みつき(感染)'),
    ],
  },
  // ---------------- T-ウイルス ----------------
  {
    id: 'tvirus', name: 'T-ウイルス', short: 'T', color: '#49b85f', blood: '#8b1a1a', initial: 34, spawn: { x: W * 0.05, z: D * 0.35 },
    growth: { every: 7, count: 2, cap: 120, mode: 'corpse' },
    info: '咬傷で感染。死体はゾンビとして蘇り、キル数の多い個体はリッカーへ変異する。',
    variants: [
      V('zombie', 'ゾンビ', 10, { hp: 80, atk: 8, def: 0.05, spd: 26, radius: 6 },
        { body: 'hunched', size: 1, skin: '#8fa886', cloth: '#4a5568', head: 'zombie', glow: '#d6ffd6', extras: ['rags'] },
        [
          A('z_bite', '噛みつき', 'bite', { effect: 'tInfect' }),
          A('z_grab', '掴みかかり', 'grab', { effect: 'tInfect', dmg: 0.5 }),
          A('z_scratch', '引っ掻き', 'slash', { dmg: 0.8 }),
        ], ['lickerMut'], '噛みつき(感染)／掴みかかり／引っ掻き'),
      V('licker', 'リッカー', 2, { hp: 140, atk: 18, def: 0.1, spd: 74, radius: 7, sight: 150 },
        { body: 'quad', size: 1.05, skin: '#b8352d', skin2: '#e7a0a0', head: 'brain', extras: ['tongue', 'claws'] },
        [
          A('l_claw', '爪斬り', 'slash', { dmg: 1.1 }),
          A('l_tongue', '舌突き', 'stab', { range: 80, dmg: 1.4, crit: 0.2 }),
          A('l_pounce', '飛びかかり', 'pounce', { dmg: 1.5 }),
        ], [], '爪斬り／舌突き／飛びかかり'),
      V('hunter', 'ハンター', 1.5, { hp: 170, atk: 20, def: 0.14, spd: 66, radius: 8 },
        { body: 'hunched', size: 1.05, skin: '#4f7f47', skin2: '#8aa36a', head: 'eyeless', glow: '#ffe98a', extras: ['claws', 'plates'] },
        [
          A('h_leap', '跳躍斬撃', 'pounce', { dmg: 1.6 }),
          A('h_sweep', '爪薙ぎ', 'slash', { aoe: 30, dmg: 1.1 }),
          A('h_decap', '首刈り', 'stab', { dmg: 1.4, crit: 0.35 }),
        ], [], '跳躍斬撃／爪薙ぎ／首刈り(致命)'),
      V('cerberus', 'ケルベロス', 2, { hp: 70, atk: 11, def: 0.04, spd: 90, radius: 5, sight: 160 },
        { body: 'quad', size: 0.8, skin: '#5b4a3e', skin2: '#b8544a', head: 'maw', glow: '#ffd0a0' },
        [
          A('c_bite', '噛みつき', 'bite', { effect: 'tInfect', dmg: 1 }),
          A('c_lunge', '跳びつき', 'pounce', { dmg: 1.2, range: 130 }),
        ], [], '噛みつき／跳びつき'),
      V('tyrant', 'タイラント', 0.5, { hp: 520, atk: 34, def: 0.26, spd: 40, radius: 12, sight: 150 },
        { body: 'brute', size: 1.35, skin: '#8f8f96', skin2: '#c4c4cc', cloth: '#2a2d36', head: 'human', glow: '#ff5050', extras: ['coat', 'bigArm', 'claws'] },
        [
          A('t_stab', '爪突き', 'stab', { dmg: 1.4, range: 52 }),
          A('t_charge', '突進', 'charge', { dmg: 1.7 }),
          A('t_sweep', '薙ぎ払い', 'slash', { aoe: 50, dmg: 1.2, range: 50 }),
          A('t_smash', '叩きつけ', 'smash', { dmg: 1.9 }),
        ], [], '爪突き／突進／薙ぎ払い／叩きつけ'),
    ],
  },
  // ---------------- t-Veronica ----------------
  {
    id: 'veronica', name: 't-Veronica', short: 'V', color: '#b52035', blood: '#ff4a2a', initial: 20, spawn: { x: W * 0.62, z: D * 0.15 },
    growth: { every: 10, count: 2, cap: 80, mode: 'spawn' },
    info: '女王が発火血液と触手で戦い、幼体を放つ。触手は拘束、感染者は咬傷で広げる。',
    variants: [
      V('vinfected', 'V感染者', 6, { hp: 100, atk: 13, def: 0.1, spd: 42, radius: 7 },
        { body: 'hunched', size: 1, skin: '#a3665c', cloth: '#5a2a2a', head: 'zombie', glow: '#ff9a9a', extras: ['rags', 'bulge'] },
        [
          A('v_bite', '噛みつき', 'bite', { effect: 'veronica' }),
          A('v_claw', '引き裂き', 'slash'),
        ], [], '噛みつき(感染)／引き裂き'),
      V('nosferatu', 'ノスフェラトゥ', 1, { hp: 260, atk: 22, def: 0.14, spd: 46, radius: 10 },
        { body: 'tall', size: 1.25, skin: '#c9b3a6', cloth: '#3a2a2a', head: 'hood', glow: '#ff4040', extras: ['tentacles', 'chain'] },
        [
          A('n_stab', '触手突き', 'stab', { range: 66, dmg: 1.4 }),
          A('n_sweep', '触手薙ぎ', 'tentacle', { dmg: 1.1 }),
          A('n_gas', '毒霧', 'gas', { effect: 'poison', dmg: 0.4 }),
        ], [], '触手突き／触手薙ぎ／毒霧'),
      V('queen', '女王アレクシア', 0.35, { hp: 560, atk: 30, def: 0.2, spd: 44, radius: 11, sight: 180 },
        { body: 'tall', size: 1.3, skin: '#c8b8b0', skin2: '#7a2a3a', cloth: '#6a1830', head: 'human', glow: '#ffb060', extras: ['flames', 'tentacles', 'crown'] },
        [
          A('q_blood', '発火血液', 'flame', { effect: 'burn', dmg: 0.6 }),
          A('q_whip', '触手鞭', 'whip', { dmg: 1.1 }),
          A('q_wave', '火炎波', 'spit', { range: 220, effect: 'burn', dmg: 1.3, aoe: 50 }),
          A('q_larva', '幼体射出', 'spawn', { spawnKey: 'larva', spawnCount: 3, cd: 16 }),
        ], [], '発火血液／触手鞭／火炎波／幼体射出'),
      V('vtentacle', '触手', 1, { hp: 140, atk: 16, def: 0.12, spd: 22, radius: 7 },
        { body: 'serpent', size: 1.1, skin: '#8a1a2a', skin2: '#d04a5a', head: 'maw', glow: '#ff8080' },
        [
          A('vt_stab', '突き刺し', 'stab', { range: 70, dmg: 1.3 }),
          A('vt_bind', '拘束', 'grab', { range: 60, dmg: 0.6 }),
        ], [], '突き刺し／拘束'),
      V('larva', '幼体', 2, { hp: 40, atk: 9, def: 0.02, spd: 80, radius: 4 },
        { body: 'crawler', size: 0.6, skin: '#e06a7a', skin2: '#ffb0b8', head: 'maw', glow: '#fff0f0' },
        [
          A('la_bite', '噛みつき', 'bite', { effect: 'veronica', dmg: 1 }),
          A('la_latch', '取り付き', 'grab', { dmg: 0.5, effect: 'veronica' }),
        ], [], '噛みつき／取り付き'),
    ],
  },
  // ---------------- G-ウイルス ----------------
  {
    id: 'gvirus', name: 'G-ウイルス', short: 'G', color: '#8e55d8', blood: '#6a2a9a', initial: 8, spawn: { x: W * 0.72, z: D * 0.8 },
    growth: { every: 18, count: 1, cap: 40, mode: 'spawn' },
    info: 'G成体はG胚を植え付け、宿主を破って新たなGが生まれる。倒れても第1〜第5形態へ変異する。',
    variants: [
      V('g1', 'G第1形態', 3, { hp: 190, atk: 26, def: 0.15, spd: 40, radius: 10 },
        { body: 'human', size: 1.15, skin: '#7d5aa8', skin2: '#c9a6ff', cloth: '#e9e9ee', head: 'human', glow: '#ff6a6a', extras: ['eyeArm', 'coat'] },
        [
          A('g1_pipe', '鉄パイプ', 'smash', { dmg: 1.4, aoe: 30 }),
          A('g1_claw', '爪斬り', 'slash', { dmg: 1.1 }),
          A('g1_eye', '目玉腕突き', 'stab', { dmg: 1.3 }),
        ], ['gform:1'], '鉄パイプ／爪斬り／目玉腕突き'),
      V('g2', 'G第2形態', 1.5, { hp: 260, atk: 34, def: 0.18, spd: 42, radius: 12 },
        { body: 'brute', size: 1.3, skin: '#6a4a98', skin2: '#c9a6ff', head: 'split', glow: '#ff6a6a', extras: ['eyeArm', 'bigArm', 'claws'] },
        [
          A('g2_smash', '爪叩きつけ', 'smash', { dmg: 1.7 }),
          A('g2_grab', '掴み', 'grab', { dmg: 0.9 }),
          A('g2_charge', '突進', 'charge'),
        ], ['gform:2'], '爪叩きつけ／掴み／突進'),
      V('g3', 'G第3形態', 0.8, { hp: 360, atk: 46, def: 0.22, spd: 46, radius: 14 },
        { body: 'brute', size: 1.45, skin: '#5a3a88', skin2: '#c9a6ff', head: 'split', glow: '#ff6a6a', extras: ['arms4', 'eyeArm', 'claws'] },
        [
          A('g3_multi', '多腕斬撃', 'slash', { hits: 2, dmg: 1.1, range: 48, strike: 0.3 }),
          A('g3_grab', '掴み噛み', 'grab', { dmg: 1.1 }),
          A('g3_smash', '叩きつけ', 'smash', { aoe: 60, dmg: 1.8 }),
        ], ['gform:3'], '多腕斬撃／掴み噛み／叩きつけ'),
      V('g4', 'G第4形態', 0.5, { hp: 480, atk: 55, def: 0.18, spd: 72, radius: 15, sight: 160 },
        { body: 'quad', size: 1.5, skin: '#4e3080', skin2: '#c9a6ff', head: 'split', glow: '#ff6a6a', extras: ['eyes', 'claws', 'spikes'] },
        [
          A('g4_charge', '四足突進', 'charge', { dmg: 1.6 }),
          A('g4_bite', '噛みつき', 'bite', { dmg: 1.3, range: 40 }),
          A('g4_pounce', '飛びかかり', 'pounce', { dmg: 1.5 }),
        ], ['gform:4'], '四足突進／噛みつき／飛びかかり'),
      V('g5', 'G第5形態', 0.2, { hp: 700, atk: 70, def: 0.28, spd: 28, radius: 19, sight: 160 },
        { body: 'blob', size: 1.9, skin: '#3e2468', skin2: '#c9a6ff', head: 'maw', glow: '#ff6a6a', extras: ['eyes', 'tentacles', 'bulge'] },
        [
          A('g5_maw', '巨大顎', 'bite', { range: 60, aoe: 50, dmg: 1.5 }),
          A('g5_tent', '触手薙ぎ', 'tentacle', { dmg: 1.2, range: 90 }),
          A('g5_emb', 'G胚放出', 'spawn', { spawnKey: 'gembryo', spawnCount: 2, cd: 18 }),
        ], ['gform:5'], '巨大顎／触手薙ぎ／G胚放出'),
      V('gadult', 'G成体', 1.5, { hp: 220, atk: 24, def: 0.14, spd: 44, radius: 9 },
        { body: 'hunched', size: 1.1, skin: '#8a68b8', skin2: '#c9a6ff', head: 'eyeless', glow: '#ff6a6a', extras: ['claws', 'proboscis'] },
        [
          A('ga_claw', '爪', 'slash'),
          A('ga_implant', '胚植え付け', 'stab', { effect: 'gEmbryo', dmg: 0.9 }),
          A('ga_grab', '掴み', 'grab', { effect: 'gEmbryo', dmg: 0.6 }),
        ], [], '爪／胚植え付け(寄生)／掴み'),
      V('gembryo', 'G胚', 1, { hp: 45, atk: 8, def: 0.02, spd: 76, radius: 4 },
        { body: 'crawler', size: 0.6, skin: '#b090e0', skin2: '#e0c8ff', head: 'maw', glow: '#ff8a8a', extras: ['eyes'] },
        [
          A('ge_bite', '噛みつき', 'bite'),
          A('ge_latch', '寄生', 'grab', { effect: 'gEmbryo', dmg: 0.4 }),
        ], [], '噛みつき／寄生'),
    ],
  },
  // ---------------- ウロボロス ----------------
  {
    id: 'uroboros', name: 'ウロボロス', short: 'U', color: '#101010', outline: '#ff7a1a', blood: '#111', initial: 14, spawn: { x: W * 0.06, z: D * 0.82 },
    growth: { every: 12, count: 1, cap: 50, mode: 'corpse' },
    info: '不適合者を触手で取り込み、死体を吸収して巨大化する。弱点は露出したコア。',
    variants: [
      V('umass', 'ウロボロス', 5, { hp: 160, atk: 22, def: 0.12, spd: 38, radius: 9 },
        { body: 'blob', size: 1.1, skin: '#111', skin2: '#2a2a2a', outline: '#3a3a3a', head: 'none', glow: '#ff7a1a', extras: ['tentacles', 'cores'] },
        [
          A('u_sweep', '触手薙ぎ', 'tentacle', { dmg: 1.1 }),
          A('u_bind', '触手拘束', 'grab', { effect: 'uroSeed', range: 50 }),
          A('u_stab', '触手突き', 'stab', { range: 72, dmg: 1.3 }),
        ], ['absorb'], '触手薙ぎ／触手拘束(取り込み)／触手突き'),
      V('aheri', 'ウロボロス・アヘリ', 0.35, { hp: 760, atk: 48, def: 0.26, spd: 24, radius: 20, sight: 170 },
        { body: 'blob', size: 2.1, skin: '#0c0c0c', skin2: '#262626', outline: '#3a3a3a', head: 'none', glow: '#ff7a1a', extras: ['tentacles', 'cores', 'spikes'] },
        [
          A('ua_slam', '触手叩きつけ', 'slam', { dmg: 1.6, range: 80, aoe: 110 }),
          A('ua_rain', '触手雨', 'tentacle', { hits: 3, dmg: 0.8, range: 130, aoe: 70, strike: 0.5 }),
          A('ua_core', 'コア爆散', 'scream', { dmg: 1.2, aoe: 140, stun: 0.8, color: '#ff7a1a' }),
        ], ['absorb'], '触手叩きつけ／触手雨／コア爆散'),
    ],
  },
  // ---------------- C-ウイルス ----------------
  {
    id: 'cvirus', name: 'C-ウイルス', short: 'C', color: '#f28a22', blood: '#c85a1a', initial: 24, spawn: { x: W * 0.4, z: D * 0.12 },
    growth: { every: 11, count: 2, cap: 80, mode: 'spawn' },
    info: 'ジュアヴォは銃器を使い、部位が変異する。致命傷でサナギ化し、完全変異体へ羽化する。',
    variants: [
      V('javo', 'ジュアヴォ', 8, { hp: 90, atk: 12, def: 0.08, spd: 54, radius: 6, sight: 200 },
        { body: 'human', size: 1, skin: '#c98a5a', cloth: '#3b3f2a', head: 'human', glow: '#ff5a2a', extras: ['gun', 'armor', 'eyes'] },
        [
          A('j_shoot', '銃撃', 'shoot', { range: 210, dmg: 0.8 }),
          A('j_butt', '銃床殴打', 'punch', { dmg: 1 }),
          A('j_arm', '変異腕斬撃', 'slash', { effect: 'cInfect', dmg: 1.2, range: 44 }),
        ], ['cocoon'], '銃撃／銃床殴打／変異腕斬撃(感染)'),
      V('cocoon', 'サナギ', 0, { hp: 120, atk: 0, def: 0.3, spd: 0, radius: 8 },
        { body: 'blob', size: 1, skin: '#c9a050', skin2: '#f5d080', outline: '#7a5a20', head: 'none', extras: ['sac'] },
        [], ['cocoonStage'], '一定時間後に完全変異体へ羽化'),
      V('napad', 'ナパド', 1, { hp: 380, atk: 34, def: 0.3, spd: 42, radius: 12 },
        { body: 'brute', size: 1.35, skin: '#b06a3a', skin2: '#e8c8a0', head: 'skull', glow: '#ffb060', extras: ['plates', 'bigArm'] },
        [
          A('na_punch', '殴打', 'punch', { dmg: 1.4, range: 40 }),
          A('na_slam', '地面叩きつけ', 'slam'),
          A('na_charge', '突進', 'charge'),
        ], [], '殴打／地面叩きつけ／突進'),
      V('strelats', 'ストレラッツ', 1, { hp: 200, atk: 20, def: 0.12, spd: 62, radius: 8, sight: 190 },
        { body: 'quad', size: 1.05, skin: '#a86a3a', skin2: '#e8b070', head: 'maw', glow: '#ffe060', extras: ['spikes', 'tail'] },
        [
          A('st_needle', '針射出', 'spit', { range: 190, hits: 3, dmg: 0.6, aoe: 20, strike: 0.4 }),
          A('st_tail', '尻尾', 'tail'),
          A('st_bite', '噛みつき', 'bite'),
        ], [], '針射出／尻尾／噛みつき'),
      V('lepotitsa', 'レポティッツァ', 0.6, { hp: 260, atk: 18, def: 0.14, spd: 38, radius: 10 },
        { body: 'tall', size: 1.2, skin: '#c9b8a8', skin2: '#e8d8c8', head: 'eyeless', glow: '#ffd0a0', extras: ['bulge', 'sac'] },
        [
          A('le_gas', 'ガス放出', 'gas', { effect: 'cInfect', dmg: 0.45 }),
          A('le_hug', '抱擁', 'grab', { effect: 'cInfect', dmg: 0.9 }),
        ], [], 'ガス放出(感染)／抱擁'),
      V('ubistvo', 'ウビストヴォ', 0.5, { hp: 420, atk: 38, def: 0.24, spd: 48, radius: 11 },
        { body: 'brute', size: 1.3, skin: '#8a5a3a', skin2: '#d8b080', head: 'skull', glow: '#ff4a2a', extras: ['saw', 'plates'] },
        [
          A('ub_saw', 'チェーンソー回転斬', 'spin', { dmg: 1, hits: 4 }),
          A('ub_charge', '突進', 'charge'),
          A('ub_stab', '突き刺し', 'stab', { dmg: 1.6, range: 50 }),
        ], [], 'チェーンソー回転斬／突進／突き刺し'),
    ],
  },
  // ---------------- A-ウイルス ----------------
  {
    id: 'avirus', name: 'A-ウイルス', short: 'A', color: '#6f8fa0', blood: '#5a6a7a', initial: 32, spawn: { x: W * 0.5, z: D * 0.88 },
    growth: { every: 8, count: 2, cap: 110, mode: 'corpse' },
    info: '感染ガスで汚染を広げ、汚染された者は死後A感染者になる。倒れる時にガスを放つ。',
    variants: [
      V('azombie', 'A感染者', 8, { hp: 70, atk: 9, def: 0.04, spd: 46, radius: 6 },
        { body: 'hunched', size: 1, skin: '#8a9aa6', cloth: '#3a4652', head: 'zombie', glow: '#bfe8ff', extras: ['rags'] },
        [
          A('a_bite', '噛みつき', 'bite', { effect: 'aGas' }),
          A('a_grab', '掴み', 'grab', { effect: 'aGas', dmg: 0.5 }),
          A('a_tackle', 'タックル', 'charge', { dmg: 1.2, range: 120, cd: 5 }),
        ], ['gasDeath'], '噛みつき／掴み／タックル (死亡時ガス)'),
      V('acarrier', 'A汚染体', 2, { hp: 110, atk: 12, def: 0.06, spd: 40, radius: 7 },
        { body: 'hunched', size: 1.1, skin: '#7a8e9c', cloth: '#2c3540', head: 'zombie', glow: '#bfe8ff', extras: ['rags', 'bulge', 'spores'] },
        [
          A('ac_gas', '感染ガス', 'gas', { effect: 'aGas', dmg: 0.35 }),
          A('ac_bite', '噛みつき', 'bite', { effect: 'aGas' }),
        ], ['gasDeath'], '感染ガス／噛みつき'),
    ],
  },
  // ---------------- プラーガ ----------------
  {
    id: 'plaga', name: 'プラーガ', short: 'PL', color: '#d6c542', blood: '#8b1a1a', initial: 28, spawn: { x: W * 0.16, z: D * 0.5 },
    growth: { every: 10, count: 2, cap: 90, mode: 'spawn' },
    info: '寄生体は宿主を支配し武器を使う。露出した寄生体は寄生種を放ち、他者を宿主にする。',
    variants: [
      V('ganado', 'ガナード', 8, { hp: 78, atk: 13, def: 0.06, spd: 50, radius: 6 },
        { body: 'human', size: 1, skin: '#c8a888', cloth: '#6a5a3a', head: 'human', glow: '#ff4040', extras: ['pitchfork'] },
        [
          A('gn_swing', '鎌振り', 'slash', { range: 44, dmg: 1.1 }),
          A('gn_throw', '投擲', 'throw', { dmg: 1.1, aoe: 0 }),
          A('gn_grab', '掴み頭突き', 'grab', { effect: 'plagaSeed', dmg: 0.8 }),
        ], ['plagaExpose'], '鎌振り／投擲／掴み頭突き(寄生)'),
      V('exposed', '寄生体露出', 2, { hp: 120, atk: 17, def: 0.1, spd: 44, radius: 7 },
        { body: 'human', size: 1.05, skin: '#c8a888', skin2: '#c86a4a', cloth: '#6a5a3a', head: 'maw', glow: '#ff5050', extras: ['tentacles', 'blades'] },
        [
          A('ex_tent', '触手刃薙ぎ', 'tentacle', { dmg: 1.2 }),
          A('ex_stab', '刃突き', 'stab', { range: 60 }),
          A('ex_spit', '寄生種放射', 'spit', { effect: 'plagaSeed', dmg: 0.6, range: 140 }),
        ], [], '触手刃薙ぎ／刃突き／寄生種放射'),
      V('garrador', 'ガラドール', 0.8, { hp: 300, atk: 30, def: 0.22, spd: 52, radius: 10 },
        { body: 'brute', size: 1.3, skin: '#b8a090', cloth: '#4a3a2a', head: 'hood', glow: '#ffffff', extras: ['blades', 'chain', 'armor'] },
        [
          A('gr_slash', '双爪斬り', 'slash', { hits: 2, dmg: 1.2, range: 44, strike: 0.28 }),
          A('gr_charge', '突進', 'charge', { dmg: 1.7 }),
          A('gr_spin', '回転薙ぎ', 'spin', { dmg: 0.9 }),
        ], [], '双爪斬り／突進／回転薙ぎ'),
      V('regenerador', 'リヘナラドール', 0.6, { hp: 260, atk: 24, def: 0.1, spd: 34, radius: 9 },
        { body: 'tall', size: 1.2, skin: '#9aa0a8', skin2: '#c8ccd0', head: 'eyeless', glow: '#a0ffa0', extras: ['spikes'] },
        [
          A('rg_grab', '掴み', 'grab', { dmg: 1 }),
          A('rg_bite', '噛みつき', 'bite', { dmg: 1.3 }),
          A('rg_arm', '伸びる腕', 'stab', { range: 78, dmg: 1.2 }),
        ], ['regen'], '掴み／噛みつき／伸びる腕 (再生)'),
    ],
  },
  // ---------------- 特異菌 ----------------
  {
    id: 'mold', name: '特異菌 / メガマイセト', short: 'M', color: '#d8d8d0', outline: '#777', blood: '#3a3a30', initial: 16, spawn: { x: W * 0.84, z: D * 0.5 },
    growth: { every: 8, count: 2, cap: 90, mode: 'nest' },
    info: '菌糸ノードからモールデッドが湧く。掴まれた者は菌糸に侵され、菌糸体として再生する。',
    variants: [
      V('molded', 'モールデッド', 6, { hp: 115, atk: 17, def: 0.1, spd: 34, radius: 7 },
        { body: 'hunched', size: 1.05, skin: '#2e2e2c', skin2: '#8a8a80', outline: '#0d0d0d', head: 'maw', extras: ['mycelium'] },
        [
          A('mo_claw', '爪', 'slash'),
          A('mo_grab', '掴み', 'grab', { effect: 'moldSpore', dmg: 0.7 }),
          A('mo_bite', '噛みつき', 'bite', { effect: 'moldSpore' }),
        ], [], '爪／掴み(菌糸感染)／噛みつき'),
      V('quadmold', '四足モールデッド', 2, { hp: 100, atk: 16, def: 0.08, spd: 66, radius: 7 },
        { body: 'quad', size: 1, skin: '#2a2a28', skin2: '#8a8a80', outline: '#0d0d0d', head: 'maw', extras: ['mycelium'] },
        [
          A('qm_pounce', '飛びかかり', 'pounce'),
          A('qm_claw', '爪', 'slash'),
          A('qm_bite', '噛みつき', 'bite', { effect: 'moldSpore' }),
        ], [], '飛びかかり／爪／噛みつき'),
      V('fatmold', '肥満モールデッド', 1, { hp: 260, atk: 24, def: 0.16, spd: 26, radius: 11 },
        { body: 'brute', size: 1.3, skin: '#33332f', skin2: '#8a8a80', outline: '#0d0d0d', head: 'maw', extras: ['mycelium', 'bulge'] },
        [
          A('fm_vomit', '酸嘔吐', 'spit', { range: 100, effect: 'acid', dmg: 1, aoe: 40 }),
          A('fm_smash', '叩きつけ', 'smash'),
        ], ['explodeDeath'], '酸嘔吐／叩きつけ (死亡時爆発)'),
      V('blademold', '刃モールデッド', 1, { hp: 150, atk: 22, def: 0.12, spd: 42, radius: 8 },
        { body: 'human', size: 1.1, skin: '#2a2a28', skin2: '#8a8a80', outline: '#0d0d0d', head: 'maw', extras: ['mycelium', 'blades'] },
        [
          A('bm_slash', '刃斬撃', 'slash', { dmg: 1.2, range: 46 }),
          A('bm_stab', '刃突き', 'stab', { dmg: 1.4 }),
          A('bm_spin', '回転斬', 'spin'),
        ], [], '刃斬撃／刃突き／回転斬'),
    ],
  },
  // ---------------- ゼノモーフ ----------------
  {
    id: 'xeno', name: 'ゼノモーフ', short: 'X', color: '#1b1f22', outline: '#8cffea', blood: '#c8ff3a', initial: 12, spawn: { x: W * 0.9, z: D * 0.85 },
    growth: { every: 13, count: 1, cap: 60, mode: 'spawn' },
    info: 'フェイスハガーが宿主に胚を植え付け、チェストバスターが宿主を破って現れる。血は強酸。',
    variants: [
      V('facehugger', 'フェイスハガー', 2, { hp: 30, atk: 5, def: 0, spd: 96, radius: 4, sight: 180 },
        { body: 'crawler', size: 0.55, skin: '#d8c8a8', skin2: '#e8dcc0', head: 'none', extras: ['tail'] },
        [
          A('fh_latch', '寄生', 'grab', { effect: 'xenoEmbryo', dmg: 0.3, strike: 1.3 }),
          A('fh_jump', '跳躍', 'pounce', { dmg: 0.5, range: 140 }),
        ], ['acidBlood'], '寄生(胚植付)／跳躍'),
      V('drone', 'ドローン', 4, { hp: 120, atk: 20, def: 0.16, spd: 86, radius: 7, sight: 170 },
        { body: 'hunched', size: 1.1, skin: '#1b1f22', skin2: '#3a4448', outline: '#0a0c0e', head: 'xeno', glow: '#8cffea', extras: ['tail', 'claws', 'spikes'] },
        [
          A('xd_claw', '爪', 'slash', { dmg: 1.1 }),
          A('xd_tail', '尻尾突き', 'tail'),
          A('xd_jaw', '内顎', 'bite', { dmg: 1.4, crit: 0.3 }),
        ], ['acidBlood'], '爪／尻尾突き／内顎(致命)'),
      V('warrior', 'ウォリアー', 2.5, { hp: 150, atk: 23, def: 0.18, spd: 84, radius: 7, sight: 170 },
        { body: 'hunched', size: 1.15, skin: '#141618', skin2: '#2e3438', outline: '#0a0c0e', head: 'xeno', glow: '#8cffea', extras: ['tail', 'claws', 'spikes', 'plates'] },
        [
          A('xw_claw', '爪', 'slash', { dmg: 1.1 }),
          A('xw_tail', '尻尾突き', 'tail'),
          A('xw_jaw', '内顎', 'bite', { dmg: 1.4, crit: 0.3 }),
          A('xw_pounce', '飛びかかり', 'pounce'),
        ], ['acidBlood'], '爪／尻尾突き／内顎／飛びかかり'),
      V('runner', 'ランナー', 1.5, { hp: 100, atk: 18, def: 0.12, spd: 110, radius: 6, sight: 180 },
        { body: 'quad', size: 0.95, skin: '#4a2a22', skin2: '#7a4a3a', outline: '#1a0a08', head: 'xeno', glow: '#8cffea', extras: ['tail', 'claws'] },
        [
          A('xr_pounce', '飛びかかり', 'pounce'),
          A('xr_bite', '噛みつき', 'bite'),
          A('xr_tail', '尻尾', 'tail'),
        ], ['acidBlood'], '飛びかかり／噛みつき／尻尾'),
      V('praetorian', 'プレトリアン', 0.6, { hp: 380, atk: 32, def: 0.3, spd: 70, radius: 11 },
        { body: 'brute', size: 1.4, skin: '#101214', skin2: '#2e3438', outline: '#0a0c0e', head: 'xeno', glow: '#8cffea', extras: ['tail', 'claws', 'plates', 'crown'] },
        [
          A('xp_claw', '爪', 'slash', { dmg: 1.2, range: 48 }),
          A('xp_tail', '尻尾突き', 'tail', { dmg: 1.5, range: 80 }),
          A('xp_charge', '突進', 'charge'),
          A('xp_jaw', '内顎', 'bite', { dmg: 1.5, crit: 0.3 }),
        ], ['acidBlood'], '爪／尻尾突き／突進／内顎'),
      V('queen', 'クイーン', 0.15, { hp: 900, atk: 52, def: 0.34, spd: 44, radius: 18, sight: 200 },
        { body: 'brute', size: 1.9, skin: '#0c0e10', skin2: '#2e3438', outline: '#0a0c0e', head: 'xeno', glow: '#8cffea', extras: ['tail', 'claws', 'plates', 'crown', 'arms4'] },
        [
          A('xq_tail', '尻尾突き', 'tail', { range: 100, dmg: 1.6 }),
          A('xq_claw', '爪薙ぎ', 'slash', { aoe: 60, range: 60, dmg: 1.2 }),
          A('xq_jaw', '内顎', 'bite', { dmg: 1.6, range: 44, crit: 0.4 }),
          A('xq_egg', '産卵', 'spawn', { spawnKey: 'facehugger', spawnCount: 2, cd: 15 }),
        ], ['acidBlood'], '尻尾突き／爪薙ぎ／内顎／産卵'),
    ],
  },
  // ---------------- 黒い液体 ----------------
  {
    id: 'pathogen', name: '黒い液体 / Pathogen', short: 'BG', color: '#0a0a0a', outline: '#a0a0a0', blood: '#111', initial: 10, spawn: { x: W * 0.97, z: D * 0.3 },
    growth: { every: 14, count: 1, cap: 50, mode: 'corpse' },
    info: '黒液に曝露した生物は変異し、ハンマーピードやネオモーフとして生まれ変わる。',
    variants: [
      V('hammerpede', 'ハンマーピード', 3, { hp: 90, atk: 16, def: 0.1, spd: 66, radius: 6 },
        { body: 'serpent', size: 1, skin: '#d8d0c8', skin2: '#f0ece4', outline: '#4a4440', head: 'maw', extras: ['goo'] },
        [
          A('hp_wrap', '締め付け', 'grab', { effect: 'pathogen', dmg: 0.8 }),
          A('hp_acid', '酸吐き', 'spit', { range: 120, effect: 'acid', dmg: 0.8 }),
          A('hp_bite', '噛みつき', 'bite', { effect: 'pathogen' }),
        ], [], '締め付け／酸吐き／噛みつき'),
      V('trilobite', 'トリロバイト', 1, { hp: 240, atk: 22, def: 0.14, spd: 48, radius: 11 },
        { body: 'blob', size: 1.4, skin: '#c8c0b8', skin2: '#e8e0d8', outline: '#3a3430', head: 'none', extras: ['tentacles', 'goo'] },
        [
          A('tr_bind', '触手拘束', 'grab', { effect: 'pathogen', range: 56, dmg: 0.9 }),
          A('tr_sweep', '触手薙ぎ', 'tentacle'),
          A('tr_implant', '寄生', 'stab', { effect: 'xenoEmbryo', range: 60, dmg: 0.8 }),
        ], [], '触手拘束／触手薙ぎ／寄生'),
      V('deacon', 'ディーコン', 1, { hp: 220, atk: 28, def: 0.18, spd: 74, radius: 9 },
        { body: 'hunched', size: 1.2, skin: '#3a5a6a', skin2: '#6a8a9a', outline: '#0a1a20', head: 'xeno', glow: '#c0e0ff', extras: ['claws'] },
        [
          A('de_jaw', '内顎', 'bite', { dmg: 1.4, crit: 0.3 }),
          A('de_claw', '爪', 'slash'),
          A('de_pounce', '飛びかかり', 'pounce'),
        ], [], '内顎／爪／飛びかかり'),
      V('neomorph', 'ネオモーフ', 2, { hp: 150, atk: 22, def: 0.12, spd: 90, radius: 7, sight: 170 },
        { body: 'hunched', size: 1.05, skin: '#e8e8e8', skin2: '#ffffff', outline: '#5a5a5a', head: 'dome', extras: ['tail', 'claws'] },
        [
          A('ne_tail', '尾棘', 'tail', { dmg: 1.4 }),
          A('ne_bite', '噛みつき', 'bite', { effect: 'pathogen' }),
          A('ne_claw', '爪', 'slash'),
          A('ne_pounce', '飛びかかり', 'pounce'),
        ], [], '尾棘／噛みつき／爪／飛びかかり'),
    ],
  },
  // ---------------- レッド・ゼノモーフ ----------------
  {
    id: 'redxeno', name: 'レッド・ゼノモーフ', short: 'RX', color: '#a01818', outline: '#ff8080', blood: '#c8ff3a', initial: 8, spawn: { x: W * 0.78, z: D * 0.1 },
    growth: { every: 15, count: 1, cap: 40, mode: 'spawn' },
    info: '巣を追われた赤い変異種。より攻撃的で群れて襲う。',
    variants: [
      V('reddrone', 'レッドドローン', 5, { hp: 125, atk: 23, def: 0.18, spd: 92, radius: 7, sight: 190 },
        { body: 'hunched', size: 1.1, skin: '#7a1414', skin2: '#c83030', outline: '#2a0404', head: 'xeno', glow: '#ff8080', extras: ['tail', 'claws', 'spikes'] },
        [
          A('rx_claw', '爪', 'slash', { dmg: 1.1 }),
          A('rx_tail', '尻尾突き', 'tail'),
          A('rx_jaw', '内顎', 'bite', { dmg: 1.4, crit: 0.3 }),
          A('rx_pounce', '飛びかかり', 'pounce'),
        ], ['acidBlood'], '爪／尻尾突き／内顎／飛びかかり'),
      V('redprae', 'レッドプレトリアン', 0.6, { hp: 360, atk: 34, def: 0.28, spd: 74, radius: 11 },
        { body: 'brute', size: 1.4, skin: '#6a1010', skin2: '#c83030', outline: '#2a0404', head: 'xeno', glow: '#ff8080', extras: ['tail', 'claws', 'plates', 'crown'] },
        [
          A('rp_claw', '爪', 'slash', { dmg: 1.2, range: 48 }),
          A('rp_tail', '尻尾突き', 'tail', { dmg: 1.5, range: 80 }),
          A('rp_charge', '突進', 'charge'),
        ], ['acidBlood'], '爪／尻尾突き／突進'),
    ],
  },
  // ---------------- ホワイト・ハイブリッド ----------------
  {
    id: 'hybrid', name: 'ホワイト・ハイブリッド', short: 'WH', color: '#eeeeee', outline: '#88ccff', blood: '#c0c0c0', initial: 8, spawn: { x: W * 0.05, z: D * 0.95 },
    growth: { every: 16, count: 1, cap: 30, mode: 'spawn' },
    info: '人とゼノモーフの白い混合種。吸血で回復し、咆哮で敵を怯ませる。',
    variants: [
      V('offspring', 'オフスプリング', 3, { hp: 200, atk: 18, def: 0.18, spd: 70, radius: 8, sight: 210 },
        { body: 'tall', size: 1.25, skin: '#e8e8e8', skin2: '#ffffff', outline: '#5a6a7a', head: 'dome', glow: '#88ccff', extras: ['proboscis', 'claws'] },
        [
          A('hy_drain', '吸血', 'drain', { dmg: 0.8 }),
          A('hy_claw', '爪', 'slash', { dmg: 1.1 }),
          A('hy_spit', '酸吐き', 'spit', { range: 130, effect: 'acid', dmg: 0.9 }),
          A('hy_roar', '咆哮', 'scream', { effect: 'fear' }),
        ], [], '吸血／爪／酸吐き／咆哮'),
      V('newborn', 'ニューボーン', 1, { hp: 420, atk: 30, def: 0.24, spd: 60, radius: 11 },
        { body: 'brute', size: 1.4, skin: '#d8d8d8', skin2: '#f8f8f8', outline: '#5a6a7a', head: 'skull', glow: '#88ccff', extras: ['claws'] },
        [
          A('nb_swipe', '薙ぎ払い', 'slash', { aoe: 50, range: 52, dmg: 1.3 }),
          A('nb_bite', '噛みつき', 'bite', { dmg: 1.5, range: 40 }),
          A('nb_crush', '抱き潰し', 'grab', { dmg: 1.4 }),
        ], [], '薙ぎ払い／噛みつき／抱き潰し'),
    ],
  },
  // ---------------- K-シリーズ ----------------
  {
    id: 'kseries', name: 'K-シリーズ', short: 'K', color: '#e59a20', outline: '#ffe08a', blood: '#c8ff3a', initial: 8, spawn: { x: W * 0.96, z: D * 0.6 },
    growth: { every: 16, count: 1, cap: 32, mode: 'spawn' },
    info: '装甲化された兵器級ゼノモーフ。酸を吐き、重装甲で前線を押し上げる。',
    variants: [
      V('ksoldier', 'K-兵士', 3, { hp: 170, atk: 22, def: 0.34, spd: 74, radius: 8 },
        { body: 'hunched', size: 1.15, skin: '#b8741a', skin2: '#f0c060', outline: '#3a2404', head: 'xeno', glow: '#ffe08a', extras: ['tail', 'claws', 'armor', 'plates'] },
        [
          A('k_claw', '爪', 'slash', { dmg: 1.1 }),
          A('k_tail', '尻尾', 'tail'),
          A('k_charge', '突進', 'charge'),
          A('k_spit', '酸吐き', 'spit', { range: 150, effect: 'acid', dmg: 0.9 }),
        ], ['acidBlood'], '爪／尻尾／突進／酸吐き'),
      V('kheavy', 'K-重装型', 1, { hp: 480, atk: 36, def: 0.42, spd: 50, radius: 12 },
        { body: 'brute', size: 1.5, skin: '#9a5e10', skin2: '#f0c060', outline: '#3a2404', head: 'xeno', glow: '#ffe08a', extras: ['tail', 'claws', 'armor', 'plates', 'spikes'] },
        [
          A('kh_smash', '叩きつけ', 'smash', { dmg: 1.8 }),
          A('kh_tail', '尻尾', 'tail', { range: 80, dmg: 1.5 }),
          A('kh_charge', '突進', 'charge', { dmg: 1.8 }),
        ], ['acidBlood'], '叩きつけ／尻尾／突進'),
    ],
  },
  // ---------------- SRP Parasites ----------------
  {
    id: 'parasites', name: 'SRP Parasites', short: 'SRP', color: '#7b1f1f', outline: '#ff6a6a', blood: '#5a0a0a', initial: 5, spawn: { x: W * 0.55, z: D * 0.95 },
    growth: { every: 12, count: 1, cap: 50, mode: 'corpse' },
    info: '同化寄生体。取り込んだ相手に擬態し、受けた攻撃に適応する。バイオマスが溜まると合体体へ。',
    variants: [
      V('imitation', '擬態体', 4, { hp: 90, atk: 16, def: 0.14, spd: 58, radius: 6, sight: 160 },
        { body: 'human', size: 1, skin: '#b88a7a', skin2: '#7b1f1f', cloth: '#3a3a3a', head: 'split', glow: '#ff6a6a', extras: ['tentacles'] },
        [
          A('sr_whip', '触手鞭', 'whip', { dmg: 1 }),
          A('sr_assim', '同化', 'grab', { effect: 'assimilate', dmg: 0.9 }),
          A('sr_spike', '骨棘', 'stab', { dmg: 1.3, range: 56 }),
        ], ['adaptDmg'], '触手鞭／同化(寄生)／骨棘'),
      V('crawlerp', '分裂体', 3, { hp: 40, atk: 9, def: 0.05, spd: 84, radius: 4 },
        { body: 'crawler', size: 0.6, skin: '#7b1f1f', skin2: '#c85050', head: 'maw', glow: '#ff6a6a', extras: ['tentacles'] },
        [
          A('cp_bite', '噛みつき', 'bite', { effect: 'assimilate' }),
          A('cp_latch', '取り付き', 'grab', { effect: 'assimilate', dmg: 0.4 }),
        ], [], '噛みつき／取り付き'),
      V('abomination', '合体体', 0.4, { hp: 520, atk: 36, def: 0.24, spd: 40, radius: 14 },
        { body: 'blob', size: 1.7, skin: '#5a1010', skin2: '#c85050', outline: '#2a0404', head: 'split', glow: '#ff6a6a', extras: ['tentacles', 'eyes', 'arms4', 'bulge'] },
        [
          A('ab_sweep', '触手薙ぎ', 'tentacle', { aoe: 70, range: 90, dmg: 1.2 }),
          A('ab_spit', '酸吐き', 'spit', { range: 150, effect: 'acid' }),
          A('ab_slam', '叩きつけ', 'slam'),
          A('ab_assim', '同化', 'grab', { effect: 'assimilate', range: 44, dmg: 1 }),
        ], ['adaptDmg'], '触手薙ぎ／酸吐き／叩きつけ／同化'),
    ],
  },
  // ---------------- 冬虫夏草 ----------------
  {
    id: 'cordyceps', name: '冬虫夏草 (CBI)', short: 'CBI', color: '#b58a3a', outline: '#f1e0aa', blood: '#8b1a1a', initial: 28, spawn: { x: W * 0.12, z: D * 0.15 },
    growth: { every: 8, count: 2, cap: 100, mode: 'corpse' },
    info: '咬傷で胞子感染。ランナー→クリッカー→ブローターへ進行し、死体から菌糸が広がる。',
    variants: [
      V('runner', 'ランナー', 8, { hp: 70, atk: 10, def: 0.06, spd: 66, radius: 6 },
        { body: 'human', size: 1, skin: '#c8a888', skin2: '#d8b060', cloth: '#5a4a3a', head: 'zombie', glow: '#ffd080', extras: ['rags'] },
        [
          A('ru_bite', '噛みつき', 'bite', { effect: 'cordySpore' }),
          A('ru_grab', '掴み', 'grab', { effect: 'cordySpore', dmg: 0.5 }),
          A('ru_scratch', '引っ掻き', 'slash', { dmg: 0.8 }),
        ], ['cordyEvolve'], '噛みつき／掴み／引っ掻き'),
      V('stalker', 'ストーカー', 2, { hp: 95, atk: 13, def: 0.08, spd: 76, radius: 6 },
        { body: 'hunched', size: 1, skin: '#b89a78', skin2: '#d8b060', cloth: '#4a3a2a', head: 'fungus', glow: '#ffd080' },
        [
          A('sk_pounce', '奇襲飛びかかり', 'pounce', { dmg: 1.5 }),
          A('sk_slash', '引っ掻き', 'slash'),
          A('sk_bite', '噛みつき', 'bite', { effect: 'cordySpore' }),
        ], ['cordyEvolve'], '奇襲飛びかかり／引っ掻き／噛みつき'),
      V('clicker', 'クリッカー', 2.5, { hp: 160, atk: 20, def: 0.16, spd: 48, radius: 7 },
        { body: 'hunched', size: 1.05, skin: '#a89070', skin2: '#e0c070', cloth: '#3a3028', head: 'fungus', glow: '#ffe0a0', extras: ['spores'] },
        [
          A('ck_rip', '噛み千切り', 'grab', { dmg: 1.6, effect: 'cordySpore' }),
          A('ck_claw', '引っ掻き', 'slash'),
          A('ck_charge', '突進', 'charge', { range: 120, dmg: 1.3 }),
        ], ['cordyEvolve'], '噛み千切り／引っ掻き／突進'),
      V('bloater', 'ブローター', 0.6, { hp: 420, atk: 32, def: 0.3, spd: 30, radius: 12 },
        { body: 'brute', size: 1.4, skin: '#8a7050', skin2: '#e0c070', head: 'fungus', glow: '#ffe0a0', extras: ['plates', 'spores', 'bulge'] },
        [
          A('bl_bomb', '胞子爆弾', 'throw', { effect: 'cordySpore', dmg: 1, aoe: 60 }),
          A('bl_rip', '引き裂き', 'grab', { dmg: 1.8 }),
          A('bl_smash', '叩きつけ', 'smash'),
        ], [], '胞子爆弾／引き裂き／叩きつけ'),
      V('shambler', 'シャンブラー', 0.6, { hp: 300, atk: 22, def: 0.18, spd: 34, radius: 11 },
        { body: 'brute', size: 1.3, skin: '#7a6a50', skin2: '#d0b060', head: 'fungus', glow: '#ffe0a0', extras: ['pods', 'bulge'] },
        [
          A('sh_burst', '酸胞子噴出', 'gas', { effect: 'acid', dmg: 0.6, aoe: 70 }),
          A('sh_bite', '噛みつき', 'bite'),
          A('sh_punch', '殴打', 'punch', { dmg: 1.2 }),
        ], ['explodeDeath'], '酸胞子噴出／噛みつき／殴打'),
      V('ratking', 'ラットキング', 0.15, { hp: 1000, atk: 50, def: 0.34, spd: 36, radius: 19, sight: 170 },
        { body: 'blob', size: 2, skin: '#6a5840', skin2: '#d0b060', head: 'fungus', glow: '#ffe0a0', extras: ['arms4', 'plates', 'spores', 'eyes'] },
        [
          A('rk_slam', '叩きつけ', 'slam', { dmg: 1.7, aoe: 110 }),
          A('rk_charge', '突進', 'charge', { dmg: 1.8 }),
          A('rk_bite', '噛みつき', 'bite', { range: 50, dmg: 1.4 }),
          A('rk_split', '分裂', 'spawn', { spawnKey: 'stalker', spawnCount: 2, cd: 20 }),
        ], [], '叩きつけ／突進／噛みつき／分裂'),
    ],
  },
  // ---------------- ネクロモーフ ----------------
  {
    id: 'necro', name: 'ネクロモーフ', short: 'N', color: '#6b1f1f', outline: '#e0c090', blood: '#5a1010', initial: 20, spawn: { x: W * 0.68, z: D * 0.55 },
    growth: { every: 10, count: 1, cap: 80, mode: 'corpse' },
    info: 'インフェクターが死体を再構成しネクロモーフ化。四肢の切断以外では止まらない。',
    variants: [
      V('slasher', 'スラッシャー', 6, { hp: 120, atk: 19, def: 0.18, spd: 54, radius: 7 },
        { body: 'human', size: 1.05, skin: '#8a5a4a', skin2: '#e0c090', cloth: '#3a3a3a', head: 'skull', glow: '#ffd090', extras: ['blades', 'arms4'] },
        [
          A('sl_slash', '刃斬撃', 'slash', { dmg: 1.1 }),
          A('sl_stab', '刃突き', 'stab'),
          A('sl_spin', '両刃薙ぎ', 'spin', { hits: 2 }),
        ], [], '刃斬撃／刃突き／両刃薙ぎ'),
      V('leaper', 'リーパー', 2, { hp: 90, atk: 16, def: 0.1, spd: 84, radius: 6 },
        { body: 'quad', size: 0.95, skin: '#7a4a3a', skin2: '#e0c090', head: 'skull', glow: '#ffd090', extras: ['tail', 'blades'] },
        [
          A('lp_pounce', '飛びかかり', 'pounce'),
          A('lp_tail', '尾鞭', 'tail'),
          A('lp_bite', '噛みつき', 'bite'),
        ], [], '飛びかかり／尾鞭／噛みつき'),
      V('exploder', 'エクスプローダー', 1, { hp: 50, atk: 24, def: 0.02, spd: 50, radius: 6 },
        { body: 'hunched', size: 1, skin: '#8a5a4a', skin2: '#f0e070', head: 'skull', glow: '#ffff80', extras: ['sac'] },
        [A('ex_boom', '自爆', 'explode', { dmg: 3 })], ['suicide'], '自爆'),
      V('puker', 'ピューカー', 1.5, { hp: 130, atk: 17, def: 0.12, spd: 44, radius: 7 },
        { body: 'human', size: 1.05, skin: '#6a5a3a', skin2: '#c8e070', cloth: '#2a2a2a', head: 'split', glow: '#c8ff70', extras: ['goo'] },
        [
          A('pk_puke', '酸嘔吐', 'spit', { range: 140, effect: 'acid', dmg: 1 }),
          A('pk_claw', '爪', 'slash'),
          A('pk_grab', '掴み', 'grab', { effect: 'acid', dmg: 0.9 }),
        ], [], '酸嘔吐／爪／掴み'),
      V('lurker', 'ラーカー', 1.2, { hp: 70, atk: 14, def: 0.06, spd: 60, radius: 5, sight: 230 },
        { body: 'crawler', size: 0.7, skin: '#b8a090', skin2: '#e0c090', head: 'eyeless', glow: '#ffd090', extras: ['tentacles'] },
        [
          A('lk_barb', '棘射出', 'shoot', { range: 230, hits: 3, dmg: 0.55, strike: 0.5 }),
          A('lk_tent', '触手薙ぎ', 'tentacle', { range: 60 }),
        ], [], '棘射出(3連)／触手薙ぎ'),
      V('brute', 'ブルート', 0.5, { hp: 460, atk: 38, def: 0.34, spd: 46, radius: 12 },
        { body: 'brute', size: 1.45, skin: '#6a4a3a', skin2: '#e0c090', head: 'skull', glow: '#ffd090', extras: ['plates', 'bigArm', 'armor'] },
        [
          A('br_charge', '突進', 'charge', { dmg: 1.8 }),
          A('br_slam', '叩きつけ', 'slam'),
          A('br_throw', '肉塊投擲', 'throw', { dmg: 1.3 }),
        ], [], '突進／叩きつけ／肉塊投擲'),
      V('infector', 'インフェクター', 1.5, { hp: 60, atk: 10, def: 0.04, spd: 70, radius: 5, sight: 200 },
        { body: 'floater', size: 0.75, skin: '#8a6a5a', skin2: '#e0c090', head: 'none', glow: '#ffd090', extras: ['wings', 'proboscis'] },
        [A('in_stab', '吻突き', 'stab', { effect: 'necroInfect', dmg: 0.8, range: 36 })], ['corpseSeeker'], '吻突き(感染)／死体再構成'),
    ],
  },
  // ---------------- フラッド ----------------
  {
    id: 'flood', name: 'フラッド', short: 'FL', color: '#98b83c', outline: '#d7e37a', blood: '#a8b840', initial: 18, spawn: { x: W * 0.24, z: D * 0.9 },
    growth: { every: 7, count: 2, cap: 130, mode: 'corpse' },
    info: '感染フォームが宿主に潜り込み戦闘フォームへ。キャリアは破裂して感染フォームを撒く。',
    variants: [
      V('infection', '感染フォーム', 8, { hp: 18, atk: 5, def: 0, spd: 88, radius: 3.5, sight: 180 },
        { body: 'crawler', size: 0.5, skin: '#a8b850', skin2: '#d7e37a', head: 'none', extras: ['tentacles'] },
        [
          A('fi_latch', '取り付き', 'grab', { effect: 'floodSpore', dmg: 0.3, strike: 1.2 }),
          A('fi_pop', '破裂', 'explode', { dmg: 1, aoe: 30 }),
        ], ['corpseSeeker'], '取り付き(寄生)／破裂'),
      V('combat', '戦闘フォーム', 5, { hp: 110, atk: 16, def: 0.1, spd: 68, radius: 7 },
        { body: 'hunched', size: 1.05, skin: '#7a8a3a', skin2: '#d7e37a', cloth: '#3a4a2a', head: 'split', glow: '#d7e37a', extras: ['tentacles', 'gun', 'bulge'] },
        [
          A('fc_whip', '触手鞭', 'whip', { dmg: 1.1, range: 70 }),
          A('fc_shoot', '銃撃', 'shoot', { range: 180 }),
          A('fc_leap', '跳躍叩きつけ', 'pounce', { dmg: 1.3 }),
        ], [], '触手鞭／銃撃／跳躍叩きつけ'),
      V('carrier', 'キャリアフォーム', 2, { hp: 90, atk: 12, def: 0.06, spd: 36, radius: 9 },
        { body: 'blob', size: 1.2, skin: '#8a9a40', skin2: '#d7e37a', head: 'none', extras: ['sac', 'pods'] },
        [A('fr_burst', '破裂', 'explode', { dmg: 1.4, aoe: 70, spawnKey: 'infection', spawnCount: 4 })], ['suicide'], '破裂(感染フォーム散布)'),
      V('tank', 'タンクフォーム', 0.6, { hp: 560, atk: 40, def: 0.3, spd: 36, radius: 13 },
        { body: 'brute', size: 1.5, skin: '#6a7a30', skin2: '#d7e37a', head: 'maw', glow: '#d7e37a', extras: ['tentacles', 'plates', 'bulge'] },
        [
          A('ft_slam', '叩きつけ', 'slam'),
          A('ft_sweep', '触手薙ぎ', 'tentacle', { aoe: 70, dmg: 1.3 }),
          A('ft_bite', '噛みつき', 'bite', { range: 44, dmg: 1.4 }),
        ], [], '叩きつけ／触手薙ぎ／噛みつき'),
      V('fstalker', 'ストーカーフォーム', 1.5, { hp: 100, atk: 15, def: 0.08, spd: 90, radius: 6 },
        { body: 'quad', size: 0.9, skin: '#7a8a3a', skin2: '#d7e37a', head: 'maw', glow: '#d7e37a', extras: ['tentacles'] },
        [
          A('fs_claw', '爪', 'slash'),
          A('fs_pounce', '飛びかかり', 'pounce'),
        ], [], '爪／飛びかかり'),
      V('franged', '遠距離フォーム', 1, { hp: 140, atk: 16, def: 0.1, spd: 30, radius: 8, sight: 260 },
        { body: 'tall', size: 1.1, skin: '#7a8a3a', skin2: '#d7e37a', head: 'none', glow: '#d7e37a', extras: ['spikes', 'tentacles'] },
        [
          A('fr_spike', '棘射出', 'shoot', { range: 250, hits: 4, dmg: 0.5, strike: 0.6 }),
          A('fr_tent', '触手', 'tentacle', { range: 60 }),
        ], [], '棘射出(4連)／触手'),
      V('gravemind', 'グレイブマインド', 0.1, { hp: 1400, atk: 60, def: 0.36, spd: 18, radius: 24, sight: 220 },
        { body: 'blob', size: 2.6, skin: '#4a5a28', skin2: '#d7e37a', head: 'maw', glow: '#d7e37a', extras: ['tentacles', 'eyes', 'pods', 'spikes'] },
        [
          A('gm_slam', '触手叩きつけ', 'slam', { range: 120, aoe: 130, dmg: 1.6 }),
          A('gm_sweep', '触手薙ぎ', 'tentacle', { range: 150, aoe: 90, dmg: 1.2 }),
          A('gm_spore', '胞子', 'gas', { effect: 'floodSpore', aoe: 110, dmg: 0.5 }),
          A('gm_spawn', '産出', 'spawn', { spawnKey: 'infection', spawnCount: 4, cd: 12 }),
        ], [], '触手叩きつけ／触手薙ぎ／胞子／産出'),
    ],
  },
  // ---------------- E-001型 ----------------
  {
    id: 'e001', name: 'E-001型変異菌', short: 'E', color: '#f0f0e8', outline: '#777', blood: '#3a3a30', initial: 14, spawn: { x: W * 0.13, z: D * 0.7 },
    growth: { every: 12, count: 1, cap: 60, mode: 'nest' },
    info: 'エヴリンの菌糸は精神を支配する。曝露した者は幻覚に囚われ、やがてE感染体となる。',
    variants: [
      V('emold', 'E感染体', 6, { hp: 90, atk: 13, def: 0.08, spd: 40, radius: 6 },
        { body: 'hunched', size: 1, skin: '#4a4a44', skin2: '#e8e8e0', outline: '#1a1a18', head: 'maw', extras: ['mycelium'] },
        [
          A('em_claw', '爪', 'slash'),
          A('em_grab', '掴み', 'grab', { effect: 'eExposure', dmg: 0.6 }),
          A('em_bite', '噛みつき', 'bite', { effect: 'eExposure' }),
        ], [], '爪／掴み(曝露)／噛みつき'),
      V('eveline', 'エヴリン', 0.4, { hp: 380, atk: 26, def: 0.2, spd: 30, radius: 10, sight: 200 },
        { body: 'tall', size: 1.2, skin: '#e8e8e0', skin2: '#8a8a80', cloth: '#2a2a2a', head: 'human', glow: '#d0d0ff', extras: ['mycelium', 'tentacles'] },
        [
          A('ev_whip', '菌糸鞭', 'whip', { range: 130, dmg: 1.1 }),
          A('ev_fog', '胞子霧', 'gas', { effect: 'eExposure', dmg: 0.4, aoe: 100 }),
          A('ev_dom', '精神支配', 'scream', { effect: 'fear', stun: 1.6, aoe: 130 }),
          A('ev_spawn', '菌糸体生成', 'spawn', { spawnKey: 'emold', spawnCount: 2, cd: 15 }),
        ], [], '菌糸鞭／胞子霧／精神支配／菌糸体生成'),
    ],
  },
  // ---------------- t-Abyss ----------------
  {
    id: 'tabyss', name: 't-Abyss', short: 'AB', color: '#2f84a8', outline: '#8ee8ff', blood: '#3a6a8a', initial: 18, spawn: { x: W * 0.43, z: D * 0.7 },
    growth: { every: 10, count: 2, cap: 80, mode: 'corpse' },
    info: '海洋由来のウイルス。ウーズは体液を吸い、宿主をウーズへ変える。チャンクは爆発する。',
    variants: [
      V('ooze', 'ウーズ', 7, { hp: 95, atk: 15, def: 0.1, spd: 44, radius: 7 },
        { body: 'hunched', size: 1.05, skin: '#7aa0b0', skin2: '#c8e8f0', outline: '#1a3a4a', head: 'eyeless', glow: '#8ee8ff', extras: ['goo', 'proboscis'] },
        [
          A('oz_lance', '触手槍', 'stab', { range: 74, dmg: 1.3 }),
          A('oz_drain', '吸血', 'drain', { effect: 'abyssInfect', dmg: 0.7 }),
          A('oz_swipe', '引っ掻き', 'slash'),
        ], [], '触手槍／吸血(感染)／引っ掻き'),
      V('chunk', 'チャンク', 1.5, { hp: 80, atk: 24, def: 0.06, spd: 34, radius: 8 },
        { body: 'brute', size: 1.15, skin: '#5a8a9a', skin2: '#c8e8f0', outline: '#1a3a4a', head: 'eyeless', glow: '#8ee8ff', extras: ['goo', 'bulge'] },
        [A('ch_boom', '爆発', 'explode', { dmg: 2.6, aoe: 85 })], ['suicide'], '爆発'),
      V('scagdead', 'スキャグデッド', 0.8, { hp: 340, atk: 32, def: 0.2, spd: 38, radius: 11 },
        { body: 'brute', size: 1.35, skin: '#6a90a0', skin2: '#c8e8f0', cloth: '#3a4a5a', head: 'split', glow: '#8ee8ff', extras: ['saw', 'bulge'] },
        [
          A('sd_saw', '鋸斬撃', 'slash', { dmg: 1.4, range: 50 }),
          A('sd_spin', '鋸薙ぎ', 'spin', { dmg: 1 }),
          A('sd_bite', '噛みつき', 'bite', { dmg: 1.4, range: 40 }),
        ], [], '鋸斬撃／鋸薙ぎ／噛みつき'),
      V('rachael', 'レイチェル', 0.6, { hp: 260, atk: 26, def: 0.14, spd: 68, radius: 8 },
        { body: 'tall', size: 1.15, skin: '#8ab0c0', skin2: '#e0f0f8', cloth: '#c8a030', outline: '#1a3a4a', head: 'human', glow: '#8ee8ff', extras: ['claws', 'goo'] },
        [
          A('ra_claw', '爪斬り', 'slash', { dmg: 1.2 }),
          A('ra_leap', '跳躍', 'pounce'),
          A('ra_scream', '絶叫', 'scream', { effect: 'fear', dmg: 0.2 }),
        ], [], '爪斬り／跳躍／絶叫'),
      V('creeper', 'シークリーパー', 2, { hp: 60, atk: 11, def: 0.04, spd: 92, radius: 5 },
        { body: 'quad', size: 0.8, skin: '#3a7a90', skin2: '#8ee8ff', head: 'maw', glow: '#8ee8ff', extras: ['tail'] },
        [
          A('cr_bite', '噛みつき', 'bite', { effect: 'abyssInfect' }),
          A('cr_lunge', '突撃', 'pounce', { range: 120 }),
        ], [], '噛みつき／突撃'),
    ],
  },
  // ---------------- t-Phobos ----------------
  {
    id: 'tphobos', name: 't-Phobos', short: 'PH', color: '#9a6f4a', outline: '#ffcc88', blood: '#8b1a1a', initial: 18, spawn: { x: W * 0.86, z: D * 0.15 },
    growth: { every: 10, count: 2, cap: 80, mode: 'spawn' },
    info: '恐怖で発症するウイルス。恐怖が極まった者はアフリクテッドへ変異する。',
    variants: [
      V('afflicted', 'アフリクテッド', 7, { hp: 85, atk: 14, def: 0.08, spd: 52, radius: 6 },
        { body: 'human', size: 1, skin: '#b89a80', cloth: '#4a3a30', head: 'zombie', glow: '#ffcc88', extras: ['knife', 'rags'] },
        [
          A('af_knife', 'ナイフ', 'slash', { dmg: 1 }),
          A('af_swing', '刃振り下ろし', 'smash', { dmg: 1.3, aoe: 20, cd: 2.8 }),
          A('af_grab', '掴み', 'grab', { effect: 'fear', dmg: 0.7 }),
        ], [], 'ナイフ／刃振り下ろし／掴み'),
      V('rotten', 'ロッテン', 4, { hp: 110, atk: 12, def: 0.06, spd: 30, radius: 7 },
        { body: 'hunched', size: 1.05, skin: '#7a6a5a', cloth: '#3a2a20', head: 'zombie', glow: '#ffcc88', extras: ['rags', 'bulge'] },
        [
          A('ro_bite', '噛みつき', 'bite', { effect: 'fear' }),
          A('ro_grab', '掴み', 'grab', { effect: 'fear', dmg: 0.6 }),
        ], [], '噛みつき／掴み'),
      V('glasp', 'グラスプ', 1, { hp: 120, atk: 14, def: 0.1, spd: 60, radius: 7 },
        { body: 'floater', size: 1, skin: '#a0a8b0', skin2: '#d0d8e0', outline: '#4a4a50', head: 'none', glow: '#ffcc88', extras: ['tentacles', 'wings'] },
        [
          A('gl_grab', '捕獲', 'grab', { effect: 'fear', dmg: 0.8, range: 40 }),
          A('gl_gas', '恐怖ガス', 'gas', { effect: 'fear', dmg: 0.2 }),
        ], [], '捕獲／恐怖ガス (半透明)'),
      V('revenant', 'レヴナント', 1, { hp: 260, atk: 26, def: 0.16, spd: 56, radius: 9 },
        { body: 'tall', size: 1.2, skin: '#8a6a50', skin2: '#c8b090', head: 'skull', glow: '#ffcc88', extras: ['blades', 'arms4', 'spikes'] },
        [
          A('rv_slash', '刃斬', 'slash', { dmg: 1.2, range: 46 }),
          A('rv_spin', '回転刃', 'spin'),
          A('rv_charge', '突進', 'charge'),
          A('rv_grab', '掴み', 'grab', { dmg: 1 }),
        ], [], '刃斬／回転刃／突進／掴み'),
      V('vulcan', 'ヴァルカンブラバー', 0.5, { hp: 420, atk: 34, def: 0.28, spd: 30, radius: 12 },
        { body: 'brute', size: 1.4, skin: '#7a5a48', skin2: '#ff8040', head: 'maw', glow: '#ff9040', extras: ['flames', 'bulge', 'plates'] },
        [
          A('vu_fire', '火炎放射', 'flame', { effect: 'burn' }),
          A('vu_punch', '殴打', 'punch', { dmg: 1.4, range: 40 }),
          A('vu_slam', '叩きつけ', 'slam'),
        ], [], '火炎放射／殴打／叩きつけ'),
      V('durga', 'ドゥルガー', 0.4, { hp: 500, atk: 40, def: 0.26, spd: 52, radius: 12 },
        { body: 'brute', size: 1.4, skin: '#6a4a3a', skin2: '#c8b090', head: 'split', glow: '#ffcc88', extras: ['arms4', 'blades', 'spikes'] },
        [
          A('du_multi', '多腕斬', 'slash', { hits: 3, dmg: 1, range: 50, strike: 0.4 }),
          A('du_charge', '突進', 'charge'),
          A('du_spin', '回転斬', 'spin', { hits: 4 }),
        ], [], '多腕斬／突進／回転斬'),
    ],
  },
];

export const WORLD_W = W;
export const WORLD_D = D;

export const FACTION_MAP = new Map(FACTIONS.map((f) => [f.id, f]));
export function getVariant(fid: string, key: string): VariantDef | undefined {
  return FACTION_MAP.get(fid)?.variants.find((v) => v.key === key);
}

export const EFFECT_LABEL: Record<string, string> = {
  tInfect: 'T感染', gEmbryo: 'G胚寄生', cInfect: 'C感染', plagaSeed: 'プラーガ寄生', uroSeed: 'ウロボロス侵食',
  xenoEmbryo: 'ゼノ胚', moldSpore: '菌糸感染', cordySpore: 'CBI感染', floodSpore: 'Flood寄生', necroInfect: 'ネクロ感染',
  aGas: 'A汚染', burn: '炎上', fear: '恐怖', pathogen: '黒液曝露', assimilate: 'SRP同化', eExposure: 'E菌曝露',
  abyssInfect: 'Abyss感染', veronica: 'Veronica感染', progenitor: '始祖感染', acid: '酸', poison: '毒',
};
